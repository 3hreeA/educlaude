#!/bin/bash
# ============================================================================
# School Manager — Combined Database Migration Script
# Run this to generate a single SQL file for Supabase SQL Editor
# ============================================================================
# Usage: bash scripts/combine-migrations.sh > setup-database.sql
# Then paste setup-database.sql into Supabase SQL Editor and run

set -e

MIGRATION_DIR="supabase/migrations"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "-- ============================================================================"
echo "-- School Manager: Combined Database Setup"
echo "-- Generated: $(date)"
echo "-- Run this entire script in Supabase SQL Editor"
echo "-- ============================================================================"
echo ""
echo "-- Enable required extensions"
echo "CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";"
echo ""

# Ordered migration files
MIGRATIONS=(
  "001_core_schema.sql"
  "002_academic_schema.sql"
  "003_financial_schema.sql"
  "004_communication.sql"
  "005_disciplinary.sql"
  "006_rls_policies.sql"
  "009_seed_data.sql"
  "009b_seed_users.sql"
  "010_sprint3_seed_data.sql"
  "011_sprint5_teacher_data.sql"
  "012_fixup_feedback_schema.sql"
  "013_sprint6_fee_data.sql"
  "014_sprint8_communication.sql"
  "015_sprint8_notification_seed.sql"
  "016_sprint9_teacher_leave.sql"
  "017_sprint11_payroll_plans.sql"
  "018_sprint13_timetable_messages.sql"
)

for migration in "${MIGRATIONS[@]}"; do
  filepath="$PROJECT_DIR/$MIGRATION_DIR/$migration"
  if [ -f "$filepath" ]; then
    echo ""
    echo "-- ============================================================================"
    echo "-- Migration: $migration"
    echo "-- ============================================================================"
    echo ""
    cat "$filepath"
    echo ""
  else
    echo "-- WARNING: $migration not found at $filepath" >&2
  fi
done

echo ""
echo "-- ============================================================================"
echo "-- Migration complete. All tables, seed data, and indexes created."
echo "-- ============================================================================"
