-- ============================================================================
-- School Manager: Combined Database Setup
-- Generated: Sun Mar  1 13:06:16 UTC 2026
-- Run this entire script in Supabase SQL Editor
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";


-- ============================================================================
-- Migration: 001_core_schema.sql
-- ============================================================================

-- ========================================================================
-- School Manager — Core Schema
-- Tables: school, academic_years, terms, users, classes, students,
--         parents, teachers, student_parents, teacher_assignments
-- ========================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── School ────────────────────────────────────────────────────────────
CREATE TABLE schools (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(200) NOT NULL,
  address TEXT NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(200) NOT NULL,
  logo_url TEXT,
  motto VARCHAR(500),
  lga VARCHAR(100),
  state VARCHAR(50) NOT NULL DEFAULT 'Lagos',
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Academic Years ────────────────────────────────────────────────────
CREATE TABLE academic_years (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name VARCHAR(50) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT false,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(school_id, name)
);

-- ─── Terms ─────────────────────────────────────────────────────────────
CREATE TABLE terms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  name VARCHAR(50) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT false,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(academic_year_id, name)
);

-- ─── Users (all roles) ────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('parent', 'teacher', 'admin', 'finance');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  auth_id UUID UNIQUE NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  phone VARCHAR(20),
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  role user_role NOT NULL,
  avatar_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  last_login_at TIMESTAMPTZ,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Classes ───────────────────────────────────────────────────────────
CREATE TABLE classes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  level VARCHAR(50) NOT NULL,
  arm VARCHAR(10),
  capacity INTEGER NOT NULL DEFAULT 40,
  academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(school_id, name, academic_year_id)
);

-- ─── Students ──────────────────────────────────────────────────────────
CREATE TYPE gender_type AS ENUM ('male', 'female');

CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  admission_number VARCHAR(30) UNIQUE NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  middle_name VARCHAR(100),
  gender gender_type NOT NULL,
  date_of_birth DATE NOT NULL,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
  photo_url TEXT,
  blood_group VARCHAR(5),
  genotype VARCHAR(5),
  medical_notes TEXT,
  address TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  admission_date DATE NOT NULL DEFAULT CURRENT_DATE,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Parents ───────────────────────────────────────────────────────────
CREATE TABLE parents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  occupation VARCHAR(200),
  employer VARCHAR(200),
  relationship VARCHAR(50) NOT NULL DEFAULT 'parent',
  is_emergency_contact BOOLEAN NOT NULL DEFAULT false,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Teachers ──────────────────────────────────────────────────────────
CREATE TABLE teachers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  staff_id VARCHAR(30) UNIQUE NOT NULL,
  qualification VARCHAR(200),
  specialization VARCHAR(200),
  date_joined DATE NOT NULL DEFAULT CURRENT_DATE,
  is_class_teacher BOOLEAN NOT NULL DEFAULT false,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Student–Parent Junction ───────────────────────────────────────────
CREATE TABLE student_parents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  parent_id UUID NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(student_id, parent_id)
);

-- ─── Teacher Assignments ───────────────────────────────────────────────
CREATE TABLE teacher_assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id UUID,
  is_class_teacher BOOLEAN NOT NULL DEFAULT false,
  academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  established_year INT,
  level VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(teacher_id, class_id, subject_id, academic_year_id)
);

-- ─── Updated-at trigger ────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'school','academic_years','terms','users','classes','students',
    'parents','teachers','student_parents','teacher_assignments'
  ]) LOOP
    EXECUTE format('
      CREATE TRIGGER set_updated_at BEFORE UPDATE ON %I
      FOR EACH ROW EXECUTE FUNCTION update_updated_at();
    ', t);
  END LOOP;
END $$;

-- ─── Indexes ───────────────────────────────────────────────────────────
CREATE INDEX idx_users_auth_id ON users(auth_id);
CREATE INDEX idx_users_school_role ON users(school_id, role);
CREATE INDEX idx_students_class ON students(class_id);
CREATE INDEX idx_students_school ON students(school_id);
CREATE INDEX idx_student_parents_student ON student_parents(student_id);
CREATE INDEX idx_student_parents_parent ON student_parents(parent_id);
CREATE INDEX idx_teacher_assignments_teacher ON teacher_assignments(teacher_id);
CREATE INDEX idx_teacher_assignments_class ON teacher_assignments(class_id);
CREATE INDEX idx_classes_academic_year ON classes(academic_year_id);
CREATE INDEX idx_terms_academic_year ON terms(academic_year_id);


-- ============================================================================
-- Migration: 002_academic_schema.sql
-- ============================================================================

-- ========================================================================
-- Academic Schema: subjects, attendance, assessments, grades, report_cards
-- ========================================================================

CREATE TABLE subjects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20) NOT NULL,
  is_compulsory BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(school_id, code)
);

-- Now add FK for teacher_assignments.subject_id
ALTER TABLE teacher_assignments
  ADD CONSTRAINT fk_teacher_assignments_subject
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL;

CREATE TYPE attendance_status AS ENUM ('present', 'absent', 'late', 'excused');

CREATE TABLE attendance_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  status attendance_status NOT NULL,
  marked_by UUID NOT NULL REFERENCES users(id),
  term_id UUID NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(student_id, date)
);

CREATE TABLE assessments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  term_id UUID NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  max_score NUMERIC(5,2) NOT NULL,
  weight NUMERIC(5,2) NOT NULL DEFAULT 1.0,
  date DATE NOT NULL,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE grades (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  score NUMERIC(5,2) NOT NULL,
  remarks TEXT,
  entered_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(student_id, assessment_id)
);

CREATE TABLE student_feedback (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES users(id),
  term_id UUID NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
  category VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  is_visible_to_parent BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_attendance_student_date ON attendance_records(student_id, date);
CREATE INDEX idx_attendance_class_date ON attendance_records(class_id, date);
CREATE INDEX idx_attendance_term ON attendance_records(term_id);
CREATE INDEX idx_grades_student ON grades(student_id);
CREATE INDEX idx_grades_assessment ON grades(assessment_id);
CREATE INDEX idx_assessments_class_term ON assessments(class_id, term_id);
CREATE INDEX idx_feedback_student ON student_feedback(student_id);

-- Triggers
CREATE TRIGGER set_updated_at BEFORE UPDATE ON subjects FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON attendance_records FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON assessments FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON grades FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON student_feedback FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================================
-- Migration: 003_financial_schema.sql
-- ============================================================================

-- ========================================================================
-- Financial Schema: fee types, structures, accounts, payments, payroll
-- ========================================================================

CREATE TABLE fee_types (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  is_recurring BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(school_id, name)
);

CREATE TABLE fee_structures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  term_id UUID NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
  class_id UUID REFERENCES classes(id) ON DELETE SET NULL,
  name VARCHAR(200) NOT NULL,
  total_amount NUMERIC(12,2) NOT NULL,
  due_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE fee_structure_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_structure_id UUID NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
  fee_type_id UUID NOT NULL REFERENCES fee_types(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TYPE fee_account_status AS ENUM ('current', 'overdue', 'paid', 'partial');
CREATE TYPE payment_status AS ENUM ('pending', 'success', 'failed', 'refunded');
CREATE TYPE payment_method AS ENUM ('card', 'bank_transfer', 'ussd', 'cash');

CREATE TABLE student_fee_accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  fee_structure_id UUID NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
  total_amount NUMERIC(12,2) NOT NULL,
  amount_paid NUMERIC(12,2) NOT NULL DEFAULT 0,
  balance NUMERIC(12,2) GENERATED ALWAYS AS (total_amount - amount_paid) STORED,
  status fee_account_status NOT NULL DEFAULT 'current',
  due_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(student_id, fee_structure_id)
);

CREATE TABLE payment_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_account_id UUID NOT NULL REFERENCES student_fee_accounts(id) ON DELETE RESTRICT,
  amount NUMERIC(12,2) NOT NULL,
  payment_method payment_method NOT NULL,
  payment_reference VARCHAR(100) UNIQUE NOT NULL,
  gateway_reference VARCHAR(200),
  status payment_status NOT NULL DEFAULT 'pending',
  paid_by UUID NOT NULL REFERENCES users(id),
  receipt_number VARCHAR(50),
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Payroll tables
CREATE TABLE salary_structures (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  basic_salary NUMERIC(12,2) NOT NULL,
  housing_allowance NUMERIC(12,2) DEFAULT 0,
  transport_allowance NUMERIC(12,2) DEFAULT 0,
  meal_allowance NUMERIC(12,2) DEFAULT 0,
  effective_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE payroll_runs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  year INTEGER NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  processed_by UUID REFERENCES users(id),
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(school_id, month, year)
);

CREATE TABLE payslips (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  payroll_run_id UUID NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  gross_salary NUMERIC(12,2) NOT NULL,
  tax_paye NUMERIC(12,2) DEFAULT 0,
  pension NUMERIC(12,2) DEFAULT 0,
  nhf NUMERIC(12,2) DEFAULT 0,
  other_deductions NUMERIC(12,2) DEFAULT 0,
  net_salary NUMERIC(12,2) NOT NULL,
  bank_name VARCHAR(100),
  account_number VARCHAR(20),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(payroll_run_id, teacher_id)
);

-- Indexes
CREATE INDEX idx_fee_accounts_student ON student_fee_accounts(student_id);
CREATE INDEX idx_fee_accounts_status_due ON student_fee_accounts(status, due_date);
CREATE INDEX idx_payments_fee_account ON payment_transactions(fee_account_id);
CREATE INDEX idx_payments_status ON payment_transactions(status);
CREATE INDEX idx_payslips_teacher ON payslips(teacher_id);

-- Triggers
CREATE TRIGGER set_updated_at BEFORE UPDATE ON fee_types FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON fee_structures FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON student_fee_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON payment_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON salary_structures FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON payroll_runs FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON payslips FOR EACH ROW EXECUTE FUNCTION update_updated_at();


-- ============================================================================
-- Migration: 004_communication.sql
-- ============================================================================

CREATE TYPE announcement_priority AS ENUM ('low', 'normal', 'high', 'urgent');
CREATE TYPE announcement_status AS ENUM ('draft', 'published', 'archived');
CREATE TYPE notification_type AS ENUM (
  'attendance', 'grade', 'fee', 'payment', 'announcement',
  'feedback', 'disciplinary', 'system'
);

CREATE TABLE announcements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  priority announcement_priority DEFAULT 'normal',
  status announcement_status DEFAULT 'draft',
  target_audience TEXT[] DEFAULT ARRAY['all'],
  attachment_urls TEXT[],
  published_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_announcements_school ON announcements(school_id, status);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  type notification_type NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  data JSONB DEFAULT '{}',
  read_at TIMESTAMPTZ,
  sent_via TEXT[] DEFAULT ARRAY['in_app'],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX idx_notifications_unread ON notifications(recipient_id) WHERE read_at IS NULL;


-- ============================================================================
-- Migration: 005_disciplinary.sql
-- ============================================================================

CREATE TYPE incident_severity AS ENUM ('minor', 'moderate', 'major', 'critical');
CREATE TYPE incident_status AS ENUM ('reported', 'investigating', 'resolved', 'escalated');

CREATE TABLE disciplinary_incidents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  reported_by UUID NOT NULL REFERENCES users(id),
  severity incident_severity NOT NULL,
  status incident_status DEFAULT 'reported',
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  action_taken TEXT,
  parent_notified BOOLEAN DEFAULT FALSE,
  parent_notified_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES users(id),
  resolved_at TIMESTAMPTZ,
  follow_up_date DATE,
  follow_up_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_disciplinary_student ON disciplinary_incidents(student_id);
CREATE INDEX idx_disciplinary_status ON disciplinary_incidents(school_id, status);


-- ============================================================================
-- Migration: 006_rls_policies.sql
-- ============================================================================

-- Enable RLS on all tables
DO $$ 
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Helper functions
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS user_role AS $$
  SELECT role FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION get_user_school_id()
RETURNS UUID AS $$
  SELECT school_id FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION is_staff()
RETURNS BOOLEAN AS $$
  SELECT role IN ('admin', 'finance', 'super_admin') FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- School: members only
CREATE POLICY school_read ON schools FOR SELECT USING (id = get_user_school_id());

-- Users: same school
CREATE POLICY users_read ON users FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY users_update_self ON users FOR UPDATE USING (id = auth.uid());

-- Academic structure: same school read
CREATE POLICY ay_read ON academic_years FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY terms_read ON terms FOR SELECT USING (
  academic_year_id IN (SELECT id FROM academic_years WHERE school_id = get_user_school_id())
);
CREATE POLICY classes_read ON classes FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY classes_write ON classes FOR ALL USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY subjects_read ON subjects FOR SELECT USING (school_id = get_user_school_id());

-- Students: parents see own children, staff/teachers see all
CREATE POLICY students_read ON students FOR SELECT USING (
  school_id = get_user_school_id() AND (
    is_staff() OR get_user_role() = 'teacher' OR
    id IN (
      SELECT sp.student_id FROM student_parents sp
      JOIN parents p ON p.id = sp.parent_id WHERE p.user_id = auth.uid()
    )
  )
);
CREATE POLICY students_write ON students FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Parents / student_parents
CREATE POLICY parents_read ON parents FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY sp_read ON student_parents FOR SELECT USING (
  parent_id IN (SELECT id FROM parents WHERE school_id = get_user_school_id())
);

-- Teachers
CREATE POLICY teachers_read ON teachers FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY ta_read ON teacher_assignments FOR SELECT USING (
  teacher_id IN (SELECT id FROM teachers WHERE school_id = get_user_school_id())
);

-- Attendance: parents see own children, teachers/staff see all
CREATE POLICY attendance_read ON attendance_records FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id()) AND (
    is_staff() OR get_user_role() = 'teacher' OR
    student_id IN (
      SELECT sp.student_id FROM student_parents sp
      JOIN parents p ON p.id = sp.parent_id WHERE p.user_id = auth.uid()
    )
  )
);
CREATE POLICY attendance_write ON attendance_records FOR INSERT WITH CHECK (
  get_user_role() IN ('teacher', 'admin', 'super_admin')
);
CREATE POLICY attendance_edit ON attendance_records FOR UPDATE USING (
  get_user_role() IN ('teacher', 'admin', 'super_admin')
);

-- Grades
CREATE POLICY grades_read ON grades FOR SELECT USING (
  assessment_id IN (
    SELECT a.id FROM assessments a JOIN classes c ON c.id = a.class_id
    WHERE c.school_id = get_user_school_id()
  )
);
CREATE POLICY grades_write ON grades FOR ALL USING (get_user_role() IN ('teacher', 'admin', 'super_admin'));

-- Fees & Payments
CREATE POLICY fee_types_read ON fee_types FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY fee_structures_read ON fee_structures FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY fee_items_read ON fee_structure_items FOR SELECT USING (
  fee_structure_id IN (SELECT id FROM fee_structures WHERE school_id = get_user_school_id())
);
CREATE POLICY fee_accounts_read ON student_fee_accounts FOR SELECT USING (
  student_id IN (SELECT id FROM students WHERE school_id = get_user_school_id())
);
CREATE POLICY payments_read ON payment_transactions FOR SELECT USING (school_id = get_user_school_id());

-- Notifications: own only
CREATE POLICY notif_read ON notifications FOR SELECT USING (recipient_id = auth.uid());
CREATE POLICY notif_update ON notifications FOR UPDATE USING (recipient_id = auth.uid());

-- Announcements
CREATE POLICY ann_read ON announcements FOR SELECT USING (
  school_id = get_user_school_id() AND (status = 'published' OR is_staff())
);
CREATE POLICY ann_write ON announcements FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Assessments / Report Cards / Feedback
CREATE POLICY assessments_read ON assessments FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id())
);
CREATE POLICY rc_read ON report_cards FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id())
);
CREATE POLICY feedback_read ON student_feedback FOR SELECT USING (
  student_id IN (SELECT id FROM students WHERE school_id = get_user_school_id())
);

-- Disciplinary
CREATE POLICY disc_read ON disciplinary_incidents FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY disc_write ON disciplinary_incidents FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Payroll (finance/admin only)
CREATE POLICY salary_read ON salary_structures FOR SELECT USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY payroll_read ON payroll_runs FOR SELECT USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY payslips_read ON payslips FOR SELECT USING (
  payroll_run_id IN (SELECT id FROM payroll_runs WHERE school_id = get_user_school_id())
);


-- ============================================================================
-- Migration: 009_seed_data.sql
-- ============================================================================

-- Seed: Bright Future Academy test data
INSERT INTO schools (id, name, address, phone, email, motto, established_year, state, lga, level)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'Bright Future Academy',
  '15 Admiralty Way, Lekki Phase 1, Lagos',
  '+234 801 234 5678',
  'info@brightfutureacademy.ng',
  'Excellence in Education',
  2010, 'Lagos', 'Eti-Osa', 'primary_secondary'
);

INSERT INTO academic_years (id, school_id, name, start_date, end_date, is_current) VALUES
('00000000-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000001',
 '2025/2026', '2025-09-08', '2026-07-17', TRUE);

INSERT INTO terms (id, academic_year_id, name, start_date, end_date, is_current) VALUES
('00000000-0000-0000-0000-000000000011', '00000000-0000-0000-0000-000000000010', 'first',  '2025-09-08', '2025-12-12', FALSE),
('00000000-0000-0000-0000-000000000012', '00000000-0000-0000-0000-000000000010', 'second', '2026-01-12', '2026-04-03', TRUE),
('00000000-0000-0000-0000-000000000013', '00000000-0000-0000-0000-000000000010', 'third',  '2026-04-27', '2026-07-17', FALSE);

INSERT INTO classes (id, school_id, name, level, section, academic_year_id) VALUES
('00000000-0000-0000-0000-000000000020', '00000000-0000-0000-0000-000000000001', 'Primary 1A', 'Primary 1', 'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000021', '00000000-0000-0000-0000-000000000001', 'Primary 4B', 'Primary 4', 'B', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000022', '00000000-0000-0000-0000-000000000001', 'JSS 1A',     'JSS 1',     'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000023', '00000000-0000-0000-0000-000000000001', 'JSS 2A',     'JSS 2',     'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000024', '00000000-0000-0000-0000-000000000001', 'SSS 1A',     'SSS 1',     'A', '00000000-0000-0000-0000-000000000010');

INSERT INTO subjects (school_id, name, code, is_compulsory, level) VALUES
('00000000-0000-0000-0000-000000000001', 'Mathematics',     'MATH', TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'English Language', 'ENG',  TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Basic Science',   'BSC',  TRUE,  'primary'),
('00000000-0000-0000-0000-000000000001', 'Social Studies',  'SST',  TRUE,  'junior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Physics',         'PHY',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Chemistry',       'CHE',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Biology',         'BIO',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Civic Education', 'CIV',  TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Computer Science','CS',   TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Yoruba',          'YOR',  TRUE,  NULL);

INSERT INTO fee_types (school_id, name, description, is_recurring, is_compulsory) VALUES
('00000000-0000-0000-0000-000000000001', 'Tuition Fee',       'Termly tuition',          TRUE,  TRUE),
('00000000-0000-0000-0000-000000000001', 'Development Levy',  'Annual development levy',  FALSE, TRUE),
('00000000-0000-0000-0000-000000000001', 'Books & Materials', 'Textbooks and materials',  TRUE,  TRUE),
('00000000-0000-0000-0000-000000000001', 'Uniform',           'School uniform',           FALSE, TRUE),
('00000000-0000-0000-0000-000000000001', 'Transport',         'School bus service',       TRUE,  FALSE),
('00000000-0000-0000-0000-000000000001', 'Feeding',           'School lunch program',     TRUE,  FALSE);

-- NOTE: Run 009b_seed_users.sql next to create the test user accounts.


-- ============================================================================
-- Migration: 009b_seed_users.sql
-- ============================================================================

-- ============================================================================
-- Test User Accounts for School Manager
-- Creates Supabase Auth users + application users
-- Run this AFTER 009_seed_data.sql (school, classes, subjects must exist)
-- ============================================================================
-- 
-- TEST CREDENTIALS:
--   admin@brightfuture.ng    / TestPass123!  (Admin role)
--   teacher@brightfuture.ng  / TestPass123!  (Teacher role)
--   parent@brightfuture.ng   / TestPass123!  (Parent role)
--   finance@brightfuture.ng  / TestPass123!  (Finance role)
--
-- ============================================================================

-- Enable pgcrypto for password hashing (already enabled in Supabase)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─── Create Supabase Auth Users ──────────────────────────────────────
-- These go into auth.users (Supabase's built-in auth table)
-- Using deterministic UUIDs so we can reference them in the app users table

INSERT INTO auth.users (
  id, instance_id, email, encrypted_password,
  email_confirmed_at, created_at, updated_at,
  raw_app_meta_data, raw_user_meta_data,
  is_super_admin, role, aud, confirmation_token
)
VALUES
  -- Admin
  (
    'aaaa0000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000000',
    'admin@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Adewale","last_name":"Ogundimu"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Teacher
  (
    'aaaa0000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000000',
    'teacher@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Ngozi","last_name":"Eze"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Parent
  (
    'aaaa0000-0000-0000-0000-000000000003',
    '00000000-0000-0000-0000-000000000000',
    'parent@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Emeka","last_name":"Okafor"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Finance
  (
    'aaaa0000-0000-0000-0000-000000000004',
    '00000000-0000-0000-0000-000000000000',
    'finance@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Funke","last_name":"Adeyemi"}',
    false, 'authenticated', 'authenticated', ''
  )
ON CONFLICT (id) DO NOTHING;

-- Also need identities for Supabase Auth to work properly
INSERT INTO auth.identities (
  id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at
)
VALUES
  (
    'aaaa0000-0000-0000-0000-000000000001',
    'aaaa0000-0000-0000-0000-000000000001',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000001', 'email', 'admin@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000001',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000002',
    'aaaa0000-0000-0000-0000-000000000002',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000002', 'email', 'teacher@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000002',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000003',
    'aaaa0000-0000-0000-0000-000000000003',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000003', 'email', 'parent@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000003',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000004',
    'aaaa0000-0000-0000-0000-000000000004',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000004', 'email', 'finance@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000004',
    NOW(), NOW(), NOW()
  )
ON CONFLICT DO NOTHING;

-- ─── Create Application Users ────────────────────────────────────────
-- These go into the public.users table (our app's user records)

INSERT INTO users (id, auth_id, email, phone, first_name, last_name, role, is_active, school_id)
VALUES
  (
    'dd000000-0000-0000-0000-000000000001',
    'aaaa0000-0000-0000-0000-000000000001',
    'admin@brightfuture.ng',
    '+234 802 111 1111',
    'Adewale', 'Ogundimu', 'admin', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000002',
    'aaaa0000-0000-0000-0000-000000000002',
    'teacher@brightfuture.ng',
    '+234 803 222 2222',
    'Ngozi', 'Eze', 'teacher', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000003',
    'aaaa0000-0000-0000-0000-000000000003',
    'parent@brightfuture.ng',
    '+234 804 333 3333',
    'Emeka', 'Okafor', 'parent', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000004',
    'aaaa0000-0000-0000-0000-000000000004',
    'finance@brightfuture.ng',
    '+234 805 444 4444',
    'Funke', 'Adeyemi', 'finance', true,
    '00000000-0000-0000-0000-000000000001'
  )
ON CONFLICT (email) DO UPDATE SET
  auth_id = EXCLUDED.auth_id,
  first_name = EXCLUDED.first_name,
  last_name = EXCLUDED.last_name;


-- ============================================================================
-- Migration: 010_sprint3_seed_data.sql
-- ============================================================================

-- ============================================================================
-- Sprint 3-4 Seed Data: Parent Feature Test Data
-- Run AFTER 009_seed_data.sql
-- ============================================================================

-- NOTE: This seed data references UUIDs from 009_seed_data.sql.
-- In a real deployment, the auth user IDs come from Supabase Auth.
-- Below we use deterministic UUIDs for testing.

-- ─── Parent and Student records ──────────────────────────────────────
-- (Assumes users were created in 009_seed_data.sql)

-- Create parent profile for parent user
INSERT INTO parents (id, user_id, occupation, employer, relationship, is_emergency_contact, school_id)
VALUES
  ('a0000000-0000-0000-0000-000000000001', 
   (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Software Engineer', 'Tech Solutions Ltd', 'Father', true,
   (SELECT id FROM schools LIMIT 1))
ON CONFLICT DO NOTHING;

-- Create 2 test students
INSERT INTO students (id, school_id, admission_number, first_name, last_name, gender, date_of_birth, class_id, is_active, admission_date)
VALUES
  ('b0000000-0000-0000-0000-000000000001',
   (SELECT id FROM schools LIMIT 1),
   'BFA-2025-001', 'Chidi', 'Okafor', 'male', '2015-03-15',
   (SELECT id FROM classes WHERE name = 'Primary 4B' LIMIT 1),
   true, '2023-09-01'),
  ('b0000000-0000-0000-0000-000000000002',
   (SELECT id FROM schools LIMIT 1),
   'BFA-2025-002', 'Amara', 'Okafor', 'female', '2017-07-22',
   (SELECT id FROM classes WHERE name = 'Primary 1A' LIMIT 1),
   true, '2024-09-01')
ON CONFLICT DO NOTHING;

-- Link parent to students
INSERT INTO student_parents (student_id, parent_id)
VALUES
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- ─── Teacher profile ─────────────────────────────────────────────────
INSERT INTO teachers (id, user_id, staff_id, qualification, specialization, date_joined, is_class_teacher, school_id)
VALUES
  ('c0000000-0000-0000-0000-000000000001',
   (SELECT id FROM users WHERE email = 'teacher@brightfuture.ng' LIMIT 1),
   'TCH-001', 'B.Ed Mathematics', 'Mathematics', '2020-01-15', true,
   (SELECT id FROM schools LIMIT 1))
ON CONFLICT DO NOTHING;

-- ─── Attendance Records (last 30 school days for Chidi) ──────────────
DO $$
DECLARE
  term_id UUID;
  class_id UUID;
  teacher_user_id UUID;
  d DATE;
  day_count INT := 0;
  status TEXT;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_id FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;

  IF term_id IS NULL OR class_id IS NULL THEN RETURN; END IF;

  d := CURRENT_DATE - INTERVAL '45 days';
  WHILE d <= CURRENT_DATE AND day_count < 35 LOOP
    -- Skip weekends
    IF EXTRACT(DOW FROM d) NOT IN (0, 6) THEN
      -- 85% present, 8% late, 5% absent, 2% excused
      IF random() < 0.85 THEN status := 'present';
      ELSIF random() < 0.6 THEN status := 'late';
      ELSIF random() < 0.7 THEN status := 'excused';
      ELSE status := 'absent';
      END IF;

      INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
      VALUES ('b0000000-0000-0000-0000-000000000001', class_id, d, status, teacher_user_id, term_id)
      ON CONFLICT DO NOTHING;

      -- Also for Amara (younger child)
      IF random() < 0.90 THEN status := 'present';
      ELSIF random() < 0.5 THEN status := 'late';
      ELSE status := 'absent';
      END IF;

      INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
      VALUES ('b0000000-0000-0000-0000-000000000002',
        (SELECT c2.id FROM classes c2 WHERE c2.name = 'Primary 1A' LIMIT 1),
        d, status, teacher_user_id, term_id)
      ON CONFLICT DO NOTHING;

      day_count := day_count + 1;
    END IF;
    d := d + 1;
  END LOOP;
END $$;

-- ─── Assessments and Grades for Chidi ────────────────────────────────
DO $$
DECLARE
  term_id UUID;
  class_id UUID;
  teacher_user_id UUID;
  math_id UUID;
  eng_id UUID;
  sci_id UUID;
  assess_id UUID;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_id FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;
  SELECT s.id INTO math_id FROM subjects s WHERE s.name = 'Mathematics' LIMIT 1;
  SELECT s.id INTO eng_id FROM subjects s WHERE s.name = 'English Language' LIMIT 1;
  SELECT s.id INTO sci_id FROM subjects s WHERE s.name = 'Basic Science' LIMIT 1;

  IF term_id IS NULL OR class_id IS NULL THEN RETURN; END IF;

  -- Mathematics assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000001', class_id, math_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 30, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000002', class_id, math_id, term_id, 'CA Test 2', 20, 10, CURRENT_DATE - 15, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000003', class_id, math_id, term_id, 'Mid-Term Exam', 60, 30, CURRENT_DATE - 7, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- English assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000004', class_id, eng_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 28, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000005', class_id, eng_id, term_id, 'Essay Writing', 20, 10, CURRENT_DATE - 14, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000006', class_id, eng_id, term_id, 'Mid-Term Exam', 60, 30, CURRENT_DATE - 7, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Science assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000007', class_id, sci_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 25, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000008', class_id, sci_id, term_id, 'Lab Project', 20, 10, CURRENT_DATE - 12, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Grades for Chidi
  INSERT INTO grades (student_id, assessment_id, score, remarks, entered_by)
  VALUES
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 17, 'Excellent work', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000002', 15, 'Good improvement', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', 48, 'Strong performance', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004', 14, NULL, teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000005', 16, 'Creative writing', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000006', 42, NULL, teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000007', 18, 'Top of class', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000008', 16, NULL, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Some class-average grades (other students in same class)
  -- Simulated with 3 other "virtual" students to create class averages
  FOR i IN 1..3 LOOP
    INSERT INTO grades (student_id, assessment_id, score, entered_by)
    SELECT 
      gen_random_uuid(), -- virtual student (won't be linked to a real student)
      a.id,
      FLOOR(a.max_score * (0.45 + random() * 0.4)), -- 45-85% range
      teacher_user_id
    FROM assessments a
    WHERE a.class_id = class_id AND a.term_id = term_id
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;

-- ─── Fee Accounts ────────────────────────────────────────────────────
DO $$
DECLARE
  school_id UUID;
  year_id UUID;
  term_id UUID;
  fee_struct_id UUID;
BEGIN
  SELECT s.id INTO school_id FROM schools s LIMIT 1;
  SELECT ay.id INTO year_id FROM academic_years ay WHERE ay.is_current = true LIMIT 1;
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;

  IF school_id IS NULL OR year_id IS NULL THEN RETURN; END IF;

  -- Create fee structure
  INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, name, total_amount, due_date)
  VALUES
    ('e0000000-0000-0000-0000-000000000001', school_id, year_id, term_id,
     'First Term Fees 2025/2026', 185000, CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  fee_struct_id := 'e0000000-0000-0000-0000-000000000001';

  -- Fee account for Chidi (partially paid)
  INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, balance, status, due_date)
  VALUES
    ('f0000000-0000-0000-0000-000000000001',
     'b0000000-0000-0000-0000-000000000001',
     fee_struct_id, 185000, 120000, 65000, 'partial',
     CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  -- Fee account for Amara (fully paid)
  INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, balance, status, due_date)
  VALUES
    ('f0000000-0000-0000-0000-000000000002',
     'b0000000-0000-0000-0000-000000000002',
     fee_struct_id, 150000, 150000, 0, 'paid',
     CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  -- Payment transactions
  INSERT INTO payment_transactions (fee_account_id, amount, payment_method, payment_reference, status, receipt_number, paid_by)
  VALUES
    ('f0000000-0000-0000-0000-000000000001', 80000, 'bank_transfer', 'PAY-2025-001', 'success', 'RCT-001',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1)),
    ('f0000000-0000-0000-0000-000000000001', 40000, 'card', 'PAY-2025-002', 'success', 'RCT-002',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1)),
    ('f0000000-0000-0000-0000-000000000002', 150000, 'bank_transfer', 'PAY-2025-003', 'success', 'RCT-003',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1))
  ON CONFLICT DO NOTHING;
END $$;

-- ─── Student Feedback ────────────────────────────────────────────────
INSERT INTO student_feedback (student_id, teacher_id, feedback_type, category, description)
VALUES
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'positive',
   'Chidi showed excellent leadership during the group mathematics project. He helped his teammates understand fractions and was very patient with those who were struggling.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'academic', 'positive',
   'Outstanding performance in the mid-term mathematics exam. Chidi scored the highest in the class.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'concern',
   'Chidi was talking during assembly today. He has been warned to pay attention during school events.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'academic', 'neutral',
   'English essay showed good ideas but needs improvement in grammar and punctuation. Recommend extra practice with writing exercises at home.'),
  ('b0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'positive',
   'Amara is very well-behaved and always eager to participate in class activities. She is a joy to teach.')
ON CONFLICT DO NOTHING;

-- ─── Announcements ────────────────────────────────────────────────────
INSERT INTO announcements (school_id, title, content, priority, target_roles, status, published_by, published_at)
VALUES
  ((SELECT id FROM schools LIMIT 1),
   'Second Term Resumption Date',
   'Dear Parents, please be informed that the second term will commence on Monday, 13th January 2026. All students are expected to resume promptly by 8:00 AM. Please ensure all outstanding fees are settled before resumption. School uniforms must be clean and complete. Thank you for your cooperation.',
   'high',
   ARRAY['parent', 'teacher']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '3 days'),

  ((SELECT id FROM schools LIMIT 1),
   'Inter-House Sports Competition',
   'The annual inter-house sports competition will take place on Friday, 24th January 2026 at the school sports field. Events include: 100m dash, long jump, sack race, relay, and tug of war. Parents are welcome to attend and cheer on their children. Please ensure your child wears their house colour t-shirt. Refreshments will be available.',
   'normal',
   ARRAY['parent', 'teacher']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '1 day'),

  ((SELECT id FROM schools LIMIT 1),
   'PTA Meeting Notice',
   'A Parents-Teachers Association meeting is scheduled for Saturday, 18th January 2026 at 10:00 AM in the school hall. Key agenda items include: review of first term academic performance, second term plans and activities, school infrastructure improvements, and fee payment schedule discussion. Your attendance is highly encouraged.',
   'normal',
   ARRAY['parent']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '5 hours'),

  ((SELECT id FROM schools LIMIT 1),
   'Important: Updated School Drop-off Policy',
   'For the safety of all students, we are implementing a new drop-off and pick-up policy effective immediately. Parents must not drive beyond the school gate. A supervised drop-off zone has been designated at the front parking area. School buses will use the side entrance. Please cooperate with security personnel.',
   'urgent',
   ARRAY['parent']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '12 hours')
ON CONFLICT DO NOTHING;

-- ─── Notifications ───────────────────────────────────────────────────
INSERT INTO notifications (recipient_id, title, body, type, channel)
VALUES
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'New Grade Posted', 'Mid-Term Mathematics exam grades have been posted for Chidi.', 'grade_posted', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Fee Payment Reminder', 'Outstanding balance of ₦65,000 for Chidi. Please settle before the deadline.', 'fee_reminder', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'New Announcement', 'Important: Updated School Drop-off Policy', 'announcement', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Teacher Feedback', 'New feedback from Mrs. Adeyemi for Chidi regarding classroom behaviour.', 'feedback', 'in_app')
ON CONFLICT DO NOTHING;


-- ============================================================================
-- Migration: 011_sprint5_teacher_data.sql
-- ============================================================================

-- ============================================================================
-- Sprint 5 Seed Data: Teacher Assignments & Additional Students
-- Run AFTER 010_sprint3_seed_data.sql
-- ============================================================================

-- ─── Teacher Assignments (link teacher to classes + subjects) ──────────
DO $$
DECLARE
  teacher_id UUID;
  year_id UUID;
  math_id UUID;
  eng_id UUID;
  sci_id UUID;
  class_p4b UUID;
  class_p1a UUID;
BEGIN
  SELECT t.id INTO teacher_id FROM teachers t WHERE t.staff_id = 'TCH-001' LIMIT 1;
  SELECT ay.id INTO year_id FROM academic_years ay WHERE ay.is_current = true LIMIT 1;
  SELECT s.id INTO math_id FROM subjects s WHERE s.name = 'Mathematics' LIMIT 1;
  SELECT s.id INTO eng_id FROM subjects s WHERE s.name = 'English Language' LIMIT 1;
  SELECT s.id INTO sci_id FROM subjects s WHERE s.name = 'Basic Science' LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT c.id INTO class_p1a FROM classes c WHERE c.name = 'Primary 1A' LIMIT 1;

  IF teacher_id IS NULL OR year_id IS NULL THEN RETURN; END IF;

  -- Teacher is CLASS TEACHER of Primary 4B
  INSERT INTO teacher_assignments (teacher_id, class_id, subject_id, is_class_teacher, academic_year_id)
  VALUES
    (teacher_id, class_p4b, math_id, true,  year_id),
    (teacher_id, class_p4b, eng_id,  false, year_id),
    (teacher_id, class_p4b, sci_id,  false, year_id),
    (teacher_id, class_p1a, math_id, false, year_id)
  ON CONFLICT DO NOTHING;
END $$;

-- ─── Additional Students in Primary 4B (for realistic attendance/grades) ──
DO $$
DECLARE
  school_id UUID;
  class_p4b UUID;
  names TEXT[][] := ARRAY[
    ARRAY['Adaeze',  'Nwankwo',  'female'],
    ARRAY['Emeka',   'Chukwuma', 'male'],
    ARRAY['Fatima',  'Bello',    'female'],
    ARRAY['Ikenna',  'Obi',      'male'],
    ARRAY['Ngozi',   'Eze',      'female'],
    ARRAY['Olumide', 'Adebayo',  'male'],
    ARRAY['Sade',    'Ogundimu', 'female'],
    ARRAY['Tunde',   'Bakare',   'male'],
    ARRAY['Yetunde', 'Afolabi',  'female'],
    ARRAY['Chisom',  'Okeke',    'female'],
    ARRAY['Damilola','Olatunji', 'male'],
    ARRAY['Kelechi', 'Onu',      'male']
  ];
  i INT;
  dob DATE;
BEGIN
  SELECT s.id INTO school_id FROM schools s LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;

  IF school_id IS NULL OR class_p4b IS NULL THEN RETURN; END IF;

  FOR i IN 1..array_length(names, 1) LOOP
    dob := '2014-01-01'::DATE + (random() * 730)::INT; -- Random DOB 2014-2016
    INSERT INTO students (school_id, admission_number, first_name, last_name, gender, date_of_birth, class_id, is_active, admission_date)
    VALUES (
      school_id,
      'BFA-2025-' || LPAD((100 + i)::TEXT, 3, '0'),
      names[i][1],
      names[i][2],
      names[i][3]::gender_type,
      dob,
      class_p4b,
      true,
      '2023-09-01'
    )
    ON CONFLICT (admission_number) DO NOTHING;
  END LOOP;
END $$;

-- ─── Generate attendance for all Primary 4B students (today not yet marked) ──
-- This ensures the teacher has students to mark attendance for
DO $$
DECLARE
  term_id UUID;
  class_p4b UUID;
  teacher_user_id UUID;
  s RECORD;
  d DATE;
  day_count INT;
  status TEXT;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;

  IF term_id IS NULL OR class_p4b IS NULL THEN RETURN; END IF;

  -- For each student in class (except Chidi who already has attendance)
  FOR s IN
    SELECT st.id FROM students st
    WHERE st.class_id = class_p4b
      AND st.admission_number != 'BFA-2025-001'
      AND st.is_active = true
  LOOP
    d := CURRENT_DATE - INTERVAL '30 days';
    day_count := 0;
    WHILE d < CURRENT_DATE AND day_count < 22 LOOP
      IF EXTRACT(DOW FROM d) NOT IN (0, 6) THEN
        IF random() < 0.88 THEN status := 'present';
        ELSIF random() < 0.5 THEN status := 'late';
        ELSIF random() < 0.6 THEN status := 'excused';
        ELSE status := 'absent';
        END IF;

        INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
        VALUES (s.id, class_p4b, d, status, teacher_user_id, term_id)
        ON CONFLICT DO NOTHING;

        day_count := day_count + 1;
      END IF;
      d := d + 1;
    END LOOP;
  END LOOP;
END $$;


-- ============================================================================
-- Migration: 012_fixup_feedback_schema.sql
-- ============================================================================

-- ============================================================================
-- Schema Fixup: Align student_feedback with application code
-- The original schema (002) used different column names than what the
-- application code and seed data expect. This migration reconciles them.
-- ============================================================================

-- Add missing columns that the app code expects
ALTER TABLE student_feedback
  ADD COLUMN IF NOT EXISTS feedback_type VARCHAR(50) DEFAULT 'academic',
  ADD COLUMN IF NOT EXISTS description TEXT;

-- Migrate existing data: copy content → description if content exists
UPDATE student_feedback SET description = content WHERE description IS NULL AND content IS NOT NULL;

-- Make term_id optional (feedback can be submitted without selecting a term)
ALTER TABLE student_feedback ALTER COLUMN term_id DROP NOT NULL;


-- ============================================================================
-- Migration: 013_sprint6_fee_data.sql
-- ============================================================================

-- ========================================================================
-- Sprint 6-7 Seed Data: Fee Types, Fee Structures, Student Fee Accounts
-- ========================================================================

-- Fee Types for the school
INSERT INTO fee_types (id, school_id, name, description, is_recurring) VALUES
  ('ft-tuition-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Tuition Fee', 'Core academic tuition fee', true),
  ('ft-develop-0001-0001-000000000002'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Development Levy', 'School development and infrastructure', true),
  ('ft-sports--0001-0001-000000000003'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Sports Fee', 'Sports and physical education activities', true),
  ('ft-techno--0001-0001-000000000004'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Technology Fee', 'ICT lab and computer resources', true),
  ('ft-examin--0001-0001-000000000005'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Examination Fee', 'Examination materials and administration', true),
  ('ft-unifrm--0001-0001-000000000006'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Uniform Fee', 'School uniforms and PE kits', false),
  ('ft-textbk--0001-0001-000000000007'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Textbook Fee', 'Required textbooks and workbooks', false);

-- Fee Structure for Primary 4B, Second Term 2025/2026
INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, class_id, name, total_amount, due_date) VALUES
  ('fs-p4b-t2-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   (SELECT id FROM academic_years WHERE is_current = true LIMIT 1),
   (SELECT id FROM terms WHERE is_current = true LIMIT 1),
   (SELECT id FROM classes WHERE name = 'Primary 4B' LIMIT 1),
   'Primary 4B - Second Term Fees',
   185000.00,
   '2026-01-20');

-- Fee Structure Items (breakdown of the ₦185,000)
INSERT INTO fee_structure_items (fee_structure_id, fee_type_id, amount) VALUES
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-tuition-0001-0001-000000000001'::uuid, 120000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-develop-0001-0001-000000000002'::uuid, 25000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-sports--0001-0001-000000000003'::uuid, 10000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-techno--0001-0001-000000000004'::uuid, 15000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-examin--0001-0001-000000000005'::uuid, 15000.00);

-- Fee Structure for Primary 1A, Second Term 2025/2026
INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, class_id, name, total_amount, due_date) VALUES
  ('fs-p1a-t2-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   (SELECT id FROM academic_years WHERE is_current = true LIMIT 1),
   (SELECT id FROM terms WHERE is_current = true LIMIT 1),
   (SELECT id FROM classes WHERE name = 'Primary 1A' LIMIT 1),
   'Primary 1A - Second Term Fees',
   150000.00,
   '2026-01-20');

INSERT INTO fee_structure_items (fee_structure_id, fee_type_id, amount) VALUES
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-tuition-0001-0001-000000000001'::uuid, 100000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-develop-0001-0001-000000000002'::uuid, 20000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-sports--0001-0001-000000000003'::uuid, 10000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-techno--0001-0001-000000000004'::uuid, 10000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-examin--0001-0001-000000000005'::uuid, 10000.00);

-- Student Fee Accounts for ALL students in Primary 4B
-- Chidi Okafor (parent's child) — partially paid
INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, status, due_date)
SELECT
  'sfa-chidi-0001-0001-000000000001'::uuid,
  s.id,
  'fs-p4b-t2-0001-0001-000000000001'::uuid,
  185000.00,
  120000.00,
  'partial',
  '2026-01-20'
FROM students s WHERE s.admission_number = 'BFA/2024/001';

-- Remaining Primary 4B students — various payment states
INSERT INTO student_fee_accounts (student_id, fee_structure_id, total_amount, amount_paid, status, due_date)
SELECT
  s.id,
  'fs-p4b-t2-0001-0001-000000000001'::uuid,
  185000.00,
  CASE
    WHEN s.first_name IN ('Adaeze', 'Emeka', 'Fatima') THEN 185000.00  -- fully paid
    WHEN s.first_name IN ('Ikenna', 'Ngozi') THEN 100000.00            -- partial
    WHEN s.first_name IN ('Olumide', 'Sade') THEN 50000.00             -- partial
    ELSE 0.00                                                            -- unpaid
  END,
  CASE
    WHEN s.first_name IN ('Adaeze', 'Emeka', 'Fatima') THEN 'paid'::fee_account_status
    WHEN s.first_name IN ('Ikenna', 'Ngozi', 'Olumide', 'Sade') THEN 'partial'::fee_account_status
    WHEN s.first_name IN ('Tunde', 'Yetunde', 'Chisom', 'Damilola', 'Kelechi') THEN 'overdue'::fee_account_status
    ELSE 'current'::fee_account_status
  END,
  '2026-01-20'
FROM students s
JOIN classes c ON s.class_id = c.id
WHERE c.name = 'Primary 4B'
  AND s.admission_number != 'BFA/2024/001';

-- Sample payment transaction for Chidi's partial payment
INSERT INTO payment_transactions (
  fee_account_id, amount, payment_method, payment_reference,
  gateway_reference, status, paid_by, receipt_number, metadata
)
SELECT
  'sfa-chidi-0001-0001-000000000001'::uuid,
  120000.00,
  'card'::payment_method,
  'PAY-' || substr(md5(random()::text), 1, 12),
  'PSTK_' || substr(md5(random()::text), 1, 16),
  'success'::payment_status,
  u.id,
  'RCP-2026-00001',
  '{"channel": "paystack", "card_type": "visa", "last4": "4081"}'::jsonb
FROM users u WHERE u.email = 'parent@brightfuture.ng';

-- Sample payment for Adaeze (fully paid)
INSERT INTO payment_transactions (
  fee_account_id, amount, payment_method, payment_reference,
  gateway_reference, status, paid_by, receipt_number
)
SELECT
  sfa.id,
  185000.00,
  'bank_transfer'::payment_method,
  'PAY-' || substr(md5(random()::text), 1, 12),
  'PSTK_' || substr(md5(random()::text), 1, 16),
  'success'::payment_status,
  (SELECT id FROM users WHERE role = 'finance' LIMIT 1),
  'RCP-2026-00002'
FROM student_fee_accounts sfa
JOIN students s ON sfa.student_id = s.id
WHERE s.first_name = 'Adaeze' AND sfa.fee_structure_id = 'fs-p4b-t2-0001-0001-000000000001'::uuid
LIMIT 1;


-- ============================================================================
-- Migration: 014_sprint8_communication.sql
-- ============================================================================

-- ============================================================================
-- Sprint 8: Communication & Reports
-- Fixes schema, extends announcements, adds delivery tracking
-- ============================================================================

-- Fix: Rename target_audience → target_roles (user_role array) if needed
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_audience'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_roles'
  ) THEN
    ALTER TABLE announcements RENAME COLUMN target_audience TO target_roles;
    ALTER TABLE announcements ALTER COLUMN target_roles TYPE user_role[] USING target_roles::user_role[];
  END IF;
  
  -- Add target_roles if neither exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_roles'
  ) THEN
    ALTER TABLE announcements ADD COLUMN target_roles user_role[] DEFAULT ARRAY['parent','teacher']::user_role[];
  END IF;
END$$;

-- Fix: Add published_by column (separate from created_by) if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'published_by'
  ) THEN
    ALTER TABLE announcements ADD COLUMN published_by UUID REFERENCES users(id);
    -- Copy created_by to published_by
    UPDATE announcements SET published_by = created_by WHERE published_by IS NULL;
  END IF;
END$$;

-- Add delivery_channels column if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'delivery_channels'
  ) THEN
    ALTER TABLE announcements ADD COLUMN delivery_channels TEXT[] DEFAULT ARRAY['in_app'];
  END IF;
END$$;

-- Add target_classes column if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_classes'
  ) THEN
    ALTER TABLE announcements ADD COLUMN target_classes UUID[];
  END IF;
END$$;

-- Add scheduled_at column for future-dated announcements
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'scheduled_at'
  ) THEN
    ALTER TABLE announcements ADD COLUMN scheduled_at TIMESTAMPTZ;
  END IF;
END$$;

-- Announcement delivery tracking — one row per recipient per channel
CREATE TABLE IF NOT EXISTS announcement_deliveries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  announcement_id UUID NOT NULL REFERENCES announcements(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel TEXT NOT NULL DEFAULT 'in_app',         -- in_app, whatsapp, sms, email
  status TEXT NOT NULL DEFAULT 'pending',          -- pending, sent, delivered, failed
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_delivery_announcement ON announcement_deliveries(announcement_id);
CREATE INDEX IF NOT EXISTS idx_delivery_recipient ON announcement_deliveries(recipient_id);
CREATE INDEX IF NOT EXISTS idx_delivery_status ON announcement_deliveries(status);

-- ─── Seed: update existing announcements with delivery_channels ────────
UPDATE announcements
SET delivery_channels = ARRAY['in_app']
WHERE delivery_channels IS NULL;

-- ─── Additional sample announcements for testing ───────────────────────
INSERT INTO announcements (
  school_id, title, content, priority, target_roles, status,
  delivery_channels, published_by, published_at
)
VALUES
  (
    (SELECT id FROM schools LIMIT 1),
    'PTA Meeting — February 2026',
    'Dear Parents, the Parent-Teacher Association meeting for this term will hold on Saturday, 22nd February 2026 at 10:00 AM in the school hall. Agenda includes: academic progress review, upcoming events, and fee structure discussion for next session. Attendance is strongly encouraged. Light refreshments will be served.',
    'high',
    ARRAY['parent']::user_role[],
    'published',
    ARRAY['in_app', 'sms'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NOW() - INTERVAL '2 hours'
  ),
  (
    (SELECT id FROM schools LIMIT 1),
    'Staff Professional Development Day',
    'All teaching staff are required to attend the professional development workshop on Friday, 28th February 2026. Topic: "Effective Use of Technology in the Classroom". The session will run from 9:00 AM to 3:00 PM. Lunch will be provided. Students will have a free day.',
    'normal',
    ARRAY['teacher']::user_role[],
    'published',
    ARRAY['in_app'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NOW() - INTERVAL '6 hours'
  ),
  (
    (SELECT id FROM schools LIMIT 1),
    'Mid-Term Break Notice',
    'Please be informed that the mid-term break will be from Monday 3rd March to Friday 7th March 2026. Students resume on Monday 10th March. Please ensure your children revise their class notes during the break.',
    'normal',
    ARRAY['parent', 'teacher']::user_role[],
    'draft',
    ARRAY['in_app', 'whatsapp', 'sms'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NULL
  )
ON CONFLICT DO NOTHING;


-- ============================================================================
-- Migration: 015_sprint8_notification_seed.sql
-- ============================================================================

-- ============================================================================
-- Sprint 8: Notification Seed Data
-- Sample notifications for testing the notification bell and notifications page
-- ============================================================================

-- Insert sample notifications for parent users
INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at
)
SELECT
  u.id,
  u.school_id,
  'announcement',
  'PTA Meeting — February 2026',
  'The Parent-Teacher Association meeting for this term will hold on Saturday, 22nd February 2026 at 10:00 AM in the school hall.',
  '{"announcement_id": "pta-meeting"}'::jsonb,
  ARRAY['in_app'],
  NULL -- unread
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'fee_reminder',
  'School Fees Reminder',
  'This is a reminder that your child''s school fees for the Second Term are due. Please make payment at your earliest convenience to avoid disruption.',
  '{}'::jsonb,
  ARRAY['in_app', 'sms'],
  NULL, -- unread
  NOW() - INTERVAL '2 days'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'attendance_alert',
  'Absence Alert: Your Child Was Absent Today',
  'Your child was marked absent from school today. If this absence is excused, please contact the class teacher.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NOW() - INTERVAL '1 day', -- read
  NOW() - INTERVAL '3 days'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 3;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'grade_posted',
  'New Grades Posted: Mathematics',
  'New assessment grades have been posted for Mathematics. Log in to view your child''s performance.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NULL, -- unread
  NOW() - INTERVAL '5 hours'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

-- Insert sample notifications for teacher users
INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at
)
SELECT
  u.id,
  u.school_id,
  'announcement',
  'Staff Professional Development Day',
  'All teaching staff are required to attend the professional development workshop on Friday, 28th February 2026.',
  '{"announcement_id": "staff-pd"}'::jsonb,
  ARRAY['in_app'],
  NULL
FROM users u WHERE u.role = 'teacher' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'feedback',
  'Grade Submission Reminder',
  'Please submit all grades for Second Term assessments by Friday. Navigate to your class page to enter grades.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NOW() - INTERVAL '12 hours', -- read
  NOW() - INTERVAL '2 days'
FROM users u WHERE u.role = 'teacher' AND u.is_active = true
LIMIT 3;


-- ============================================================================
-- Migration: 016_sprint9_teacher_leave.sql
-- ============================================================================

-- ============================================================================
-- Sprint 9–10: Teacher Attendance & Leave Management
-- ============================================================================

-- ─── Teacher Attendance (daily check-in / check-out) ──────────────────
CREATE TABLE IF NOT EXISTS teacher_attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  check_in TIMESTAMPTZ,
  check_out TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'present',  -- present, absent, late, excused, half_day
  notes TEXT,
  marked_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(teacher_id, date)
);

CREATE INDEX idx_teacher_att_date ON teacher_attendance(school_id, date);
CREATE INDEX idx_teacher_att_teacher ON teacher_attendance(teacher_id, date);

-- ─── Leave Requests ───────────────────────────────────────────────────
CREATE TYPE leave_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');

CREATE TABLE IF NOT EXISTS leave_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  leave_type TEXT NOT NULL DEFAULT 'personal',  -- sick, personal, annual, maternity, compassionate, study
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days_count INT NOT NULL DEFAULT 1,
  reason TEXT NOT NULL,
  status leave_status NOT NULL DEFAULT 'pending',
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_leave_teacher ON leave_requests(teacher_id);
CREATE INDEX idx_leave_status ON leave_requests(school_id, status);
CREATE INDEX idx_leave_dates ON leave_requests(start_date, end_date);

-- ─── Seed: Teacher attendance (last 10 school days) ───────────────────
INSERT INTO teacher_attendance (school_id, teacher_id, date, check_in, status, marked_by)
SELECT
  t2.school_id,
  t.id,
  d::date,
  (d + TIME '07:45:00')::timestamptz + (random() * INTERVAL '30 minutes'),
  CASE
    WHEN random() < 0.85 THEN 'present'
    WHEN random() < 0.92 THEN 'late'
    WHEN random() < 0.97 THEN 'absent'
    ELSE 'excused'
  END,
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1)
FROM teachers t
JOIN users t2 ON t.user_id = t2.id
CROSS JOIN generate_series(
  CURRENT_DATE - INTERVAL '13 days',
  CURRENT_DATE - INTERVAL '1 day',
  '1 day'
) d
WHERE EXTRACT(DOW FROM d) NOT IN (0, 6) -- skip weekends
ON CONFLICT (teacher_id, date) DO NOTHING;

-- ─── Seed: Sample leave requests ──────────────────────────────────────
INSERT INTO leave_requests (school_id, teacher_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by, reviewed_at)
SELECT
  u.school_id,
  t.id,
  'sick',
  CURRENT_DATE + INTERVAL '5 days',
  CURRENT_DATE + INTERVAL '6 days',
  2,
  'Feeling unwell, need to see the doctor and rest.',
  'pending',
  NULL,
  NULL
FROM teachers t
JOIN users u ON t.user_id = u.id
LIMIT 1;

INSERT INTO leave_requests (school_id, teacher_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by, reviewed_at)
SELECT
  u.school_id,
  t.id,
  'personal',
  CURRENT_DATE - INTERVAL '10 days',
  CURRENT_DATE - INTERVAL '9 days',
  2,
  'Family event — wedding ceremony.',
  'approved',
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1),
  NOW() - INTERVAL '15 days'
FROM teachers t
JOIN users u ON t.user_id = u.id
OFFSET 1 LIMIT 1;

-- ─── Seed: Sample disciplinary incidents ──────────────────────────────
INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'teacher' LIMIT 1),
  'minor',
  'resolved',
  'Late Coming',
  'Student arrived 30 minutes late to school without prior notice. This is the second occurrence this term.',
  'Verbal warning given. Parents contacted to discuss punctuality.',
  true
FROM students s WHERE s.is_active = true
LIMIT 1;

INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'teacher' LIMIT 1),
  'moderate',
  'investigating',
  'Disruptive Behaviour',
  'Student was repeatedly disruptive during English class, talking out of turn and distracting other students despite multiple warnings.',
  NULL,
  false
FROM students s WHERE s.is_active = true
OFFSET 2 LIMIT 1;

INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified, follow_up_date
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1),
  'major',
  'reported',
  'Bullying',
  'Student was reported by classmates for persistent intimidation and name-calling of a younger student during break time.',
  NULL,
  false,
  CURRENT_DATE + INTERVAL '3 days'
FROM students s WHERE s.is_active = true
OFFSET 4 LIMIT 1;


-- ============================================================================
-- Migration: 017_sprint11_payroll_plans.sql
-- ============================================================================

-- ============================================================================
-- Sprint 11–12: Payroll Seed Data & Payment Plans
-- ============================================================================

-- Add unique constraint on salary_structures for upsert support
DO $$ BEGIN
  ALTER TABLE salary_structures ADD CONSTRAINT uq_salary_school_teacher UNIQUE (school_id, teacher_id);
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;

-- ─── Payment Plans table ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payment_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_account_id UUID NOT NULL REFERENCES student_fee_accounts(id) ON DELETE CASCADE,
  total_amount NUMERIC(12,2) NOT NULL,
  installments INT NOT NULL DEFAULT 3,
  amount_per_installment NUMERIC(12,2) NOT NULL,
  start_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',  -- active, completed, defaulted, cancelled
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_plan_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plan_id UUID NOT NULL REFERENCES payment_plans(id) ON DELETE CASCADE,
  installment_number INT NOT NULL,
  due_date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  paid BOOLEAN DEFAULT FALSE,
  paid_at TIMESTAMPTZ,
  transaction_id UUID REFERENCES payment_transactions(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_payment_plans_account ON payment_plans(fee_account_id);
CREATE INDEX idx_plan_items_plan ON payment_plan_items(plan_id);
CREATE INDEX idx_plan_items_due ON payment_plan_items(due_date, paid);

-- ─── Seed: Salary structures for all teachers ────────────────────────
INSERT INTO salary_structures (school_id, teacher_id, basic_salary, housing_allowance, transport_allowance, meal_allowance, effective_date)
SELECT
  u.school_id,
  t.id,
  CASE
    WHEN t.qualification ILIKE '%PhD%' OR t.qualification ILIKE '%Doctor%' THEN 250000
    WHEN t.qualification ILIKE '%M.Ed%' OR t.qualification ILIKE '%M.Sc%' OR t.qualification ILIKE '%Master%' THEN 200000
    ELSE 150000
  END AS basic_salary,
  CASE
    WHEN t.qualification ILIKE '%PhD%' OR t.qualification ILIKE '%Doctor%' THEN 50000
    WHEN t.qualification ILIKE '%M.Ed%' OR t.qualification ILIKE '%M.Sc%' OR t.qualification ILIKE '%Master%' THEN 40000
    ELSE 30000
  END AS housing_allowance,
  15000 AS transport_allowance,
  10000 AS meal_allowance,
  '2025-09-01'::date
FROM teachers t
JOIN users u ON t.user_id = u.id
WHERE u.is_active = true
ON CONFLICT DO NOTHING;

-- ─── Seed: A completed payroll run for last month ─────────────────────
INSERT INTO payroll_runs (school_id, month, year, status, processed_by, processed_at)
SELECT
  u.school_id,
  EXTRACT(MONTH FROM CURRENT_DATE - INTERVAL '1 month')::int,
  EXTRACT(YEAR FROM CURRENT_DATE - INTERVAL '1 month')::int,
  'approved',
  u.id,
  NOW() - INTERVAL '5 days'
FROM users u WHERE u.role = 'finance' LIMIT 1
ON CONFLICT (school_id, month, year) DO NOTHING;

-- ─── Seed: Payslips for last month's run ──────────────────────────────
INSERT INTO payslips (payroll_run_id, teacher_id, gross_salary, tax_paye, pension, nhf, other_deductions, net_salary, bank_name, account_number)
SELECT
  pr.id,
  ss.teacher_id,
  ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance AS gross,
  -- Approximate PAYE (simplified)
  GREATEST(0, ROUND(
    CASE
      WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 300000 THEN
        (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 * 0.07 / 12
      WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 600000 THEN
        (300000 * 0.07 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 300000) * 0.11) / 12
      ELSE
        (300000 * 0.07 + 300000 * 0.11 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 600000) * 0.15) / 12
    END, 2)) AS tax_paye,
  -- Pension: 8% employee contribution
  ROUND(ss.basic_salary * 0.08, 2) AS pension,
  -- NHF: 2.5% of basic
  ROUND(ss.basic_salary * 0.025, 2) AS nhf,
  0 AS other_deductions,
  -- Net (computed later)
  (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance)
    - GREATEST(0, ROUND(
        CASE
          WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 300000 THEN
            (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 * 0.07 / 12
          WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 600000 THEN
            (300000 * 0.07 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 300000) * 0.11) / 12
          ELSE
            (300000 * 0.07 + 300000 * 0.11 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 600000) * 0.15) / 12
        END, 2))
    - ROUND(ss.basic_salary * 0.08, 2)
    - ROUND(ss.basic_salary * 0.025, 2) AS net_salary,
  (ARRAY['GTBank', 'Zenith Bank', 'First Bank', 'Access Bank', 'UBA'])[FLOOR(random() * 5 + 1)] AS bank_name,
  LPAD(FLOOR(random() * 9000000000 + 1000000000)::text, 10, '0') AS account_number
FROM salary_structures ss
CROSS JOIN payroll_runs pr
WHERE pr.status = 'approved'
ON CONFLICT (payroll_run_id, teacher_id) DO NOTHING;

-- ─── Seed: A sample payment plan ─────────────────────────────────────
DO $$
DECLARE
  v_account_id UUID;
  v_plan_id UUID;
  v_user_id UUID;
  v_balance NUMERIC;
BEGIN
  SELECT id, balance INTO v_account_id, v_balance
  FROM student_fee_accounts
  WHERE status IN ('current', 'overdue', 'partial') AND balance > 0
  LIMIT 1;

  SELECT id INTO v_user_id FROM users WHERE role = 'finance' LIMIT 1;

  IF v_account_id IS NOT NULL AND v_balance > 0 THEN
    INSERT INTO payment_plans (fee_account_id, total_amount, installments, amount_per_installment, start_date, status, created_by)
    VALUES (v_account_id, v_balance, 3, ROUND(v_balance / 3, 2), CURRENT_DATE, 'active', v_user_id)
    RETURNING id INTO v_plan_id;

    INSERT INTO payment_plan_items (plan_id, installment_number, due_date, amount) VALUES
      (v_plan_id, 1, CURRENT_DATE + INTERVAL '7 days', ROUND(v_balance / 3, 2)),
      (v_plan_id, 2, CURRENT_DATE + INTERVAL '37 days', ROUND(v_balance / 3, 2)),
      (v_plan_id, 3, CURRENT_DATE + INTERVAL '67 days', v_balance - 2 * ROUND(v_balance / 3, 2));
  END IF;
END $$;


-- ============================================================================
-- Migration: 018_sprint13_timetable_messages.sql
-- ============================================================================

-- ============================================================================
-- Sprint 13–15: Timetable, Messaging, Fee Reminders
-- ============================================================================

-- ─── Timetable ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS timetable_slots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id UUID REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id UUID REFERENCES teachers(id) ON DELETE SET NULL,
  day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 1 AND 5), -- Mon=1..Fri=5
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  room VARCHAR(50),
  term_id UUID REFERENCES terms(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT no_overlap CHECK (end_time > start_time)
);

CREATE INDEX idx_timetable_class ON timetable_slots(class_id, day_of_week);
CREATE INDEX idx_timetable_teacher ON timetable_slots(teacher_id, day_of_week);

-- ─── Direct Messages (Parent ↔ Teacher) ──────────────────────────────
CREATE TABLE IF NOT EXISTS direct_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  thread_id UUID, -- group related messages
  subject VARCHAR(200),
  content TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dm_recipient ON direct_messages(recipient_id, read_at NULLS FIRST);
CREATE INDEX idx_dm_sender ON direct_messages(sender_id, created_at DESC);
CREATE INDEX idx_dm_thread ON direct_messages(thread_id, created_at);

-- ─── Fee Reminder Log ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fee_reminder_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_account_id UUID NOT NULL REFERENCES student_fee_accounts(id) ON DELETE CASCADE,
  channel TEXT NOT NULL, -- 'sms', 'whatsapp', 'email', 'push'
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'sent', -- sent, delivered, failed
  sent_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_reminder_account ON fee_reminder_logs(fee_account_id, sent_at DESC);

-- ─── Seed: Timetable slots for a class ───────────────────────────────
DO $$
DECLARE
  v_school_id UUID;
  v_class_id UUID;
  v_term_id UUID;
  v_subjects UUID[];
  v_teachers UUID[];
  v_day INT;
  v_slot_idx INT;
  v_periods TIME[][] := ARRAY[
    ARRAY['08:00'::time, '08:45'::time],
    ARRAY['08:45'::time, '09:30'::time],
    ARRAY['09:45'::time, '10:30'::time],
    ARRAY['10:30'::time, '11:15'::time],
    ARRAY['11:30'::time, '12:15'::time],
    ARRAY['12:15'::time, '13:00'::time]
  ];
BEGIN
  SELECT id INTO v_school_id FROM schools LIMIT 1;
  SELECT id INTO v_class_id FROM classes WHERE school_id = v_school_id LIMIT 1;
  SELECT id INTO v_term_id FROM terms WHERE status = 'current' LIMIT 1;

  IF v_term_id IS NULL THEN
    SELECT id INTO v_term_id FROM terms ORDER BY start_date DESC LIMIT 1;
  END IF;

  SELECT ARRAY_AGG(id) INTO v_subjects FROM subjects WHERE school_id = v_school_id LIMIT 6;
  SELECT ARRAY_AGG(id) INTO v_teachers FROM teachers LIMIT 6;

  IF v_class_id IS NOT NULL AND v_subjects IS NOT NULL AND array_length(v_subjects, 1) > 0 THEN
    FOR v_day IN 1..5 LOOP
      FOR v_slot_idx IN 1..6 LOOP
        INSERT INTO timetable_slots (school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, term_id)
        VALUES (
          v_school_id, v_class_id,
          v_subjects[((v_day + v_slot_idx) % array_length(v_subjects, 1)) + 1],
          CASE WHEN v_teachers IS NOT NULL AND array_length(v_teachers, 1) > 0
            THEN v_teachers[((v_day + v_slot_idx) % array_length(v_teachers, 1)) + 1]
            ELSE NULL END,
          v_day,
          v_periods[v_slot_idx][1],
          v_periods[v_slot_idx][2],
          v_term_id
        )
        ON CONFLICT DO NOTHING;
      END LOOP;
    END LOOP;
  END IF;
END $$;


-- ============================================================================
-- Migration complete. All tables, seed data, and indexes created.
-- ============================================================================
