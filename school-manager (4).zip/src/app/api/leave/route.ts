import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List leave requests ─────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user) return apiError("User not found", ErrorCodes.NOT_FOUND, 404);

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let query = supabase
      .from("leave_requests")
      .select(`id, leave_type, start_date, end_date, days_count, reason, status,
               review_notes, reviewed_at, created_at,
               teachers:teacher_id ( id, staff_id, users:user_id ( first_name, last_name ) ),
               reviewer:reviewed_by ( first_name, last_name )`)
      .eq("school_id", user.school_id)
      .order("created_at", { ascending: false });

    // Teachers only see their own
    if (user.role === "teacher") {
      const { data: teacher } = await supabase.from("teachers").select("id").eq("user_id", user.id).single();
      if (!teacher) return apiError("Teacher profile not found", ErrorCodes.NOT_FOUND, 404);
      query = query.eq("teacher_id", teacher.id);
    }

    if (status && status !== "all") query = query.eq("status", status);

    const { data: leaves, error } = await query;
    if (error) {
      console.error("Leave query error:", error);
      return apiError("Failed to fetch", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (leaves || []).map((l: Record<string, unknown>) => {
      const t = l.teachers as Record<string, unknown> | null;
      const tu = t?.users as Record<string, string> | null;
      const rev = l.reviewer as Record<string, string> | null;
      return {
        ...l,
        teachers: undefined,
        reviewer: undefined,
        teacher_id: t?.id,
        teacher_name: tu ? `${tu.first_name} ${tu.last_name}` : "Unknown",
        staff_id: t?.staff_id || "",
        reviewed_by_name: rev ? `${rev.first_name} ${rev.last_name}` : null,
      };
    });

    return apiSuccess({ leaves: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Create leave request (teacher) ─────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user) return apiError("User not found", ErrorCodes.NOT_FOUND, 404);

    const { data: teacher } = await supabase.from("teachers").select("id").eq("user_id", user.id).single();
    if (!teacher) return apiError("Teacher profile not found", ErrorCodes.NOT_FOUND, 404);

    const body = await request.json();
    const { leave_type, start_date, end_date, reason } = body;

    if (!leave_type || !start_date || !end_date || !reason) {
      return apiError("leave_type, start_date, end_date, and reason are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Calculate days
    const start = new Date(start_date);
    const end = new Date(end_date);
    const diffMs = end.getTime() - start.getTime();
    const days_count = Math.max(1, Math.ceil(diffMs / 86400000) + 1);

    const { data: leave, error } = await supabase
      .from("leave_requests")
      .insert({
        school_id: user.school_id,
        teacher_id: teacher.id,
        leave_type,
        start_date,
        end_date,
        days_count,
        reason,
      })
      .select("*")
      .single();

    if (error) {
      console.error("Create leave error:", error);
      return apiError("Failed to create", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(leave, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
