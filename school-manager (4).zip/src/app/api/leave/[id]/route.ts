import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

type Ctx = { params: Promise<{ id: string }> };

// ─── PUT: Review leave request (admin approve/reject) ─────────────────
export async function PUT(request: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { action, review_notes } = body as { action: "approved" | "rejected"; review_notes?: string };

    if (!["approved", "rejected"].includes(action)) {
      return apiError("action must be 'approved' or 'rejected'", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const { data: updated, error } = await supabase
      .from("leave_requests")
      .update({
        status: action,
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString(),
        review_notes: review_notes || null,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("school_id", user.school_id)
      .eq("status", "pending")
      .select("*")
      .single();

    if (error || !updated) return apiError("Failed to update or already reviewed", ErrorCodes.INTERNAL_ERROR, 500);
    return apiSuccess(updated);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
