import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { loginSchema } from "@/types/api";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = loginSchema.safeParse(body);

    if (!parsed.success) {
      return apiError(
        parsed.error.errors[0]?.message || "Invalid input",
        ErrorCodes.VALIDATION_ERROR,
        400
      );
    }

    const supabase = createServerSupabaseClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: parsed.data.email,
      password: parsed.data.password,
    });

    if (error) {
      return apiError("Invalid email or password", ErrorCodes.INVALID_CREDENTIALS, 401);
    }

    // Fetch user profile
    const { data: profile, error: profileError } = await supabase
      .from("users")
      .select("*")
      .eq("auth_id", data.user.id)
      .single();

    if (profileError || !profile) {
      return apiError(
        "User profile not found. Contact your school administrator.",
        ErrorCodes.NOT_FOUND,
        404
      );
    }

    if (!profile.is_active) {
      await supabase.auth.signOut();
      return apiError(
        "Your account has been deactivated. Contact your school administrator.",
        ErrorCodes.FORBIDDEN,
        403
      );
    }

    // Update last login
    await supabase
      .from("users")
      .update({ last_login_at: new Date().toISOString() })
      .eq("id", profile.id);

    return apiSuccess({ user: profile, session: data.session });
  } catch {
    return apiError("An unexpected error occurred", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
