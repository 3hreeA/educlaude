import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { data: user } = await supabase
      .from("users")
      .select("*")
      .eq("auth_id", session.user.id)
      .single();

    if (!user) {
      return apiError("User profile not found", ErrorCodes.NOT_FOUND, 404);
    }

    return apiSuccess(user);
  } catch {
    return apiError("An unexpected error occurred", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
