import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function POST() {
  try {
    const supabase = createServerSupabaseClient();
    const { error } = await supabase.auth.signOut();

    if (error) {
      return apiError("Failed to sign out", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess({ message: "Signed out successfully" });
  } catch {
    return apiError("An unexpected error occurred", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
