import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

/** Resolve the internal users.id from the auth session */
async function getUserId(supabase: ReturnType<typeof createServerSupabaseClient>, authId: string) {
  const { data } = await supabase
    .from("users")
    .select("id")
    .eq("auth_id", authId)
    .single();
  return data?.id as string | undefined;
}

// ─── GET: Fetch notifications for current user ────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const userId = await getUserId(supabase, session.user.id);
    if (!userId) return apiError("User not found", ErrorCodes.NOT_FOUND, 404);

    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unread") === "true";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = Math.min(parseInt(searchParams.get("limit") || "30"), 100);
    const offset = (page - 1) * limit;

    let query = supabase
      .from("notifications")
      .select("id, title, body, type, data, read_at, sent_via, created_at", { count: "exact" })
      .eq("recipient_id", userId)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (unreadOnly) {
      query = query.is("read_at", null);
    }

    const { data: notifications, error, count } = await query;

    if (error) {
      console.error("Notifications query error:", error);
      return apiError("Failed to fetch notifications", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Get unread count (always useful for badge)
    const { count: unreadCount } = await supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("recipient_id", userId)
      .is("read_at", null);

    return apiSuccess({
      notifications: notifications || [],
      unread_count: unreadCount || 0,
      pagination: {
        page,
        limit,
        total: count || 0,
        total_pages: Math.ceil((count || 0) / limit),
      },
    });
  } catch (err) {
    console.error("Error fetching notifications:", err);
    return apiError("Failed to fetch notifications", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── PATCH: Mark notifications as read ────────────────────────────────
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const userId = await getUserId(supabase, session.user.id);
    if (!userId) return apiError("User not found", ErrorCodes.NOT_FOUND, 404);

    const body = await request.json();
    const { notification_ids } = body as { notification_ids?: string[] };

    const now = new Date().toISOString();

    if (notification_ids && notification_ids.length > 0) {
      // Mark specific notifications
      await supabase
        .from("notifications")
        .update({ read_at: now })
        .in("id", notification_ids)
        .eq("recipient_id", userId)
        .is("read_at", null);
    } else {
      // Mark all as read
      await supabase
        .from("notifications")
        .update({ read_at: now })
        .eq("recipient_id", userId)
        .is("read_at", null);
    }

    // Return new unread count
    const { count: unreadCount } = await supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("recipient_id", userId)
      .is("read_at", null);

    return apiSuccess({ success: true, unread_count: unreadCount || 0 });
  } catch (err) {
    console.error("Error updating notifications:", err);
    return apiError("Failed to update notifications", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
