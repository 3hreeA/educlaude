import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { studentId } = params;
    const { searchParams } = new URL(request.url);
    const termId = searchParams.get("term_id");

    // Build query for attendance records
    let query = supabase
      .from("attendance_records")
      .select("id, date, status, notes, term_id")
      .eq("student_id", studentId)
      .order("date", { ascending: false });

    if (termId) {
      query = query.eq("term_id", termId);
    }

    const { data: records, error } = await query;

    if (error) {
      console.error("Attendance query error:", error);
      return apiError("Failed to fetch attendance", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Calculate summary
    const total = records?.length || 0;
    const present = records?.filter((r) => r.status === "present").length || 0;
    const late = records?.filter((r) => r.status === "late").length || 0;
    const absent = records?.filter((r) => r.status === "absent").length || 0;
    const excused = records?.filter((r) => r.status === "excused").length || 0;

    const percentage = total > 0 ? Math.round(((present + late) / total) * 100) : null;

    // Find streaks
    let currentStreak = 0;
    let consecutiveAbsent = 0;
    if (records) {
      for (const r of records) {
        if (r.status === "present" || r.status === "late") {
          currentStreak++;
        } else {
          break;
        }
      }
      // Find longest consecutive absent
      let tempAbsent = 0;
      for (const r of records) {
        if (r.status === "absent") {
          tempAbsent++;
          consecutiveAbsent = Math.max(consecutiveAbsent, tempAbsent);
        } else {
          tempAbsent = 0;
        }
      }
    }

    return apiSuccess({
      records: records || [],
      summary: {
        total,
        present,
        late,
        absent,
        excused,
        percentage,
        current_streak: currentStreak,
        max_consecutive_absent: consecutiveAbsent,
      },
    });
  } catch (err) {
    console.error("Error fetching attendance:", err);
    return apiError("Failed to fetch attendance", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
