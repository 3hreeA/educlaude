import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

interface AttendanceEntry {
  student_id: string;
  status: "present" | "absent" | "late" | "excused";
  notes?: string;
}

interface MarkAttendanceBody {
  class_id: string;
  date: string;
  entries: AttendanceEntry[];
}

// POST: Mark/update attendance for a class
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const body: MarkAttendanceBody = await request.json();
    const { class_id, date, entries } = body;

    // Validate input
    if (!class_id || !date || !entries || !Array.isArray(entries) || entries.length === 0) {
      return apiError("class_id, date, and entries are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const validStatuses = ["present", "absent", "late", "excused"];
    for (const entry of entries) {
      if (!entry.student_id || !validStatuses.includes(entry.status)) {
        return apiError(
          `Invalid entry: student_id and valid status required`,
          ErrorCodes.VALIDATION_ERROR,
          422
        );
      }
    }

    // Get current term
    const { data: currentTerm } = await supabase
      .from("terms")
      .select("id")
      .eq("is_current", true)
      .single();

    if (!currentTerm) {
      return apiError("No active term found", ErrorCodes.BAD_REQUEST, 400);
    }

    // Upsert attendance records (insert or update on conflict)
    const records = entries.map((e) => ({
      student_id: e.student_id,
      class_id,
      date,
      status: e.status,
      notes: e.notes || null,
      marked_by: session.user.id,
      term_id: currentTerm.id,
    }));

    // Delete existing records for this class+date, then insert fresh
    // (upsert on composite unique constraint student_id+date)
    const { error: deleteErr } = await supabase
      .from("attendance_records")
      .delete()
      .eq("class_id", class_id)
      .eq("date", date);

    if (deleteErr) {
      console.error("Delete attendance error:", deleteErr);
      return apiError("Failed to update attendance", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const { data: inserted, error: insertErr } = await supabase
      .from("attendance_records")
      .insert(records)
      .select("id, student_id, status");

    if (insertErr) {
      console.error("Insert attendance error:", insertErr);
      return apiError("Failed to save attendance", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(
      {
        saved: inserted?.length || 0,
        date,
        class_id,
      },
      201
    );
  } catch (err) {
    console.error("Error marking attendance:", err);
    return apiError("Failed to mark attendance", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// GET: Retrieve attendance for a class on a specific date
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { searchParams } = new URL(request.url);
    const classId = searchParams.get("class_id");
    const date = searchParams.get("date");

    if (!classId || !date) {
      return apiError("class_id and date are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const { data: records, error } = await supabase
      .from("attendance_records")
      .select("id, student_id, status, notes")
      .eq("class_id", classId)
      .eq("date", date);

    if (error) {
      console.error("Attendance query error:", error);
      return apiError("Failed to fetch attendance", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(records || []);
  } catch (err) {
    console.error("Error fetching attendance:", err);
    return apiError("Failed to fetch attendance", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
