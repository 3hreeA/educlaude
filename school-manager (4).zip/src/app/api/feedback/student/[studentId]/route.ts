import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { studentId } = params;

    const { data: feedback, error } = await supabase
      .from("student_feedback")
      .select(`
        id, feedback_type, category, description, created_at,
        teachers:teacher_id (
          id,
          users:user_id ( first_name, last_name )
        )
      `)
      .eq("student_id", studentId)
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) {
      console.error("Feedback query error:", error);
      return apiError("Failed to fetch feedback", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Flatten teacher names
    const formatted = (feedback || []).map((f) => {
      const teacher = f.teachers as any;
      const teacherUser = teacher?.users;
      return {
        id: f.id,
        type: f.feedback_type,
        category: f.category,
        description: f.description,
        date: f.created_at,
        teacher_name: teacherUser
          ? `${teacherUser.first_name} ${teacherUser.last_name}`
          : "Unknown",
      };
    });

    return apiSuccess(formatted);
  } catch (err) {
    console.error("Error fetching feedback:", err);
    return apiError("Failed to fetch feedback", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
