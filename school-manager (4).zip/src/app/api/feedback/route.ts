import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

interface FeedbackBody {
  student_id: string;
  feedback_type: "behavioral" | "academic" | "social" | "attendance";
  category: "positive" | "neutral" | "concern" | "serious";
  description: string;
}

// POST: Submit feedback for a student
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const body: FeedbackBody = await request.json();
    const { student_id, feedback_type, category, description } = body;

    // Validate
    if (!student_id || !feedback_type || !category || !description) {
      return apiError(
        "student_id, feedback_type, category, and description are required",
        ErrorCodes.VALIDATION_ERROR,
        422
      );
    }

    const validTypes = ["behavioral", "academic", "social", "attendance"];
    const validCategories = ["positive", "neutral", "concern", "serious"];

    if (!validTypes.includes(feedback_type)) {
      return apiError(`feedback_type must be one of: ${validTypes.join(", ")}`, ErrorCodes.VALIDATION_ERROR, 422);
    }
    if (!validCategories.includes(category)) {
      return apiError(`category must be one of: ${validCategories.join(", ")}`, ErrorCodes.VALIDATION_ERROR, 422);
    }

    if (description.trim().length < 10) {
      return apiError("Description must be at least 10 characters", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Get teacher record
    const { data: teacher } = await supabase
      .from("teachers")
      .select("id")
      .eq("user_id", session.user.id)
      .single();

    if (!teacher) {
      return apiError("Teacher profile not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get current term (optional)
    const { data: currentTerm } = await supabase
      .from("terms")
      .select("id")
      .eq("is_current", true)
      .single();

    const { data: feedback, error } = await supabase
      .from("student_feedback")
      .insert({
        student_id,
        teacher_id: teacher.id,
        feedback_type,
        category,
        description,
        content: description, // Also populate content column for schema compatibility
        term_id: currentTerm?.id || null,
        is_visible_to_parent: true,
      })
      .select("id, feedback_type, category, description, created_at")
      .single();

    if (error) {
      console.error("Create feedback error:", error);
      return apiError("Failed to submit feedback", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(feedback, 201);
  } catch (err) {
    console.error("Error submitting feedback:", err);
    return apiError("Failed to submit feedback", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
