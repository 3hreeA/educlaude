import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const schoolId = user.school_id;

    // Parallel queries for dashboard stats
    const [
      studentsRes,
      teachersRes,
      classesRes,
      todayAttendanceRes,
      incidentsRes,
      announcementsRes,
    ] = await Promise.all([
      supabase.from("students").select("id", { count: "exact", head: true }).eq("school_id", schoolId).eq("is_active", true),
      supabase.from("teachers").select("id", { count: "exact", head: true }).eq("user_id", supabase.rpc ? "" : "").is("user_id", null).not("user_id", "is", null),
      supabase.from("classes").select("id", { count: "exact", head: true }).eq("school_id", schoolId),
      supabase.from("attendance_records").select("id, status", { count: "exact" }).eq("date", new Date().toISOString().split("T")[0]),
      supabase.from("disciplinary_incidents").select("id", { count: "exact", head: true }).eq("status", "open"),
      supabase.from("announcements").select("id", { count: "exact", head: true }).eq("status", "sent"),
    ]);

    // Calculate teacher count properly
    const { count: teacherCount } = await supabase
      .from("users")
      .select("id", { count: "exact", head: true })
      .eq("school_id", schoolId)
      .eq("role", "teacher")
      .eq("is_active", true);

    // Calculate attendance percentage for today
    const totalAttendance = todayAttendanceRes.count || 0;
    let presentCount = 0;
    if (todayAttendanceRes.data) {
      presentCount = todayAttendanceRes.data.filter((r: { status: string }) => r.status === "present" || r.status === "late").length;
    }
    const attendancePercentage = totalAttendance > 0 ? Math.round((presentCount / totalAttendance) * 100) : null;

    return NextResponse.json({
      data: {
        total_students: studentsRes.count || 0,
        total_teachers: teacherCount || 0,
        total_classes: classesRes.count || 0,
        attendance_today: attendancePercentage,
        pending_incidents: incidentsRes.count || 0,
        active_announcements: announcementsRes.count || 0,
      },
    });
  } catch (err) {
    console.error("Admin stats error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
