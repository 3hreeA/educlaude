import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: Teacher attendance for a date ───────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date") || new Date().toISOString().split("T")[0];

    // All teachers
    const { data: teachers } = await supabase
      .from("teachers")
      .select("id, staff_id, users:user_id ( first_name, last_name, is_active )");

    // Attendance for this date
    const { data: records } = await supabase
      .from("teacher_attendance")
      .select("teacher_id, status, check_in, check_out, notes")
      .eq("school_id", user.school_id)
      .eq("date", date);

    const attMap: Record<string, Record<string, unknown>> = {};
    for (const r of records || []) {
      attMap[r.teacher_id] = r;
    }

    const result = (teachers || [])
      .filter((t) => {
        const u = t.users as Record<string, unknown> | null;
        return u?.is_active;
      })
      .map((t) => {
        const u = t.users as Record<string, string>;
        const att = attMap[t.id];
        return {
          teacher_id: t.id,
          staff_id: t.staff_id,
          name: `${u.first_name} ${u.last_name}`,
          status: att?.status || null,
          check_in: att?.check_in || null,
          check_out: att?.check_out || null,
          notes: att?.notes || null,
        };
      });

    return apiSuccess({ date, teachers: result });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Mark teacher attendance (bulk) ─────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { date, entries } = body as {
      date: string;
      entries: { teacher_id: string; status: string; notes?: string }[];
    };

    if (!date || !entries?.length) {
      return apiError("date and entries required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const now = new Date().toISOString();
    const records = entries.map((e) => ({
      school_id: user.school_id,
      teacher_id: e.teacher_id,
      date,
      status: e.status,
      check_in: e.status === "present" || e.status === "late" ? now : null,
      notes: e.notes || null,
      marked_by: user.id,
    }));

    const { error } = await supabase
      .from("teacher_attendance")
      .upsert(records, { onConflict: "teacher_id,date" });

    if (error) {
      console.error("Teacher att error:", error);
      return apiError("Failed to save", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess({ saved: records.length });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
