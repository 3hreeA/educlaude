import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

type Ctx = { params: Promise<{ id: string }> };

// ─── GET: Incident detail ─────────────────────────────────────────────
export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["admin", "teacher"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { data: inc, error } = await supabase
      .from("disciplinary_incidents")
      .select(`*, students:student_id ( id, first_name, last_name, admission_number, classes:class_id ( name ) ),
               reporter:reported_by ( first_name, last_name ),
               resolver:resolved_by ( first_name, last_name )`)
      .eq("id", id)
      .eq("school_id", user.school_id)
      .single();

    if (error || !inc) return apiError("Incident not found", ErrorCodes.NOT_FOUND, 404);

    return apiSuccess(inc);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── PUT: Update incident ─────────────────────────────────────────────
export async function PUT(request: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };

    if (body.status) updates.status = body.status;
    if (body.action_taken !== undefined) updates.action_taken = body.action_taken;
    if (body.follow_up_date !== undefined) updates.follow_up_date = body.follow_up_date || null;
    if (body.follow_up_notes !== undefined) updates.follow_up_notes = body.follow_up_notes || null;

    if (body.status === "resolved") {
      updates.resolved_by = user.id;
      updates.resolved_at = new Date().toISOString();
    }

    if (body.parent_notified) {
      updates.parent_notified = true;
      updates.parent_notified_at = new Date().toISOString();
    }

    const { data: updated, error } = await supabase
      .from("disciplinary_incidents")
      .update(updates)
      .eq("id", id)
      .eq("school_id", user.school_id)
      .select("*")
      .single();

    if (error || !updated) return apiError("Failed to update", ErrorCodes.INTERNAL_ERROR, 500);
    return apiSuccess(updated);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
