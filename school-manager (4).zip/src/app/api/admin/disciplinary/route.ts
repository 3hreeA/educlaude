import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List incidents ──────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("id, role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || !["admin", "teacher"].includes(user.role)) {
      return apiError("Admin or teacher access required", ErrorCodes.FORBIDDEN, 403);
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = Math.min(parseInt(searchParams.get("limit") || "20"), 50);
    const offset = (page - 1) * limit;
    const status = searchParams.get("status");
    const severity = searchParams.get("severity");
    const studentId = searchParams.get("student_id");

    let query = supabase
      .from("disciplinary_incidents")
      .select(
        `id, severity, status, category, description, action_taken,
         parent_notified, follow_up_date, created_at, updated_at,
         students:student_id ( id, first_name, last_name, admission_number,
           classes:class_id ( name ) ),
         reporter:reported_by ( first_name, last_name )`,
        { count: "exact" }
      )
      .eq("school_id", user.school_id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (status && status !== "all") query = query.eq("status", status);
    if (severity && severity !== "all") query = query.eq("severity", severity);
    if (studentId) query = query.eq("student_id", studentId);

    const { data: incidents, error, count } = await query;

    if (error) {
      console.error("Incidents query error:", error);
      return apiError("Failed to fetch incidents", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (incidents || []).map((inc: Record<string, unknown>) => {
      const student = inc.students as Record<string, unknown> | null;
      const reporter = inc.reporter as Record<string, string> | null;
      const cls = student?.classes as Record<string, string> | null;
      return {
        ...inc,
        students: undefined,
        reporter: undefined,
        student_name: student ? `${student.first_name} ${student.last_name}` : "Unknown",
        student_admission: student?.admission_number || "",
        class_name: cls?.name || "",
        student_id: student?.id || "",
        reported_by_name: reporter ? `${reporter.first_name} ${reporter.last_name}` : "Unknown",
      };
    });

    return apiSuccess({
      incidents: formatted,
      pagination: { page, limit, total: count || 0, total_pages: Math.ceil((count || 0) / limit) },
    });
  } catch (err) {
    console.error("Error fetching incidents:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Create incident ────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("id, role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || !["admin", "teacher"].includes(user.role)) {
      return apiError("Admin or teacher access required", ErrorCodes.FORBIDDEN, 403);
    }

    const body = await request.json();
    const { student_id, severity, category, description, action_taken, follow_up_date } = body;

    if (!student_id || !severity || !category || !description) {
      return apiError("student_id, severity, category, and description are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const { data: incident, error } = await supabase
      .from("disciplinary_incidents")
      .insert({
        school_id: user.school_id,
        student_id,
        reported_by: user.id,
        severity,
        category,
        description,
        action_taken: action_taken || null,
        follow_up_date: follow_up_date || null,
      })
      .select("*")
      .single();

    if (error) {
      console.error("Create incident error:", error);
      return apiError("Failed to create incident", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(incident, 201);
  } catch (err) {
    console.error("Error creating incident:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
