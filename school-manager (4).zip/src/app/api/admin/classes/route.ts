import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/admin/classes - List classes with student counts */
export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "admin" && user.role !== "finance")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    // Get current academic year
    const { data: currentYear } = await supabase
      .from("academic_years")
      .select("id")
      .eq("school_id", user.school_id)
      .eq("is_current", true)
      .single();

    if (!currentYear) {
      return NextResponse.json({ data: [] });
    }

    const { data: classes, error } = await supabase
      .from("classes")
      .select(`
        id, name, level, arm, capacity,
        students ( id )
      `)
      .eq("school_id", user.school_id)
      .eq("academic_year_id", currentYear.id)
      .order("level")
      .order("name");

    if (error) throw error;

    const result = (classes || []).map((c: Record<string, unknown>) => ({
      id: c.id,
      name: c.name,
      level: c.level,
      arm: c.arm,
      capacity: c.capacity,
      student_count: Array.isArray(c.students) ? c.students.length : 0,
    }));

    return NextResponse.json({ data: result });
  } catch (err) {
    console.error("Admin classes error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}

/** POST /api/admin/classes - Create a new class */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const body = await req.json();
    const { name, level, arm, capacity } = body;

    if (!name || !level) {
      return NextResponse.json({ error: { message: "Name and level are required" } }, { status: 400 });
    }

    const { data: currentYear } = await supabase
      .from("academic_years")
      .select("id")
      .eq("school_id", user.school_id)
      .eq("is_current", true)
      .single();

    if (!currentYear) {
      return NextResponse.json({ error: { message: "No active academic year" } }, { status: 400 });
    }

    const { data: newClass, error } = await supabase
      .from("classes")
      .insert({
        school_id: user.school_id,
        name: name.trim(),
        level: level.trim(),
        arm: arm?.trim() || null,
        capacity: capacity || 40,
        academic_year_id: currentYear.id,
      })
      .select()
      .single();

    if (error) {
      if (error.code === "23505") {
        return NextResponse.json({ error: { message: "Class already exists" } }, { status: 409 });
      }
      throw error;
    }

    return NextResponse.json({ data: newClass }, { status: 201 });
  } catch (err) {
    console.error("Class creation error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
