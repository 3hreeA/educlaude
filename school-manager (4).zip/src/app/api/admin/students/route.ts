import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/admin/students?search=&class_id=&status=&page=1&limit=20 */
export async function GET(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "admin" && user.role !== "finance")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const url = req.nextUrl;
    const search = url.searchParams.get("search") || "";
    const classId = url.searchParams.get("class_id") || "";
    const status = url.searchParams.get("status") || "active";
    const page = parseInt(url.searchParams.get("page") || "1");
    const limit = Math.min(parseInt(url.searchParams.get("limit") || "20"), 50);
    const offset = (page - 1) * limit;

    let query = supabase
      .from("students")
      .select(`
        id, admission_number, first_name, last_name, middle_name,
        gender, date_of_birth, photo_url, is_active, admission_date,
        classes!inner ( id, name, level, arm )
      `, { count: "exact" })
      .eq("school_id", user.school_id);

    // Filters
    if (status === "active") query = query.eq("is_active", true);
    else if (status === "inactive") query = query.eq("is_active", false);

    if (classId) query = query.eq("class_id", classId);

    if (search) {
      query = query.or(
        `first_name.ilike.%${search}%,last_name.ilike.%${search}%,admission_number.ilike.%${search}%`
      );
    }

    query = query.order("last_name").order("first_name").range(offset, offset + limit - 1);

    const { data: students, count, error } = await query;
    if (error) throw error;

    return NextResponse.json({
      data: {
        students: students || [],
        pagination: {
          page,
          limit,
          total: count || 0,
          total_pages: Math.ceil((count || 0) / limit),
        },
      },
    });
  } catch (err) {
    console.error("Admin students list error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}

/** POST /api/admin/students - Register new student */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const body = await req.json();
    const {
      first_name, last_name, middle_name, gender, date_of_birth,
      class_id, blood_group, genotype, medical_notes, address,
      parent_name, parent_email, parent_phone, parent_relationship,
    } = body;

    // Validate required fields
    if (!first_name || !last_name || !gender || !date_of_birth || !class_id) {
      return NextResponse.json(
        { error: { message: "Missing required fields: first_name, last_name, gender, date_of_birth, class_id" } },
        { status: 400 }
      );
    }

    // Generate admission number
    const year = new Date().getFullYear();
    const { count } = await supabase
      .from("students")
      .select("id", { count: "exact", head: true })
      .eq("school_id", user.school_id);

    const seqNum = String((count || 0) + 1).padStart(3, "0");
    const admissionNumber = `BFA/${year}/${seqNum}`;

    // Insert student
    const { data: student, error: studentErr } = await supabase
      .from("students")
      .insert({
        school_id: user.school_id,
        admission_number: admissionNumber,
        first_name: first_name.trim(),
        last_name: last_name.trim(),
        middle_name: middle_name?.trim() || null,
        gender,
        date_of_birth,
        class_id,
        blood_group: blood_group || null,
        genotype: genotype || null,
        medical_notes: medical_notes || null,
        address: address || null,
        is_active: true,
      })
      .select()
      .single();

    if (studentErr) {
      console.error("Student insert error:", studentErr);
      if (studentErr.code === "23505") {
        return NextResponse.json({ error: { message: "Student already exists with this admission number" } }, { status: 409 });
      }
      throw studentErr;
    }

    // If parent details provided, create or link parent
    if (parent_email) {
      // Check if parent user already exists
      const { data: existingUser } = await supabase
        .from("users")
        .select("id")
        .eq("email", parent_email.toLowerCase())
        .single();

      let parentUserId = existingUser?.id;

      if (!parentUserId) {
        // Create parent user in users table (without auth — admin-created)
        // In production, you'd send an invite email with a signup link
        const { data: newUser, error: userErr } = await supabase
          .from("users")
          .insert({
            auth_id: crypto.randomUUID(), // placeholder until parent registers
            email: parent_email.toLowerCase(),
            phone: parent_phone || null,
            first_name: (parent_name || "Parent").split(" ")[0],
            last_name: (parent_name || "").split(" ").slice(1).join(" ") || last_name,
            role: "parent",
            school_id: user.school_id,
            is_active: true,
          })
          .select("id")
          .single();

        if (userErr) {
          console.error("Parent user creation error:", userErr);
        } else {
          parentUserId = newUser?.id;
        }
      }

      if (parentUserId) {
        // Get or create parent record
        let parentRecord = await supabase
          .from("parents")
          .select("id")
          .eq("user_id", parentUserId)
          .single();

        if (!parentRecord.data) {
          const { data: newParent } = await supabase
            .from("parents")
            .insert({
              user_id: parentUserId,
              relationship: parent_relationship || "parent",
              is_emergency_contact: true,
            })
            .select("id")
            .single();
          parentRecord = { data: newParent, error: null, count: null, status: 200, statusText: "OK" } as typeof parentRecord;
        }

        if (parentRecord.data) {
          await supabase.from("student_parents").insert({
            student_id: student.id,
            parent_id: parentRecord.data.id,
          });
        }
      }
    }

    return NextResponse.json({ data: student }, { status: 201 });
  } catch (err) {
    console.error("Student registration error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
