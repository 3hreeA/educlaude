import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

const DAYS = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

// ─── GET: Timetable for a class or teacher ────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const classId = searchParams.get("class_id");
    const teacherId = searchParams.get("teacher_id");

    let query = supabase
      .from("timetable_slots")
      .select(`id, day_of_week, start_time, end_time, room,
               classes:class_id ( id, name ),
               subjects:subject_id ( id, name ),
               teachers:teacher_id ( id, staff_id, users:user_id ( first_name, last_name ) )`)
      .eq("school_id", user.school_id)
      .order("day_of_week")
      .order("start_time");

    if (classId) query = query.eq("class_id", classId);
    if (teacherId) query = query.eq("teacher_id", teacherId);

    const { data: slots, error } = await query;
    if (error) {
      console.error("Timetable query error:", error);
      return apiError("Failed to fetch", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (slots || []).map((s: Record<string, unknown>) => {
      const cls = s.classes as Record<string, string> | null;
      const subj = s.subjects as Record<string, string> | null;
      const t = s.teachers as Record<string, unknown> | null;
      const u = t?.users as Record<string, string> | null;
      return {
        id: s.id,
        day_of_week: s.day_of_week,
        day_name: DAYS[s.day_of_week as number] || "",
        start_time: (s.start_time as string)?.slice(0, 5),
        end_time: (s.end_time as string)?.slice(0, 5),
        room: s.room,
        class_name: cls?.name || "",
        class_id: cls?.id,
        subject_name: subj?.name || "Free Period",
        subject_id: subj?.id,
        teacher_name: u ? `${u.first_name} ${u.last_name}` : "",
        teacher_id: t?.id,
      };
    });

    // Group by day
    const byDay: Record<number, typeof formatted> = {};
    for (let d = 1; d <= 5; d++) byDay[d] = formatted.filter((s) => s.day_of_week === d);

    return apiSuccess({ slots: formatted, by_day: byDay });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Create / update timetable slot ─────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room, term_id } = body;

    if (!class_id || !day_of_week || !start_time || !end_time) {
      return apiError("class_id, day_of_week, start_time, end_time required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Check for conflicts
    const { data: conflicts } = await supabase
      .from("timetable_slots")
      .select("id")
      .eq("school_id", user.school_id)
      .eq("class_id", class_id)
      .eq("day_of_week", day_of_week)
      .lte("start_time", end_time)
      .gte("end_time", start_time);

    if (conflicts && conflicts.length > 0) {
      return apiError("Time slot conflicts with existing entry", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const { data, error } = await supabase
      .from("timetable_slots")
      .insert({
        school_id: user.school_id,
        class_id,
        subject_id: subject_id || null,
        teacher_id: teacher_id || null,
        day_of_week,
        start_time,
        end_time,
        room: room || null,
        term_id: term_id || null,
      })
      .select("*")
      .single();

    if (error) {
      console.error("Timetable insert error:", error);
      return apiError("Failed to create slot", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(data, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── DELETE: Remove slot ──────────────────────────────────────────────
export async function DELETE(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const slotId = searchParams.get("id");
    if (!slotId) return apiError("id required", ErrorCodes.VALIDATION_ERROR, 422);

    await supabase.from("timetable_slots").delete().eq("id", slotId).eq("school_id", user.school_id);
    return apiSuccess({ deleted: true });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
