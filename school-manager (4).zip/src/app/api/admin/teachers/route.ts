import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List teachers with performance summary ──────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin access required", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";

    // Get teachers with user info
    let query = supabase
      .from("teachers")
      .select(`
        id, staff_id, qualification, specialization, date_joined, is_class_teacher,
        users:user_id ( id, first_name, last_name, email, phone, is_active, avatar_url )
      `)
      .order("created_at", { ascending: false });

    const { data: teachers, error } = await query;
    if (error) {
      console.error("Teachers query error:", error);
      return apiError("Failed to fetch teachers", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Filter by school via users table + search
    const schoolTeachers = (teachers || [])
      .filter((t) => {
        const u = t.users as Record<string, unknown> | null;
        if (!u) return false;
        if (search) {
          const name = `${u.first_name} ${u.last_name}`.toLowerCase();
          return name.includes(search.toLowerCase()) || t.staff_id.toLowerCase().includes(search.toLowerCase());
        }
        return true;
      });

    // Get attendance stats for each teacher (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split("T")[0];
    const { data: attStats } = await supabase
      .from("teacher_attendance")
      .select("teacher_id, status")
      .eq("school_id", user.school_id)
      .gte("date", thirtyDaysAgo);

    const attByTeacher: Record<string, { total: number; present: number; late: number; absent: number }> = {};
    for (const a of attStats || []) {
      if (!attByTeacher[a.teacher_id]) attByTeacher[a.teacher_id] = { total: 0, present: 0, late: 0, absent: 0 };
      attByTeacher[a.teacher_id].total++;
      if (a.status === "present") attByTeacher[a.teacher_id].present++;
      else if (a.status === "late") attByTeacher[a.teacher_id].late++;
      else if (a.status === "absent") attByTeacher[a.teacher_id].absent++;
    }

    // Get class assignment counts
    const { data: assignments } = await supabase
      .from("teacher_assignments")
      .select("teacher_id, class_id, is_class_teacher");

    const assignByTeacher: Record<string, { classes: number; is_class_teacher: boolean }> = {};
    for (const a of assignments || []) {
      if (!assignByTeacher[a.teacher_id]) assignByTeacher[a.teacher_id] = { classes: 0, is_class_teacher: false };
      assignByTeacher[a.teacher_id].classes++;
      if (a.is_class_teacher) assignByTeacher[a.teacher_id].is_class_teacher = true;
    }

    // Get pending leave counts
    const { data: leaveData } = await supabase
      .from("leave_requests")
      .select("teacher_id, status")
      .eq("school_id", user.school_id);

    const leaveByTeacher: Record<string, { pending: number; approved: number; total: number }> = {};
    for (const l of leaveData || []) {
      if (!leaveByTeacher[l.teacher_id]) leaveByTeacher[l.teacher_id] = { pending: 0, approved: 0, total: 0 };
      leaveByTeacher[l.teacher_id].total++;
      if (l.status === "pending") leaveByTeacher[l.teacher_id].pending++;
      if (l.status === "approved") leaveByTeacher[l.teacher_id].approved++;
    }

    const formatted = schoolTeachers.map((t) => {
      const u = t.users as Record<string, unknown>;
      const att = attByTeacher[t.id] || { total: 0, present: 0, late: 0, absent: 0 };
      const assign = assignByTeacher[t.id] || { classes: 0, is_class_teacher: false };
      const leave = leaveByTeacher[t.id] || { pending: 0, approved: 0, total: 0 };
      const attendanceRate = att.total > 0 ? Math.round(((att.present + att.late) / att.total) * 100) : null;

      return {
        id: t.id,
        user_id: u.id,
        staff_id: t.staff_id,
        first_name: u.first_name,
        last_name: u.last_name,
        email: u.email,
        phone: u.phone,
        avatar_url: u.avatar_url,
        is_active: u.is_active,
        qualification: t.qualification,
        specialization: t.specialization,
        date_joined: t.date_joined,
        is_class_teacher: assign.is_class_teacher,
        classes_count: assign.classes,
        attendance_rate: attendanceRate,
        attendance_days: att,
        leave_summary: leave,
      };
    });

    return apiSuccess({ teachers: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
