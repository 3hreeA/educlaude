import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

type Ctx = { params: Promise<{ teacherId: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const { teacherId } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || user.role !== "admin") return apiError("Admin only", ErrorCodes.FORBIDDEN, 403);

    // Teacher base info
    const { data: teacher, error } = await supabase
      .from("teachers")
      .select(`id, staff_id, qualification, specialization, date_joined, is_class_teacher,
               users:user_id ( id, first_name, last_name, email, phone, is_active, avatar_url )`)
      .eq("id", teacherId)
      .single();

    if (error || !teacher) return apiError("Teacher not found", ErrorCodes.NOT_FOUND, 404);

    // Class assignments
    const { data: assignments } = await supabase
      .from("teacher_assignments")
      .select(`id, is_class_teacher, classes:class_id ( id, name, level ),
               subjects:subject_id ( id, name, code )`)
      .eq("teacher_id", teacherId);

    // Attendance history (last 60 days)
    const sixtyDaysAgo = new Date(Date.now() - 60 * 86400000).toISOString().split("T")[0];
    const { data: attendance } = await supabase
      .from("teacher_attendance")
      .select("date, status, check_in, check_out, notes")
      .eq("teacher_id", teacherId)
      .gte("date", sixtyDaysAgo)
      .order("date", { ascending: false });

    // Compute attendance stats
    const attStats = { total: 0, present: 0, late: 0, absent: 0, excused: 0, half_day: 0 };
    for (const a of attendance || []) {
      attStats.total++;
      const s = a.status as keyof typeof attStats;
      if (s in attStats) attStats[s]++;
    }
    const attendanceRate = attStats.total > 0
      ? Math.round(((attStats.present + attStats.late) / attStats.total) * 100)
      : null;

    // Leave requests
    const { data: leaves } = await supabase
      .from("leave_requests")
      .select("id, leave_type, start_date, end_date, days_count, reason, status, reviewed_at, created_at")
      .eq("teacher_id", teacherId)
      .order("created_at", { ascending: false })
      .limit(10);

    // Combine
    const u = teacher.users as Record<string, unknown>;
    return apiSuccess({
      id: teacher.id,
      staff_id: teacher.staff_id,
      first_name: u.first_name,
      last_name: u.last_name,
      email: u.email,
      phone: u.phone,
      avatar_url: u.avatar_url,
      is_active: u.is_active,
      qualification: teacher.qualification,
      specialization: teacher.specialization,
      date_joined: teacher.date_joined,
      assignments: (assignments || []).map((a) => ({
        id: a.id,
        class: a.classes,
        subject: a.subjects,
        is_class_teacher: a.is_class_teacher,
      })),
      attendance: {
        stats: attStats,
        rate: attendanceRate,
        recent: (attendance || []).slice(0, 30),
      },
      leaves: leaves || [],
    });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
