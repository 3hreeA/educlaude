import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// GET: List assessments for a class/subject/term
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { searchParams } = new URL(request.url);
    const classId = searchParams.get("class_id");
    const subjectId = searchParams.get("subject_id");
    const termId = searchParams.get("term_id");

    let query = supabase
      .from("assessments")
      .select(`
        id, name, max_score, weight, date, created_at,
        subjects:subject_id (id, name, code),
        classes:class_id (id, name)
      `)
      .order("date", { ascending: false });

    if (classId) query = query.eq("class_id", classId);
    if (subjectId) query = query.eq("subject_id", subjectId);
    if (termId) query = query.eq("term_id", termId);

    const { data: assessments, error } = await query;

    if (error) {
      console.error("Assessments query error:", error);
      return apiError("Failed to fetch assessments", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // For each assessment, get count of grades entered
    const withCounts = await Promise.all(
      (assessments || []).map(async (a) => {
        const { count } = await supabase
          .from("grades")
          .select("id", { count: "exact", head: true })
          .eq("assessment_id", a.id);

        // Get total students in the class
        const cls = a.classes as any;
        let totalStudents = 0;
        if (cls?.id) {
          const { count: studentCount } = await supabase
            .from("students")
            .select("id", { count: "exact", head: true })
            .eq("class_id", cls.id)
            .eq("is_active", true);
          totalStudents = studentCount || 0;
        }

        return {
          id: a.id,
          name: a.name,
          max_score: a.max_score,
          weight: a.weight,
          date: a.date,
          subject: a.subjects,
          class: a.classes,
          grades_entered: count || 0,
          total_students: totalStudents,
          is_complete: (count || 0) >= totalStudents && totalStudents > 0,
        };
      })
    );

    return apiSuccess(withCounts);
  } catch (err) {
    console.error("Error fetching assessments:", err);
    return apiError("Failed to fetch assessments", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// POST: Create a new assessment
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const body = await request.json();
    const { class_id, subject_id, name, max_score, weight, date } = body;

    // Validate
    if (!class_id || !subject_id || !name || !max_score || !date) {
      return apiError(
        "class_id, subject_id, name, max_score, and date are required",
        ErrorCodes.VALIDATION_ERROR,
        422
      );
    }

    if (max_score <= 0 || max_score > 200) {
      return apiError("max_score must be between 1 and 200", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Get current term
    const { data: currentTerm } = await supabase
      .from("terms")
      .select("id")
      .eq("is_current", true)
      .single();

    if (!currentTerm) {
      return apiError("No active term found", ErrorCodes.BAD_REQUEST, 400);
    }

    const { data: assessment, error } = await supabase
      .from("assessments")
      .insert({
        class_id,
        subject_id,
        term_id: currentTerm.id,
        name,
        max_score,
        weight: weight || 1.0,
        date,
        created_by: session.user.id,
      })
      .select("id, name, max_score, weight, date")
      .single();

    if (error) {
      console.error("Create assessment error:", error);
      return apiError("Failed to create assessment", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(assessment, 201);
  } catch (err) {
    console.error("Error creating assessment:", err);
    return apiError("Failed to create assessment", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
