import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: Reminder history ────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get("limit") || "50");

    const { data: logs } = await supabase
      .from("fee_reminder_logs")
      .select(`id, channel, message, status, sent_at,
               student_fee_accounts:fee_account_id (
                 students:student_id ( first_name, last_name, admission_number ),
                 balance
               )`)
      .order("sent_at", { ascending: false })
      .limit(limit);

    const formatted = (logs || []).map((l: Record<string, unknown>) => {
      const acct = l.student_fee_accounts as Record<string, unknown> | null;
      const s = acct?.students as Record<string, string> | null;
      return {
        id: l.id,
        channel: l.channel,
        message: l.message,
        status: l.status,
        sent_at: l.sent_at,
        student_name: s ? `${s.first_name} ${s.last_name}` : "Unknown",
        admission_number: s?.admission_number || "",
        balance: acct ? Number(acct.balance) : 0,
      };
    });

    return apiSuccess({ reminders: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Send fee reminders to overdue accounts ─────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { aging, channels } = body as { aging?: string; channels?: string[] };
    const selectedChannels = channels || ["push"];

    // Get overdue accounts
    const now = new Date().toISOString().split("T")[0];
    let query = supabase
      .from("student_fee_accounts")
      .select(`id, balance, due_date, status,
               students:student_id ( first_name, last_name, admission_number,
                 parents:student_parents ( parents:parent_id ( user_id, phone, users:user_id ( first_name ) ) ) )`)
      .gt("balance", 0)
      .lte("due_date", now);

    if (aging === "30") query = query.lte("due_date", new Date(Date.now() - 30 * 86400000).toISOString().split("T")[0]);
    if (aging === "60") query = query.lte("due_date", new Date(Date.now() - 60 * 86400000).toISOString().split("T")[0]);
    if (aging === "90") query = query.lte("due_date", new Date(Date.now() - 90 * 86400000).toISOString().split("T")[0]);

    const { data: accounts } = await query;

    if (!accounts || accounts.length === 0) {
      return apiSuccess({ sent: 0, message: "No overdue accounts found" });
    }

    // Generate reminder logs (in production, this would trigger actual WhatsApp/SMS sends)
    const logs = [];
    for (const acct of accounts) {
      const student = acct.students as Record<string, unknown> | null;
      const name = student ? `${student.first_name} ${student.last_name}` : "your child";
      const balance = Number(acct.balance).toLocaleString("en-NG");

      for (const channel of selectedChannels) {
        const message = channel === "sms"
          ? `Dear Parent, this is a reminder that ₦${balance} school fees for ${name} is overdue. Please make payment at your earliest convenience.`
          : `Dear Parent,\n\nThis is a friendly reminder that school fees of ₦${balance} for ${name} is currently outstanding.\n\nPlease log in to School Manager to make your payment, or contact the school finance office for assistance.\n\nThank you.`;

        logs.push({
          fee_account_id: acct.id,
          channel,
          message,
          status: "sent", // In production: "pending" until delivery confirmed
        });
      }
    }

    if (logs.length > 0) {
      await supabase.from("fee_reminder_logs").insert(logs);
    }

    // Also create in-app notifications for parents
    const notifications = [];
    for (const acct of accounts) {
      const student = acct.students as Record<string, unknown> | null;
      const parents = (student as Record<string, unknown>)?.parents as Array<Record<string, unknown>> | null;
      if (!parents) continue;

      for (const sp of parents) {
        const parent = sp.parents as Record<string, unknown> | null;
        if (!parent?.user_id) continue;
        notifications.push({
          recipient_id: parent.user_id,
          type: "fee_reminder",
          title: "Fee Payment Reminder",
          message: `Outstanding balance of ₦${Number(acct.balance).toLocaleString("en-NG")} is overdue. Please make payment.`,
          channel: "push",
        });
      }
    }

    if (notifications.length > 0) {
      await supabase.from("notifications").insert(notifications);
    }

    return apiSuccess({
      sent: logs.length,
      accounts_notified: accounts.length,
      channels: selectedChannels,
    });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
