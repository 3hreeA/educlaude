import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** POST /api/finance/fee-accounts/assign - Assign fee structure to students */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "finance") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const body = await req.json();
    const { fee_structure_id, class_id } = body;

    if (!fee_structure_id) {
      return NextResponse.json({ error: { message: "fee_structure_id is required" } }, { status: 400 });
    }

    // Get fee structure details
    const { data: structure, error: structErr } = await supabase
      .from("fee_structures")
      .select("id, total_amount, due_date, class_id")
      .eq("id", fee_structure_id)
      .single();

    if (structErr || !structure) {
      return NextResponse.json({ error: { message: "Fee structure not found" } }, { status: 404 });
    }

    const targetClassId = class_id || structure.class_id;
    if (!targetClassId) {
      return NextResponse.json({ error: { message: "class_id is required for non-class-specific structures" } }, { status: 400 });
    }

    // Get all active students in the class
    const { data: students } = await supabase
      .from("students")
      .select("id")
      .eq("class_id", targetClassId)
      .eq("is_active", true);

    if (!students || students.length === 0) {
      return NextResponse.json({ error: { message: "No active students in this class" } }, { status: 400 });
    }

    // Check which students already have accounts for this structure
    const { data: existing } = await supabase
      .from("student_fee_accounts")
      .select("student_id")
      .eq("fee_structure_id", fee_structure_id);

    const existingSet = new Set((existing || []).map((e: { student_id: string }) => e.student_id));
    const newStudents = students.filter((s: { id: string }) => !existingSet.has(s.id));

    if (newStudents.length === 0) {
      return NextResponse.json({
        data: { assigned: 0, message: "All students already assigned" },
      });
    }

    // Create fee accounts
    const accounts = newStudents.map((s: { id: string }) => ({
      student_id: s.id,
      fee_structure_id: fee_structure_id,
      total_amount: structure.total_amount,
      amount_paid: 0,
      status: "current" as const,
      due_date: structure.due_date,
    }));

    const { error: insertErr } = await supabase
      .from("student_fee_accounts")
      .insert(accounts);

    if (insertErr) throw insertErr;

    return NextResponse.json({
      data: {
        assigned: newStudents.length,
        skipped: existingSet.size,
        message: `Fee accounts created for ${newStudents.length} students`,
      },
    });
  } catch (err) {
    console.error("Fee account assignment error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
