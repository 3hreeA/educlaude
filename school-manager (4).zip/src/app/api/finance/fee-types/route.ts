import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/finance/fee-types - List all fee types */
export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "finance" && user.role !== "admin")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const { data, error } = await supabase
      .from("fee_types")
      .select("*")
      .eq("school_id", user.school_id)
      .order("name");

    if (error) throw error;
    return NextResponse.json({ data: data || [] });
  } catch (err) {
    console.error("Fee types error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}

/** POST /api/finance/fee-types - Create a new fee type */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "finance") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const body = await req.json();
    const { name, description, is_recurring } = body;

    if (!name) {
      return NextResponse.json({ error: { message: "Name is required" } }, { status: 400 });
    }

    const { data, error } = await supabase
      .from("fee_types")
      .insert({
        school_id: user.school_id,
        name: name.trim(),
        description: description?.trim() || null,
        is_recurring: is_recurring !== false,
      })
      .select()
      .single();

    if (error) {
      if (error.code === "23505") {
        return NextResponse.json({ error: { message: "Fee type already exists" } }, { status: 409 });
      }
      throw error;
    }

    return NextResponse.json({ data }, { status: 201 });
  } catch (err) {
    console.error("Fee type creation error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
