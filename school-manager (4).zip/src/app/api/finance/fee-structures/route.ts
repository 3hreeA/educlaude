import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/finance/fee-structures?term_id=&class_id= */
export async function GET(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "finance" && user.role !== "admin")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const url = req.nextUrl;
    const termId = url.searchParams.get("term_id");
    const classId = url.searchParams.get("class_id");

    let query = supabase
      .from("fee_structures")
      .select(`
        id, name, total_amount, due_date, created_at,
        terms ( id, name ),
        academic_years ( id, name ),
        classes ( id, name, level ),
        fee_structure_items (
          id, amount,
          fee_types ( id, name )
        )
      `)
      .eq("school_id", user.school_id)
      .order("created_at", { ascending: false });

    if (termId) query = query.eq("term_id", termId);
    if (classId) query = query.eq("class_id", classId);

    const { data, error } = await query;
    if (error) throw error;

    // Count assigned students per structure
    const structureIds = (data || []).map((s: { id: string }) => s.id);
    const { data: accountCounts } = await supabase
      .from("student_fee_accounts")
      .select("fee_structure_id")
      .in("fee_structure_id", structureIds.length > 0 ? structureIds : ["none"]);

    const countMap: Record<string, number> = {};
    (accountCounts || []).forEach((a: { fee_structure_id: string }) => {
      countMap[a.fee_structure_id] = (countMap[a.fee_structure_id] || 0) + 1;
    });

    const result = (data || []).map((s: Record<string, unknown>) => ({
      ...s,
      assigned_students: countMap[s.id as string] || 0,
    }));

    return NextResponse.json({ data: result });
  } catch (err) {
    console.error("Fee structures error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}

/** POST /api/finance/fee-structures - Create structure with items */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "finance") {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const body = await req.json();
    const { name, class_id, term_id, due_date, items } = body;

    if (!name || !term_id || !due_date || !items?.length) {
      return NextResponse.json({
        error: { message: "Required: name, term_id, due_date, and at least one item" },
      }, { status: 400 });
    }

    // Get academic year from term
    const { data: term } = await supabase
      .from("terms")
      .select("academic_year_id")
      .eq("id", term_id)
      .single();

    if (!term) {
      return NextResponse.json({ error: { message: "Invalid term" } }, { status: 400 });
    }

    const totalAmount = items.reduce((sum: number, it: { amount: number }) => sum + Number(it.amount), 0);

    // Create fee structure
    const { data: structure, error: structErr } = await supabase
      .from("fee_structures")
      .insert({
        school_id: user.school_id,
        academic_year_id: term.academic_year_id,
        term_id,
        class_id: class_id || null,
        name: name.trim(),
        total_amount: totalAmount,
        due_date,
      })
      .select()
      .single();

    if (structErr) throw structErr;

    // Create fee structure items
    const structureItems = items.map((it: { fee_type_id: string; amount: number }) => ({
      fee_structure_id: structure.id,
      fee_type_id: it.fee_type_id,
      amount: Number(it.amount),
    }));

    const { error: itemsErr } = await supabase
      .from("fee_structure_items")
      .insert(structureItems);

    if (itemsErr) throw itemsErr;

    return NextResponse.json({ data: structure }, { status: 201 });
  } catch (err) {
    console.error("Fee structure creation error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
