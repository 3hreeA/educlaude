import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";
import { generateNibssCsv, getBankCode } from "@/lib/utils/payroll";

type Ctx = { params: Promise<{ id: string }> };

// ─── GET: Payroll run detail with payslips ────────────────────────────
export async function GET(request: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const format = searchParams.get("format");

    // Payroll run
    const { data: run, error } = await supabase
      .from("payroll_runs")
      .select("*")
      .eq("id", id)
      .eq("school_id", user.school_id)
      .single();

    if (error || !run) return apiError("Payroll run not found", ErrorCodes.NOT_FOUND, 404);

    // Payslips
    const { data: payslips } = await supabase
      .from("payslips")
      .select(`*, teachers:teacher_id ( id, staff_id, users:user_id ( first_name, last_name ) )`)
      .eq("payroll_run_id", id)
      .order("created_at");

    const formattedSlips = (payslips || []).map((p: Record<string, unknown>) => {
      const t = p.teachers as Record<string, unknown> | null;
      const u = t?.users as Record<string, string> | null;
      return {
        id: p.id,
        teacher_id: t?.id,
        staff_id: t?.staff_id,
        teacher_name: u ? `${u.first_name} ${u.last_name}` : "Unknown",
        gross_salary: Number(p.gross_salary),
        tax_paye: Number(p.tax_paye),
        pension: Number(p.pension),
        nhf: Number(p.nhf),
        other_deductions: Number(p.other_deductions),
        net_salary: Number(p.net_salary),
        bank_name: p.bank_name,
        account_number: p.account_number,
      };
    });

    // NIBSS export format
    if (format === "nibss") {
      const entries = formattedSlips.map((s) => ({
        account_number: s.account_number || "",
        bank_code: getBankCode(s.bank_name as string || ""),
        amount: s.net_salary,
        narration: `Salary ${run.month}/${run.year} - ${s.teacher_name}`,
        beneficiary_name: s.teacher_name,
      }));
      const csv = generateNibssCsv(entries);
      return new Response(csv, {
        headers: {
          "Content-Type": "text/csv",
          "Content-Disposition": `attachment; filename="payroll_${run.year}_${String(run.month).padStart(2, "0")}_nibss.csv"`,
        },
      });
    }

    // Summary
    const totalGross = formattedSlips.reduce((s, p) => s + p.gross_salary, 0);
    const totalPaye = formattedSlips.reduce((s, p) => s + p.tax_paye, 0);
    const totalPension = formattedSlips.reduce((s, p) => s + p.pension, 0);
    const totalNhf = formattedSlips.reduce((s, p) => s + p.nhf, 0);
    const totalNet = formattedSlips.reduce((s, p) => s + p.net_salary, 0);

    return apiSuccess({
      run: {
        id: run.id,
        month: run.month,
        year: run.year,
        status: run.status,
        processed_at: run.processed_at,
      },
      payslips: formattedSlips,
      summary: {
        staff_count: formattedSlips.length,
        total_gross: totalGross,
        total_paye: totalPaye,
        total_pension: totalPension,
        total_nhf: totalNhf,
        total_net: totalNet,
      },
    });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── PUT: Approve / finalize payroll ──────────────────────────────────
export async function PUT(request: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { action } = body as { action: "approve" | "paid" };

    const statusMap: Record<string, string> = { approve: "approved", paid: "paid" };
    const newStatus = statusMap[action];
    if (!newStatus) return apiError("action must be 'approve' or 'paid'", ErrorCodes.VALIDATION_ERROR, 422);

    const { data: updated, error } = await supabase
      .from("payroll_runs")
      .update({
        status: newStatus,
        processed_by: user.id,
        processed_at: new Date().toISOString(),
      })
      .eq("id", id)
      .eq("school_id", user.school_id)
      .select("*")
      .single();

    if (error || !updated) return apiError("Failed to update", ErrorCodes.INTERNAL_ERROR, 500);
    return apiSuccess(updated);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
