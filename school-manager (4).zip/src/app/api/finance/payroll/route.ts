import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";
import { computePayslip } from "@/lib/utils/payroll";

// ─── GET: List payroll runs ───────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { data: runs, error } = await supabase
      .from("payroll_runs")
      .select(`id, month, year, status, processed_at, created_at,
               processor:processed_by ( first_name, last_name )`)
      .eq("school_id", user.school_id)
      .order("year", { ascending: false })
      .order("month", { ascending: false });

    if (error) {
      console.error("Payroll runs error:", error);
      return apiError("Failed to fetch", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Get payslip summary per run
    const runIds = (runs || []).map((r: { id: string }) => r.id);
    const { data: slips } = await supabase
      .from("payslips")
      .select("payroll_run_id, gross_salary, net_salary")
      .in("payroll_run_id", runIds.length > 0 ? runIds : ["00000000-0000-0000-0000-000000000000"]);

    const slipsByRun: Record<string, { count: number; totalGross: number; totalNet: number }> = {};
    for (const s of slips || []) {
      if (!slipsByRun[s.payroll_run_id]) slipsByRun[s.payroll_run_id] = { count: 0, totalGross: 0, totalNet: 0 };
      slipsByRun[s.payroll_run_id].count++;
      slipsByRun[s.payroll_run_id].totalGross += Number(s.gross_salary);
      slipsByRun[s.payroll_run_id].totalNet += Number(s.net_salary);
    }

    const formatted = (runs || []).map((r: Record<string, unknown>) => {
      const proc = r.processor as Record<string, string> | null;
      const summary = slipsByRun[r.id as string] || { count: 0, totalGross: 0, totalNet: 0 };
      return {
        id: r.id,
        month: r.month,
        year: r.year,
        status: r.status,
        processed_at: r.processed_at,
        processed_by_name: proc ? `${proc.first_name} ${proc.last_name}` : null,
        staff_count: summary.count,
        total_gross: summary.totalGross,
        total_net: summary.totalNet,
      };
    });

    return apiSuccess({ runs: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Generate payroll run ───────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { month, year } = body;
    if (!month || !year) return apiError("month and year required", ErrorCodes.VALIDATION_ERROR, 422);

    // Check for existing run
    const { data: existing } = await supabase
      .from("payroll_runs")
      .select("id, status")
      .eq("school_id", user.school_id)
      .eq("month", month)
      .eq("year", year)
      .single();

    if (existing) return apiError(`Payroll for ${month}/${year} already exists (${existing.status})`, ErrorCodes.VALIDATION_ERROR, 422);

    // Get all salary structures
    const { data: salaries } = await supabase
      .from("salary_structures")
      .select(`*, teachers:teacher_id ( id, staff_id, users:user_id ( first_name, last_name, is_active ) )`)
      .eq("school_id", user.school_id);

    const activeSalaries = (salaries || []).filter((s: Record<string, unknown>) => {
      const t = s.teachers as Record<string, unknown> | null;
      const u = t?.users as Record<string, unknown> | null;
      return u?.is_active;
    });

    if (activeSalaries.length === 0) return apiError("No active salary structures found", ErrorCodes.VALIDATION_ERROR, 422);

    // Create payroll run
    const { data: run, error: runErr } = await supabase
      .from("payroll_runs")
      .insert({
        school_id: user.school_id,
        month,
        year,
        status: "draft",
      })
      .select("*")
      .single();

    if (runErr) {
      console.error("Payroll run error:", runErr);
      return apiError("Failed to create payroll run", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Generate payslips
    const payslips = activeSalaries.map((s: Record<string, unknown>) => {
      const computation = computePayslip({
        basic_salary: Number(s.basic_salary),
        housing_allowance: Number(s.housing_allowance),
        transport_allowance: Number(s.transport_allowance),
        meal_allowance: Number(s.meal_allowance),
      });

      return {
        payroll_run_id: run.id,
        teacher_id: (s.teachers as Record<string, unknown>)?.id,
        gross_salary: computation.gross_salary,
        tax_paye: computation.tax_paye,
        pension: computation.pension,
        nhf: computation.nhf,
        other_deductions: 0,
        net_salary: computation.net_salary,
      };
    });

    const { error: slipErr } = await supabase.from("payslips").insert(payslips);
    if (slipErr) {
      console.error("Payslip insert error:", slipErr);
      // Clean up the run
      await supabase.from("payroll_runs").delete().eq("id", run.id);
      return apiError("Failed to generate payslips", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess({ run_id: run.id, payslips_generated: payslips.length }, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
