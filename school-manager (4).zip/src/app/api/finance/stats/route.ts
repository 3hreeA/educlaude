import { NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "finance" && user.role !== "admin")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    // Total revenue (successful payments)
    const { data: payments } = await supabase
      .from("payment_transactions")
      .select("amount, created_at, fee_account_id")
      .eq("status", "success");

    const totalRevenue = (payments || []).reduce((sum: number, p: { amount: number }) => sum + Number(p.amount), 0);

    // This month's collections
    const now = new Date();
    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
    const thisMonthRevenue = (payments || [])
      .filter((p: { created_at: string }) => p.created_at >= monthStart)
      .reduce((sum: number, p: { amount: number }) => sum + Number(p.amount), 0);

    // Outstanding fees
    const { data: feeAccounts } = await supabase
      .from("student_fee_accounts")
      .select("total_amount, amount_paid, status, balance");

    const totalOutstanding = (feeAccounts || [])
      .reduce((sum: number, a: { balance: number }) => sum + Math.max(0, Number(a.balance)), 0);

    const overdueCount = (feeAccounts || [])
      .filter((a: { status: string }) => a.status === "overdue").length;

    const totalStudentAccounts = (feeAccounts || []).length;
    const paidCount = (feeAccounts || []).filter((a: { status: string }) => a.status === "paid").length;
    const collectionRate = totalStudentAccounts > 0 ? Math.round((paidCount / totalStudentAccounts) * 100) : 0;

    return NextResponse.json({
      data: {
        total_revenue: totalRevenue,
        this_month_revenue: thisMonthRevenue,
        total_outstanding: totalOutstanding,
        overdue_count: overdueCount,
        total_accounts: totalStudentAccounts,
        paid_accounts: paidCount,
        collection_rate: collectionRate,
      },
    });
  } catch (err) {
    console.error("Finance stats error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
