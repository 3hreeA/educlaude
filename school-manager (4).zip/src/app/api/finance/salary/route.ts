import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List salary structures ──────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { data: salaries, error } = await supabase
      .from("salary_structures")
      .select(`id, basic_salary, housing_allowance, transport_allowance, meal_allowance, effective_date,
               teachers:teacher_id ( id, staff_id, users:user_id ( first_name, last_name, is_active ) )`)
      .eq("school_id", user.school_id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Salary query error:", error);
      return apiError("Failed to fetch", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (salaries || []).map((s: Record<string, unknown>) => {
      const t = s.teachers as Record<string, unknown> | null;
      const u = t?.users as Record<string, unknown> | null;
      const gross = Number(s.basic_salary) + Number(s.housing_allowance) + Number(s.transport_allowance) + Number(s.meal_allowance);
      return {
        id: s.id,
        teacher_id: t?.id,
        staff_id: t?.staff_id,
        teacher_name: u ? `${u.first_name} ${u.last_name}` : "Unknown",
        is_active: u?.is_active ?? true,
        basic_salary: Number(s.basic_salary),
        housing_allowance: Number(s.housing_allowance),
        transport_allowance: Number(s.transport_allowance),
        meal_allowance: Number(s.meal_allowance),
        gross_salary: gross,
        effective_date: s.effective_date,
      };
    });

    return apiSuccess({ salaries: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Create / update salary structure ───────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { teacher_id, basic_salary, housing_allowance, transport_allowance, meal_allowance, effective_date } = body;

    if (!teacher_id || !basic_salary) {
      return apiError("teacher_id and basic_salary required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const { data, error } = await supabase
      .from("salary_structures")
      .upsert({
        school_id: user.school_id,
        teacher_id,
        basic_salary: basic_salary || 0,
        housing_allowance: housing_allowance || 0,
        transport_allowance: transport_allowance || 0,
        meal_allowance: meal_allowance || 0,
        effective_date: effective_date || new Date().toISOString().split("T")[0],
      }, { onConflict: "school_id,teacher_id" })
      .select("*")
      .single();

    if (error) {
      console.error("Salary save error:", error);
      // If upsert conflict issue, try a different approach
      const { data: existing } = await supabase
        .from("salary_structures")
        .select("id")
        .eq("school_id", user.school_id)
        .eq("teacher_id", teacher_id)
        .single();

      if (existing) {
        const { data: updated, error: updateErr } = await supabase
          .from("salary_structures")
          .update({
            basic_salary: basic_salary || 0,
            housing_allowance: housing_allowance || 0,
            transport_allowance: transport_allowance || 0,
            meal_allowance: meal_allowance || 0,
            effective_date: effective_date || new Date().toISOString().split("T")[0],
          })
          .eq("id", existing.id)
          .select("*")
          .single();

        if (updateErr) return apiError("Failed to update", ErrorCodes.INTERNAL_ERROR, 500);
        return apiSuccess(updated);
      }
      return apiError("Failed to save salary", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(data, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
