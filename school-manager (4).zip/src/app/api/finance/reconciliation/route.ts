import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: Daily reconciliation summary ────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const dateStr = searchParams.get("date") || new Date().toISOString().split("T")[0];
    const startOfDay = `${dateStr}T00:00:00Z`;
    const endOfDay = `${dateStr}T23:59:59Z`;

    // Get all transactions for the date
    const { data: transactions } = await supabase
      .from("payment_transactions")
      .select(`id, amount, payment_method, payment_reference, gateway_reference, status, receipt_number, created_at, metadata,
               student_fee_accounts:fee_account_id (
                 students:student_id ( first_name, last_name, admission_number ),
                 fee_structures:fee_structure_id ( name )
               )`)
      .gte("created_at", startOfDay)
      .lte("created_at", endOfDay)
      .order("created_at", { ascending: false });

    const txns = transactions || [];

    // Compute summary
    const successful = txns.filter((t: { status: string }) => t.status === "success");
    const pending = txns.filter((t: { status: string }) => t.status === "pending");
    const failed = txns.filter((t: { status: string }) => t.status === "failed");

    const totalSuccess = successful.reduce((s: number, t: { amount: number }) => s + Number(t.amount), 0);
    const totalPending = pending.reduce((s: number, t: { amount: number }) => s + Number(t.amount), 0);

    // Payment method breakdown
    const methodBreakdown: Record<string, { count: number; amount: number }> = {};
    for (const t of successful) {
      const m = (t as Record<string, unknown>).payment_method as string;
      if (!methodBreakdown[m]) methodBreakdown[m] = { count: 0, amount: 0 };
      methodBreakdown[m].count++;
      methodBreakdown[m].amount += Number((t as Record<string, unknown>).amount);
    }

    // Format transactions
    const formatted = txns.map((t: Record<string, unknown>) => {
      const acct = t.student_fee_accounts as Record<string, unknown> | null;
      const student = acct?.students as Record<string, string> | null;
      const fee = acct?.fee_structures as Record<string, string> | null;
      return {
        id: t.id,
        amount: Number(t.amount),
        payment_method: t.payment_method,
        payment_reference: t.payment_reference,
        gateway_reference: t.gateway_reference,
        status: t.status,
        receipt_number: t.receipt_number,
        created_at: t.created_at,
        student_name: student ? `${student.first_name} ${student.last_name}` : "Unknown",
        admission_number: student?.admission_number || "",
        fee_name: fee?.name || "",
        reconciled: t.status === "success" && !!t.gateway_reference,
      };
    });

    return apiSuccess({
      date: dateStr,
      transactions: formatted,
      summary: {
        total_transactions: txns.length,
        successful_count: successful.length,
        successful_amount: totalSuccess,
        pending_count: pending.length,
        pending_amount: totalPending,
        failed_count: failed.length,
        method_breakdown: methodBreakdown,
        reconciled: successful.filter((t: Record<string, unknown>) => !!t.gateway_reference).length,
        unreconciled: successful.filter((t: Record<string, unknown>) => !t.gateway_reference).length,
      },
    });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Manual reconciliation (mark transaction as reconciled) ─────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { transaction_id, gateway_reference, notes } = body;

    if (!transaction_id) return apiError("transaction_id required", ErrorCodes.VALIDATION_ERROR, 422);

    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (gateway_reference) updates.gateway_reference = gateway_reference;
    if (notes) {
      // Store reconciliation notes in metadata
      const { data: txn } = await supabase.from("payment_transactions").select("metadata").eq("id", transaction_id).single();
      const meta = (txn?.metadata || {}) as Record<string, unknown>;
      meta.reconciliation_notes = notes;
      meta.reconciled_by = user.id;
      meta.reconciled_at = new Date().toISOString();
      updates.metadata = meta;
    }

    const { data, error } = await supabase
      .from("payment_transactions")
      .update(updates)
      .eq("id", transaction_id)
      .select("id, gateway_reference, status")
      .single();

    if (error || !data) return apiError("Failed to update", ErrorCodes.INTERNAL_ERROR, 500);
    return apiSuccess(data);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
