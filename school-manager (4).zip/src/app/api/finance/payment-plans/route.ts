import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List payment plans ──────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("role, school_id").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let query = supabase
      .from("payment_plans")
      .select(`id, total_amount, installments, amount_per_installment, start_date, status, notes, created_at,
               student_fee_accounts:fee_account_id (
                 id, total_amount, amount_paid, balance, status,
                 students:student_id ( id, first_name, last_name, admission_number, classes:class_id ( name ) ),
                 fee_structures:fee_structure_id ( name )
               ),
               payment_plan_items ( id, installment_number, due_date, amount, paid, paid_at )`)
      .order("created_at", { ascending: false });

    if (status && status !== "all") query = query.eq("status", status);

    const { data: plans, error } = await query;
    if (error) {
      console.error("Plans query error:", error);
      return apiError("Failed to fetch", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (plans || []).map((p: Record<string, unknown>) => {
      const acct = p.student_fee_accounts as Record<string, unknown> | null;
      const student = acct?.students as Record<string, unknown> | null;
      const cls = student?.classes as Record<string, string> | null;
      const fee = acct?.fee_structures as Record<string, string> | null;
      const items = (p.payment_plan_items || []) as Array<Record<string, unknown>>;

      return {
        id: p.id,
        total_amount: Number(p.total_amount),
        installments: p.installments,
        amount_per_installment: Number(p.amount_per_installment),
        start_date: p.start_date,
        status: p.status,
        notes: p.notes,
        created_at: p.created_at,
        student_name: student ? `${student.first_name} ${student.last_name}` : "Unknown",
        admission_number: student?.admission_number || "",
        class_name: cls?.name || "",
        fee_name: fee?.name || "",
        fee_account_balance: acct ? Number(acct.balance) : 0,
        items: items
          .sort((a, b) => Number(a.installment_number) - Number(b.installment_number))
          .map((i) => ({
            id: i.id,
            number: i.installment_number,
            due_date: i.due_date,
            amount: Number(i.amount),
            paid: i.paid,
            paid_at: i.paid_at,
          })),
      };
    });

    return apiSuccess({ plans: formatted });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Create payment plan ────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id, role").eq("auth_id", session.user.id).single();
    if (!user || !["finance", "admin"].includes(user.role)) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { fee_account_id, installments, start_date, notes } = body;

    if (!fee_account_id || !installments || !start_date) {
      return apiError("fee_account_id, installments, start_date required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Get fee account balance
    const { data: acct } = await supabase
      .from("student_fee_accounts")
      .select("balance")
      .eq("id", fee_account_id)
      .single();

    if (!acct || Number(acct.balance) <= 0) return apiError("No outstanding balance", ErrorCodes.VALIDATION_ERROR, 422);

    const totalAmount = Number(acct.balance);
    const perInstallment = Math.round((totalAmount / installments) * 100) / 100;

    // Create plan
    const { data: plan, error: planErr } = await supabase
      .from("payment_plans")
      .insert({
        fee_account_id,
        total_amount: totalAmount,
        installments,
        amount_per_installment: perInstallment,
        start_date,
        notes: notes || null,
        created_by: user.id,
      })
      .select("*")
      .single();

    if (planErr) {
      console.error("Plan create error:", planErr);
      return apiError("Failed to create plan", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Create installment items
    const items = [];
    const sd = new Date(start_date);
    let remaining = totalAmount;

    for (let i = 1; i <= installments; i++) {
      const dueDate = new Date(sd);
      dueDate.setDate(dueDate.getDate() + (i - 1) * 30); // 30-day intervals
      const amount = i === installments ? remaining : perInstallment;
      remaining -= perInstallment;
      items.push({
        plan_id: plan.id,
        installment_number: i,
        due_date: dueDate.toISOString().split("T")[0],
        amount,
      });
    }

    const { error: itemErr } = await supabase.from("payment_plan_items").insert(items);
    if (itemErr) {
      console.error("Plan items error:", itemErr);
    }

    return apiSuccess(plan, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
