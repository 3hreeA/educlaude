import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/finance/payments?status=&method=&page=1&limit=20 */
export async function GET(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "finance" && user.role !== "admin")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const url = req.nextUrl;
    const status = url.searchParams.get("status");
    const method = url.searchParams.get("method");
    const page = parseInt(url.searchParams.get("page") || "1");
    const limit = Math.min(parseInt(url.searchParams.get("limit") || "20"), 50);
    const offset = (page - 1) * limit;

    let query = supabase
      .from("payment_transactions")
      .select(`
        id, amount, payment_method, payment_reference, gateway_reference,
        status, receipt_number, created_at, metadata,
        student_fee_accounts!inner (
          id, student_id,
          students!inner ( id, first_name, last_name, admission_number,
            classes ( name )
          ),
          fee_structures ( name )
        )
      `, { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (status) query = query.eq("status", status);
    if (method) query = query.eq("payment_method", method);

    const { data, count, error } = await query;
    if (error) throw error;

    return NextResponse.json({
      data: {
        payments: data || [],
        pagination: { page, limit, total: count || 0, total_pages: Math.ceil((count || 0) / limit) },
      },
    });
  } catch (err) {
    console.error("Finance payments error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
