import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

/** GET /api/finance/outstanding?class_id=&aging=&page=1&limit=20 */
export async function GET(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || (user.role !== "finance" && user.role !== "admin")) {
      return NextResponse.json({ error: { message: "Forbidden" } }, { status: 403 });
    }

    const url = req.nextUrl;
    const classId = url.searchParams.get("class_id");
    const aging = url.searchParams.get("aging"); // "30", "60", "90"
    const page = parseInt(url.searchParams.get("page") || "1");
    const limit = Math.min(parseInt(url.searchParams.get("limit") || "20"), 50);
    const offset = (page - 1) * limit;

    let query = supabase
      .from("student_fee_accounts")
      .select(`
        id, total_amount, amount_paid, balance, status, due_date,
        students!inner (
          id, admission_number, first_name, last_name, photo_url,
          classes!inner ( id, name, level )
        ),
        fee_structures ( id, name, terms ( name ) )
      `, { count: "exact" })
      .in("status", ["current", "partial", "overdue"])
      .gt("balance", 0)
      .order("balance", { ascending: false });

    if (classId) {
      query = query.eq("students.class_id", classId);
    }

    if (aging) {
      const now = new Date();
      const daysAgo = new Date(now.getTime() - parseInt(aging) * 24 * 60 * 60 * 1000);
      query = query.lt("due_date", daysAgo.toISOString().split("T")[0]);
    }

    query = query.range(offset, offset + limit - 1);

    const { data, count, error } = await query;
    if (error) throw error;

    // Calculate aging summary
    const { data: allOutstanding } = await supabase
      .from("student_fee_accounts")
      .select("balance, due_date, status")
      .in("status", ["current", "partial", "overdue"])
      .gt("balance", 0);

    const now = new Date();
    const summary = {
      current: 0,
      days_30: 0,
      days_60: 0,
      days_90_plus: 0,
      total: 0,
    };

    (allOutstanding || []).forEach((a: { balance: number; due_date: string }) => {
      const bal = Number(a.balance);
      const daysPastDue = Math.floor((now.getTime() - new Date(a.due_date).getTime()) / (1000 * 60 * 60 * 24));
      summary.total += bal;
      if (daysPastDue <= 0) summary.current += bal;
      else if (daysPastDue <= 30) summary.days_30 += bal;
      else if (daysPastDue <= 60) summary.days_60 += bal;
      else summary.days_90_plus += bal;
    });

    return NextResponse.json({
      data: {
        accounts: data || [],
        summary,
        pagination: {
          page, limit,
          total: count || 0,
          total_pages: Math.ceil((count || 0) / limit),
        },
      },
    });
  } catch (err) {
    console.error("Outstanding fees error:", err);
    return NextResponse.json({ error: { message: "Internal server error" } }, { status: 500 });
  }
}
