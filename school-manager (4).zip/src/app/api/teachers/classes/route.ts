import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    // Get teacher record for this user
    const { data: teacher, error: teacherErr } = await supabase
      .from("teachers")
      .select("id")
      .eq("user_id", session.user.id)
      .single();

    if (teacherErr || !teacher) {
      return apiError("Teacher profile not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get current academic year
    const { data: currentYear } = await supabase
      .from("academic_years")
      .select("id")
      .eq("is_current", true)
      .single();

    if (!currentYear) {
      return apiSuccess([]);
    }

    // Get teacher assignments with class details and subjects
    const { data: assignments, error: assignErr } = await supabase
      .from("teacher_assignments")
      .select(`
        id, is_class_teacher, subject_id,
        classes:class_id (id, name, level),
        subjects:subject_id (id, name, code)
      `)
      .eq("teacher_id", teacher.id)
      .eq("academic_year_id", currentYear.id);

    if (assignErr) {
      console.error("Assignments query error:", assignErr);
      return apiError("Failed to fetch classes", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Group assignments by class
    const classMap = new Map<string, any>();
    for (const a of assignments || []) {
      const cls = a.classes as any;
      if (!cls) continue;

      if (!classMap.has(cls.id)) {
        classMap.set(cls.id, {
          id: cls.id,
          name: cls.name,
          level: cls.level,
          is_class_teacher: false,
          subjects: [],
        });
      }

      const entry = classMap.get(cls.id)!;
      if (a.is_class_teacher) entry.is_class_teacher = true;

      const subj = a.subjects as any;
      if (subj) {
        entry.subjects.push({ id: subj.id, name: subj.name, code: subj.code });
      }
    }

    // Get student counts per class
    const classIds = Array.from(classMap.keys());
    const classes = [];

    for (const classId of classIds) {
      const { count } = await supabase
        .from("students")
        .select("id", { count: "exact", head: true })
        .eq("class_id", classId)
        .eq("is_active", true);

      const entry = classMap.get(classId)!;
      entry.student_count = count || 0;

      // Check if attendance is marked for today
      const today = new Date().toISOString().split("T")[0];
      const { count: attendanceCount } = await supabase
        .from("attendance_records")
        .select("id", { count: "exact", head: true })
        .eq("class_id", classId)
        .eq("date", today);

      entry.attendance_marked_today = (attendanceCount || 0) > 0;
      classes.push(entry);
    }

    return apiSuccess(classes);
  } catch (err) {
    console.error("Error fetching teacher classes:", err);
    return apiError("Failed to fetch classes", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
