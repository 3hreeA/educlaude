import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { classId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { classId } = params;

    // Fetch active students in this class
    const { data: students, error } = await supabase
      .from("students")
      .select("id, admission_number, first_name, last_name, middle_name, gender, photo_url, medical_notes")
      .eq("class_id", classId)
      .eq("is_active", true)
      .order("last_name", { ascending: true })
      .order("first_name", { ascending: true });

    if (error) {
      console.error("Students query error:", error);
      return apiError("Failed to fetch students", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(students || []);
  } catch (err) {
    console.error("Error fetching class students:", err);
    return apiError("Failed to fetch students", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
