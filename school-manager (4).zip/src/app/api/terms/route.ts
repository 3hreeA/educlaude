import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { data: user } = await supabase
      .from("users")
      .select("school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user) {
      return apiError("User not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get current academic year's terms
    const { data: currentYear } = await supabase
      .from("academic_years")
      .select("id, name")
      .eq("school_id", user.school_id)
      .eq("is_current", true)
      .single();

    if (!currentYear) {
      return apiSuccess({ terms: [], current_term: null, academic_year: null });
    }

    const { data: terms } = await supabase
      .from("terms")
      .select("id, name, start_date, end_date, is_current")
      .eq("academic_year_id", currentYear.id)
      .order("start_date");

    const currentTerm = terms?.find((t) => t.is_current) || null;

    return apiSuccess({
      terms: terms || [],
      current_term: currentTerm,
      academic_year: currentYear,
    });
  } catch (err) {
    console.error("Error fetching terms:", err);
    return apiError("Failed to fetch terms", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
