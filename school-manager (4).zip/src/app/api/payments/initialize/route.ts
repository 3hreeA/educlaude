import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { initializePayment, generatePaymentReference } from "@/lib/integrations/paystack";

/** POST /api/payments/initialize - Start Paystack payment */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const { data: user } = await supabase
      .from("users")
      .select("id, email, school_id, role")
      .eq("auth_id", session.user.id)
      .single();

    if (!user) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const body = await req.json();
    const { fee_account_id, amount } = body;

    if (!fee_account_id || !amount || amount <= 0) {
      return NextResponse.json(
        { error: { message: "fee_account_id and positive amount are required" } },
        { status: 400 }
      );
    }

    // Validate fee account and balance
    const { data: account, error: accErr } = await supabase
      .from("student_fee_accounts")
      .select(`
        id, balance, student_id,
        students ( first_name, last_name ),
        fee_structures ( name )
      `)
      .eq("id", fee_account_id)
      .single();

    if (accErr || !account) {
      return NextResponse.json({ error: { message: "Fee account not found" } }, { status: 404 });
    }

    if (amount > Number(account.balance)) {
      return NextResponse.json(
        { error: { message: `Amount exceeds outstanding balance of ${account.balance}` } },
        { status: 400 }
      );
    }

    const reference = generatePaymentReference();
    const origin = req.headers.get("origin") || process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const callbackUrl = `${origin}/parent/fees/verify?reference=${reference}`;

    // Create pending transaction record
    const { error: txErr } = await supabase
      .from("payment_transactions")
      .insert({
        fee_account_id,
        amount: Number(amount),
        payment_method: "card",
        payment_reference: reference,
        status: "pending",
        paid_by: user.id,
        metadata: {
          student_name: `${(account.students as Record<string, string>)?.first_name} ${(account.students as Record<string, string>)?.last_name}`,
          fee_structure: (account.fee_structures as Record<string, string>)?.name,
        },
      });

    if (txErr) throw txErr;

    // Initialize Paystack
    const paystackRes = await initializePayment({
      email: user.email,
      amount: Number(amount),
      reference,
      callback_url: callbackUrl,
      metadata: {
        fee_account_id,
        student_id: account.student_id,
        user_id: user.id,
      },
    });

    return NextResponse.json({
      data: {
        authorization_url: paystackRes.data.authorization_url,
        access_code: paystackRes.data.access_code,
        reference: paystackRes.data.reference,
      },
    });
  } catch (err) {
    console.error("Payment initialize error:", err);
    return NextResponse.json({ error: { message: "Payment initialization failed" } }, { status: 500 });
  }
}
