import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

/** GET /api/payments/receipt?ref=xxx */
export async function GET(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const ref = req.nextUrl.searchParams.get("ref");
    if (!ref) return apiError("Payment reference required", ErrorCodes.VALIDATION_ERROR, 400);

    const { data: transaction, error } = await supabase
      .from("payment_transactions")
      .select(`
        id, amount, payment_method, payment_reference, gateway_reference,
        status, receipt_number, created_at, metadata,
        student_fee_accounts:fee_account_id (
          id, total_amount, amount_paid, balance,
          students:student_id (
            id, first_name, last_name, admission_number,
            classes:class_id ( id, name )
          ),
          fee_structures:fee_structure_id (
            id, name,
            terms:term_id ( name ),
            academic_years:academic_year_id ( name )
          )
        )
      `)
      .eq("payment_reference", ref)
      .single();

    if (error || !transaction) {
      return apiError("Receipt not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get school info
    const { data: school } = await supabase
      .from("school")
      .select("name, address, phone, email, logo_url")
      .limit(1)
      .single();

    return apiSuccess({
      transaction,
      school: school || { name: "School Manager", address: "", phone: "", email: "" },
    });
  } catch (err) {
    console.error("Receipt fetch error:", err);
    return apiError("Failed to fetch receipt", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
