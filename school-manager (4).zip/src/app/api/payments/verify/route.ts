import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { verifyPayment } from "@/lib/integrations/paystack";

/** POST /api/payments/verify - Verify payment after Paystack redirect */
export async function POST(req: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return NextResponse.json({ error: { message: "Unauthorized" } }, { status: 401 });

    const body = await req.json();
    const { reference } = body;

    if (!reference) {
      return NextResponse.json({ error: { message: "Payment reference is required" } }, { status: 400 });
    }

    // Get the pending transaction
    const { data: transaction, error: txErr } = await supabase
      .from("payment_transactions")
      .select("id, fee_account_id, amount, status")
      .eq("payment_reference", reference)
      .single();

    if (txErr || !transaction) {
      return NextResponse.json({ error: { message: "Transaction not found" } }, { status: 404 });
    }

    // Already processed?
    if (transaction.status === "success") {
      return NextResponse.json({
        data: { status: "success", message: "Payment already verified", transaction_id: transaction.id },
      });
    }

    // Verify with Paystack
    let paystackStatus: "success" | "failed" = "failed";
    let gatewayRef = "";
    let metadata: Record<string, unknown> = {};

    try {
      const result = await verifyPayment(reference);
      if (result.data.status === "success") {
        paystackStatus = "success";
        gatewayRef = String(result.data.id);
        metadata = {
          channel: result.data.channel,
          card_type: result.data.authorization?.card_type,
          last4: result.data.authorization?.last4,
          bank: result.data.authorization?.bank,
          gateway_response: result.data.gateway_response,
        };
      }
    } catch (verifyErr) {
      console.error("Paystack verification error:", verifyErr);
      // If Paystack is down or key not configured, allow manual testing
      // In production, this would be a hard fail
      if (process.env.NODE_ENV === "development" || process.env.PAYSTACK_TEST_MODE === "true") {
        paystackStatus = "success";
        gatewayRef = `DEV-${Date.now()}`;
        metadata = { channel: "test", note: "Development mode - auto-verified" };
      }
    }

    // Generate receipt number
    const receiptNumber = paystackStatus === "success"
      ? `RCP-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`
      : null;

    // Update transaction
    await supabase
      .from("payment_transactions")
      .update({
        status: paystackStatus,
        gateway_reference: gatewayRef,
        receipt_number: receiptNumber,
        metadata,
      })
      .eq("id", transaction.id);

    // If successful, update fee account
    if (paystackStatus === "success") {
      const { data: account } = await supabase
        .from("student_fee_accounts")
        .select("amount_paid, total_amount")
        .eq("id", transaction.fee_account_id)
        .single();

      if (account) {
        const newPaid = Number(account.amount_paid) + Number(transaction.amount);
        const newStatus = newPaid >= Number(account.total_amount) ? "paid" : "partial";

        await supabase
          .from("student_fee_accounts")
          .update({
            amount_paid: newPaid,
            status: newStatus,
          })
          .eq("id", transaction.fee_account_id);
      }
    }

    return NextResponse.json({
      data: {
        status: paystackStatus,
        transaction_id: transaction.id,
        receipt_number: receiptNumber,
        amount: transaction.amount,
        message: paystackStatus === "success" ? "Payment verified successfully" : "Payment verification failed",
      },
    });
  } catch (err) {
    console.error("Payment verify error:", err);
    return NextResponse.json({ error: { message: "Payment verification failed" } }, { status: 500 });
  }
}
