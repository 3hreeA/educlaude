import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── GET: List messages (inbox or thread) ─────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id").eq("auth_id", session.user.id).single();
    if (!user) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const { searchParams } = new URL(request.url);
    const threadId = searchParams.get("thread_id");
    const contactId = searchParams.get("contact_id");

    if (threadId) {
      // Get messages in a thread
      const { data: messages } = await supabase
        .from("direct_messages")
        .select(`id, content, subject, created_at, read_at,
                 sender:sender_id ( id, first_name, last_name, role )`)
        .eq("thread_id", threadId)
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order("created_at", { ascending: true });

      // Mark as read
      await supabase
        .from("direct_messages")
        .update({ read_at: new Date().toISOString() })
        .eq("thread_id", threadId)
        .eq("recipient_id", user.id)
        .is("read_at", null);

      return apiSuccess({ messages: messages || [] });
    }

    // Get inbox: latest message per conversation partner
    const { data: received } = await supabase
      .from("direct_messages")
      .select(`id, content, subject, created_at, read_at, thread_id,
               sender:sender_id ( id, first_name, last_name, role )`)
      .eq("recipient_id", user.id)
      .order("created_at", { ascending: false });

    const { data: sent } = await supabase
      .from("direct_messages")
      .select(`id, content, subject, created_at, read_at, thread_id,
               recipient:recipient_id ( id, first_name, last_name, role )`)
      .eq("sender_id", user.id)
      .order("created_at", { ascending: false });

    // Build conversation list (group by contact)
    const convMap: Record<string, {
      contact_id: string;
      contact_name: string;
      contact_role: string;
      thread_id: string | null;
      last_message: string;
      last_at: string;
      unread: number;
    }> = {};

    for (const m of received || []) {
      const s = m.sender as Record<string, string> | null;
      if (!s) continue;
      const cid = s.id;
      if (!convMap[cid] || m.created_at > convMap[cid].last_at) {
        convMap[cid] = {
          contact_id: cid,
          contact_name: `${s.first_name} ${s.last_name}`,
          contact_role: s.role,
          thread_id: m.thread_id,
          last_message: m.content?.slice(0, 100) || "",
          last_at: m.created_at,
          unread: 0,
        };
      }
      if (!m.read_at) convMap[cid].unread++;
    }

    for (const m of sent || []) {
      const r = m.recipient as Record<string, string> | null;
      if (!r) continue;
      const cid = r.id;
      if (!convMap[cid] || m.created_at > convMap[cid].last_at) {
        convMap[cid] = {
          contact_id: cid,
          contact_name: `${r.first_name} ${r.last_name}`,
          contact_role: r.role,
          thread_id: m.thread_id,
          last_message: m.content?.slice(0, 100) || "",
          last_at: m.created_at,
          unread: convMap[cid]?.unread || 0,
        };
      }
    }

    const conversations = Object.values(convMap).sort((a, b) => b.last_at.localeCompare(a.last_at));
    const totalUnread = conversations.reduce((s, c) => s + c.unread, 0);

    return apiSuccess({ conversations, total_unread: totalUnread });
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── POST: Send a message ─────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Unauthorized", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase.from("users").select("id").eq("auth_id", session.user.id).single();
    if (!user) return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);

    const body = await request.json();
    const { recipient_id, content, subject, thread_id } = body;

    if (!recipient_id || !content) {
      return apiError("recipient_id and content required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Generate thread_id if new conversation
    const tid = thread_id || crypto.randomUUID();

    const { data, error } = await supabase
      .from("direct_messages")
      .insert({
        sender_id: user.id,
        recipient_id,
        thread_id: tid,
        subject: subject || null,
        content,
      })
      .select("id, thread_id, created_at")
      .single();

    if (error) {
      console.error("Message send error:", error);
      return apiError("Failed to send", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(data, 201);
  } catch (err) {
    console.error("Error:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
