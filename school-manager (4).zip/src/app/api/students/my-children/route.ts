import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    // Get parent record
    const { data: parent, error: parentErr } = await supabase
      .from("parents")
      .select("id")
      .eq("user_id", session.user.id)
      .single();

    if (parentErr || !parent) {
      return apiError("Parent profile not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get student IDs linked to this parent
    const { data: links } = await supabase
      .from("student_parents")
      .select("student_id")
      .eq("parent_id", parent.id);

    if (!links || links.length === 0) {
      return apiSuccess([]);
    }

    const studentIds = links.map((l) => l.student_id);

    // Get students with class info
    const { data: students } = await supabase
      .from("students")
      .select(`
        id, admission_number, first_name, last_name, middle_name,
        gender, date_of_birth, photo_url, is_active,
        classes:class_id ( id, name, level )
      `)
      .in("id", studentIds)
      .eq("is_active", true)
      .order("first_name");

    if (!students) {
      return apiSuccess([]);
    }

    // Get current term
    const { data: currentTerm } = await supabase
      .from("terms")
      .select("id")
      .eq("is_current", true)
      .single();

    const termId = currentTerm?.id;

    // Enrich each student with attendance %, fee balance
    const enriched = await Promise.all(
      students.map(async (student) => {
        let attendancePct: number | null = null;
        let feeBalance: number = 0;
        let feeStatus: string | null = null;

        // Attendance percentage for current term
        if (termId) {
          const { count: totalDays } = await supabase
            .from("attendance_records")
            .select("id", { count: "exact", head: true })
            .eq("student_id", student.id)
            .eq("term_id", termId);

          const { count: presentDays } = await supabase
            .from("attendance_records")
            .select("id", { count: "exact", head: true })
            .eq("student_id", student.id)
            .eq("term_id", termId)
            .in("status", ["present", "late"]);

          if (totalDays && totalDays > 0) {
            attendancePct = Math.round(((presentDays || 0) / totalDays) * 100);
          }
        }

        // Fee accounts: sum balances
        const { data: feeAccounts } = await supabase
          .from("student_fee_accounts")
          .select("balance, status")
          .eq("student_id", student.id)
          .neq("status", "paid");

        if (feeAccounts && feeAccounts.length > 0) {
          feeBalance = feeAccounts.reduce((sum, fa) => sum + (fa.balance || 0), 0);
          // If any overdue, mark overdue; else partial; else current
          const hasOverdue = feeAccounts.some((fa) => fa.status === "overdue");
          feeStatus = hasOverdue ? "overdue" : feeBalance > 0 ? "partial" : "current";
        } else {
          feeStatus = "paid";
        }

        return {
          id: student.id,
          admission_number: student.admission_number,
          first_name: student.first_name,
          last_name: student.last_name,
          middle_name: student.middle_name,
          gender: student.gender,
          date_of_birth: student.date_of_birth,
          photo_url: student.photo_url,
          class_name: (student.classes as any)?.name || "Unassigned",
          class_level: (student.classes as any)?.level || "",
          attendance_percentage: attendancePct,
          fee_balance: feeBalance,
          fee_status: feeStatus,
        };
      })
    );

    return apiSuccess(enriched);
  } catch (err) {
    console.error("Error fetching children:", err);
    return apiError("Failed to fetch children", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
