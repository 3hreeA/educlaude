import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { studentId } = params;

    const { data: user } = await supabase
      .from("users")
      .select("role")
      .eq("auth_id", session.user.id)
      .single();

    if (user?.role === "parent") {
      const { data: parent } = await supabase
        .from("parents")
        .select("id")
        .eq("user_id", session.user.id)
        .single();

      if (!parent) return apiError("Parent profile not found", ErrorCodes.NOT_FOUND, 404);

      const { data: link } = await supabase
        .from("student_parents")
        .select("id")
        .eq("parent_id", parent.id)
        .eq("student_id", studentId)
        .single();

      if (!link) return apiError("Access denied", ErrorCodes.FORBIDDEN, 403);
    }

    // Fetch student with class info
    const { data: student, error } = await supabase
      .from("students")
      .select(`
        *,
        classes:class_id ( id, name, level, arm )
      `)
      .eq("id", studentId)
      .single();

    if (error || !student) {
      return apiError("Student not found", ErrorCodes.NOT_FOUND, 404);
    }

    // For admin/finance: also fetch parent info and fee summary
    if (user?.role === "admin" || user?.role === "finance") {
      const { data: parentLinks } = await supabase
        .from("student_parents")
        .select(`
          relationship,
          parents ( id, first_name, last_name, email, phone, whatsapp_number )
        `)
        .eq("student_id", studentId);

      const { data: feeAccounts } = await supabase
        .from("student_fee_accounts")
        .select("id, total_amount, amount_paid, balance, status, due_date")
        .eq("student_id", studentId);

      const totalDue = (feeAccounts || []).reduce((s, a) => s + a.total_amount, 0);
      const totalPaid = (feeAccounts || []).reduce((s, a) => s + a.amount_paid, 0);
      const totalBalance = (feeAccounts || []).reduce((s, a) => s + a.balance, 0);

      return apiSuccess({
        ...student,
        parents: (parentLinks || []).map((l) => ({
          ...(l.parents as Record<string, unknown>),
          relationship: l.relationship,
        })),
        fee_summary: { total_due: totalDue, total_paid: totalPaid, total_balance: totalBalance },
      });
    }

    return apiSuccess(student);
  } catch (err) {
    console.error("Error fetching student:", err);
    return apiError("Failed to fetch student", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

/** PUT /api/students/[studentId] - Update student (admin only) */
export async function PUT(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return apiError("Forbidden", ErrorCodes.FORBIDDEN, 403);
    }

    const body = await request.json();
    const { studentId } = params;

    const allowedFields: Record<string, unknown> = {};
    const editableKeys = [
      "first_name", "last_name", "middle_name", "gender", "date_of_birth",
      "address", "blood_group", "genotype", "medical_notes", "class_id", "is_active",
    ];

    for (const key of editableKeys) {
      if (body[key] !== undefined) allowedFields[key] = body[key];
    }

    if (Object.keys(allowedFields).length === 0) {
      return apiError("No valid fields to update", ErrorCodes.VALIDATION_ERROR, 400);
    }

    const { data: updated, error } = await supabase
      .from("students")
      .update(allowedFields)
      .eq("id", studentId)
      .select("*, classes:class_id ( id, name, level, arm )")
      .single();

    if (error) throw error;

    return apiSuccess(updated);
  } catch (err) {
    console.error("Error updating student:", err);
    return apiError("Failed to update student", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
