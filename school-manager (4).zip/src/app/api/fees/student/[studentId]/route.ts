import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { studentId } = params;

    // Get fee accounts for this student
    const { data: feeAccounts, error: faErr } = await supabase
      .from("student_fee_accounts")
      .select(`
        id, total_amount, amount_paid, balance, status, due_date,
        fee_structures:fee_structure_id (
          id, name, total_amount,
          terms:term_id ( id, name ),
          academic_years:academic_year_id ( id, name )
        )
      `)
      .eq("student_id", studentId)
      .order("due_date", { ascending: false });

    if (faErr) {
      console.error("Fee accounts query error:", faErr);
      return apiError("Failed to fetch fee accounts", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // Get payment transactions for all fee accounts
    const feeAccountIds = (feeAccounts || []).map((fa) => fa.id);

    let payments: any[] = [];
    if (feeAccountIds.length > 0) {
      const { data: txns } = await supabase
        .from("payment_transactions")
        .select(
          "id, amount, payment_method, payment_reference, status, receipt_number, created_at, fee_account_id"
        )
        .in("fee_account_id", feeAccountIds)
        .order("created_at", { ascending: false });

      payments = txns || [];
    }

    // Summary
    const totalDue = (feeAccounts || []).reduce((sum, fa) => sum + fa.total_amount, 0);
    const totalPaid = (feeAccounts || []).reduce((sum, fa) => sum + fa.amount_paid, 0);
    const totalBalance = (feeAccounts || []).reduce((sum, fa) => sum + fa.balance, 0);
    const overdueAccounts = (feeAccounts || []).filter(
      (fa) => fa.status === "overdue"
    ).length;

    return apiSuccess({
      accounts: feeAccounts || [],
      payments,
      summary: {
        total_due: totalDue,
        total_paid: totalPaid,
        total_balance: totalBalance,
        overdue_count: overdueAccounts,
      },
    });
  } catch (err) {
    console.error("Error fetching fees:", err);
    return apiError("Failed to fetch fees", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
