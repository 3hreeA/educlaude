import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || !["admin", "finance"].includes(user.role)) {
      return apiError("Admin or finance access required", ErrorCodes.FORBIDDEN, 403);
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");
    const classId = searchParams.get("class_id");
    const termId = searchParams.get("term_id");
    const dateFrom = searchParams.get("date_from");
    const dateTo = searchParams.get("date_to");

    switch (type) {
      case "attendance":
        return await attendanceReport(supabase, user.school_id, { classId, dateFrom, dateTo });
      case "grades":
        return await gradesReport(supabase, user.school_id, { classId, termId });
      case "enrollment":
        return await enrollmentReport(supabase, user.school_id);
      case "fee_collection":
        return await feeCollectionReport(supabase, user.school_id, { dateFrom, dateTo, classId });
      case "outstanding_fees":
        return await outstandingFeesReport(supabase, user.school_id, { classId });
      default:
        return apiError("Invalid report type. Use: attendance, grades, enrollment, fee_collection, outstanding_fees", ErrorCodes.BAD_REQUEST, 400);
    }
  } catch (err) {
    console.error("Report error:", err);
    return apiError("Failed to generate report", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── Attendance Report ────────────────────────────────────────────────
async function attendanceReport(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  schoolId: string,
  filters: { classId?: string | null; dateFrom?: string | null; dateTo?: string | null }
) {
  // Get classes
  let classQuery = supabase
    .from("classes")
    .select("id, name, level, arm")
    .eq("school_id", schoolId)
    .eq("is_active", true)
    .order("level");

  if (filters.classId) classQuery = classQuery.eq("id", filters.classId);
  const { data: classes } = await classQuery;

  const classIds = (classes || []).map((c) => c.id);
  if (classIds.length === 0) return apiSuccess({ report_type: "attendance", data: [], summary: {} });

  // Get attendance records
  let attQuery = supabase
    .from("attendance_records")
    .select("student_id, class_id, status, date")
    .in("class_id", classIds);

  if (filters.dateFrom) attQuery = attQuery.gte("date", filters.dateFrom);
  if (filters.dateTo) attQuery = attQuery.lte("date", filters.dateTo);

  const { data: records } = await attQuery;

  // Get student info
  const studentIds = [...new Set((records || []).map((r) => r.student_id))];
  const { data: students } = studentIds.length > 0
    ? await supabase
        .from("students")
        .select("id, first_name, last_name, admission_number, class_id")
        .in("id", studentIds)
    : { data: [] };

  const studentMap = new Map((students || []).map((s) => [s.id, s]));
  const classMap = new Map((classes || []).map((c) => [c.id, c]));

  // Aggregate per-student
  const studentStats: Record<string, { present: number; absent: number; late: number; excused: number; total: number }> = {};
  for (const r of records || []) {
    if (!studentStats[r.student_id]) {
      studentStats[r.student_id] = { present: 0, absent: 0, late: 0, excused: 0, total: 0 };
    }
    const s = studentStats[r.student_id];
    s.total++;
    if (r.status === "present") s.present++;
    else if (r.status === "absent") s.absent++;
    else if (r.status === "late") s.late++;
    else if (r.status === "excused") s.excused++;
  }

  const data = Object.entries(studentStats).map(([studentId, stats]) => {
    const student = studentMap.get(studentId);
    const cls = student ? classMap.get(student.class_id) : null;
    return {
      student_id: studentId,
      student_name: student ? `${student.last_name}, ${student.first_name}` : "Unknown",
      admission_number: student?.admission_number || "",
      class_name: cls?.name || "",
      total_days: stats.total,
      present: stats.present,
      absent: stats.absent,
      late: stats.late,
      excused: stats.excused,
      attendance_rate: stats.total > 0 ? Math.round((stats.present / stats.total) * 1000) / 10 : 0,
    };
  }).sort((a, b) => a.student_name.localeCompare(b.student_name));

  const totalRecords = records?.length || 0;
  const presentCount = (records || []).filter((r) => r.status === "present").length;

  return apiSuccess({
    report_type: "attendance",
    generated_at: new Date().toISOString(),
    filters: { class_id: filters.classId, date_from: filters.dateFrom, date_to: filters.dateTo },
    summary: {
      total_students: data.length,
      total_records: totalRecords,
      overall_attendance_rate: totalRecords > 0 ? Math.round((presentCount / totalRecords) * 1000) / 10 : 0,
      classes_covered: classes?.length || 0,
    },
    data,
  });
}

// ─── Grades Report ────────────────────────────────────────────────────
async function gradesReport(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  schoolId: string,
  filters: { classId?: string | null; termId?: string | null }
) {
  // Get classes
  let classQuery = supabase
    .from("classes")
    .select("id, name, level, arm")
    .eq("school_id", schoolId)
    .eq("is_active", true);
  if (filters.classId) classQuery = classQuery.eq("id", filters.classId);
  const { data: classes } = await classQuery;
  const classIds = (classes || []).map((c) => c.id);

  // Get assessments for these classes
  let assessmentQuery = supabase
    .from("assessments")
    .select("id, name, subject_id, class_id, max_score, weight")
    .in("class_id", classIds);
  if (filters.termId) assessmentQuery = assessmentQuery.eq("term_id", filters.termId);
  const { data: assessments } = await assessmentQuery;

  const assessmentIds = (assessments || []).map((a) => a.id);
  if (assessmentIds.length === 0) {
    return apiSuccess({ report_type: "grades", data: [], summary: {} });
  }

  // Get grades
  const { data: grades } = await supabase
    .from("grades")
    .select("student_id, assessment_id, score, percentage")
    .in("assessment_id", assessmentIds);

  // Get subjects
  const subjectIds = [...new Set((assessments || []).map((a) => a.subject_id))];
  const { data: subjects } = subjectIds.length > 0
    ? await supabase.from("subjects").select("id, name, code").in("id", subjectIds)
    : { data: [] };
  const subjectMap = new Map((subjects || []).map((s) => [s.id, s]));

  // Get students
  const studentIds = [...new Set((grades || []).map((g) => g.student_id))];
  const { data: students } = studentIds.length > 0
    ? await supabase
        .from("students")
        .select("id, first_name, last_name, admission_number, class_id")
        .in("id", studentIds)
    : { data: [] };
  const studentMap = new Map((students || []).map((s) => [s.id, s]));
  const classMap = new Map((classes || []).map((c) => [c.id, c]));

  // Aggregate per student per subject
  const studentSubjectScores: Record<string, Record<string, { total: number; count: number; scores: number[] }>> = {};
  for (const g of grades || []) {
    const assessment = (assessments || []).find((a) => a.id === g.assessment_id);
    if (!assessment) continue;
    const subject = subjectMap.get(assessment.subject_id);
    if (!subject) continue;

    if (!studentSubjectScores[g.student_id]) studentSubjectScores[g.student_id] = {};
    if (!studentSubjectScores[g.student_id][subject.name]) {
      studentSubjectScores[g.student_id][subject.name] = { total: 0, count: 0, scores: [] };
    }
    const s = studentSubjectScores[g.student_id][subject.name];
    s.total += g.percentage || 0;
    s.count++;
    s.scores.push(g.percentage || 0);
  }

  const data = Object.entries(studentSubjectScores).map(([studentId, subjects]) => {
    const student = studentMap.get(studentId);
    const cls = student ? classMap.get(student.class_id) : null;
    const subjectGrades = Object.entries(subjects).map(([subjectName, stats]) => ({
      subject: subjectName,
      average: stats.count > 0 ? Math.round(stats.total / stats.count * 10) / 10 : 0,
      assessments: stats.count,
    }));
    const overall = subjectGrades.reduce((a, b) => a + b.average, 0) / (subjectGrades.length || 1);

    return {
      student_id: studentId,
      student_name: student ? `${student.last_name}, ${student.first_name}` : "Unknown",
      admission_number: student?.admission_number || "",
      class_name: cls?.name || "",
      subjects: subjectGrades,
      overall_average: Math.round(overall * 10) / 10,
    };
  }).sort((a, b) => b.overall_average - a.overall_average);

  return apiSuccess({
    report_type: "grades",
    generated_at: new Date().toISOString(),
    filters: { class_id: filters.classId, term_id: filters.termId },
    summary: {
      total_students: data.length,
      total_assessments: assessments?.length || 0,
      subjects_covered: subjects?.length || 0,
      class_average: data.length > 0
        ? Math.round(data.reduce((a, b) => a + b.overall_average, 0) / data.length * 10) / 10
        : 0,
    },
    data,
  });
}

// ─── Enrollment Report ────────────────────────────────────────────────
async function enrollmentReport(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  schoolId: string
) {
  const { data: classes } = await supabase
    .from("classes")
    .select("id, name, level, arm, capacity")
    .eq("school_id", schoolId)
    .eq("is_active", true)
    .order("level");

  const { data: students } = await supabase
    .from("students")
    .select("id, class_id, gender, is_active, admission_date")
    .eq("school_id", schoolId);

  const classMap = new Map((classes || []).map((c) => [c.id, c]));

  // Per-class breakdown
  const classStats: Record<string, { total: number; active: number; male: number; female: number }> = {};
  for (const s of students || []) {
    const cid = s.class_id || "unassigned";
    if (!classStats[cid]) classStats[cid] = { total: 0, active: 0, male: 0, female: 0 };
    classStats[cid].total++;
    if (s.is_active) classStats[cid].active++;
    if (s.gender === "male") classStats[cid].male++;
    else if (s.gender === "female") classStats[cid].female++;
  }

  const data = (classes || []).map((cls) => {
    const stats = classStats[cls.id] || { total: 0, active: 0, male: 0, female: 0 };
    return {
      class_id: cls.id,
      class_name: cls.name,
      level: cls.level,
      arm: cls.arm,
      capacity: cls.capacity,
      enrolled: stats.active,
      total_ever: stats.total,
      male: stats.male,
      female: stats.female,
      utilization: cls.capacity > 0 ? Math.round((stats.active / cls.capacity) * 1000) / 10 : 0,
    };
  });

  const activeStudents = (students || []).filter((s) => s.is_active);
  return apiSuccess({
    report_type: "enrollment",
    generated_at: new Date().toISOString(),
    summary: {
      total_classes: classes?.length || 0,
      total_enrolled: activeStudents.length,
      total_capacity: (classes || []).reduce((a, c) => a + (c.capacity || 0), 0),
      male: activeStudents.filter((s) => s.gender === "male").length,
      female: activeStudents.filter((s) => s.gender === "female").length,
      overall_utilization:
        (classes || []).reduce((a, c) => a + (c.capacity || 0), 0) > 0
          ? Math.round(
              (activeStudents.length /
                (classes || []).reduce((a, c) => a + (c.capacity || 0), 0)) *
                1000
            ) / 10
          : 0,
    },
    data,
  });
}

// ─── Fee Collection Report ────────────────────────────────────────────
async function feeCollectionReport(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  schoolId: string,
  filters: { dateFrom?: string | null; dateTo?: string | null; classId?: string | null }
) {
  let txQuery = supabase
    .from("payment_transactions")
    .select(`
      id, amount, payment_method, status, created_at, receipt_number,
      student_fee_accounts:fee_account_id (
        student_id,
        students!inner ( first_name, last_name, admission_number, class_id, school_id )
      )
    `)
    .eq("status", "success");

  if (filters.dateFrom) txQuery = txQuery.gte("created_at", filters.dateFrom);
  if (filters.dateTo) txQuery = txQuery.lte("created_at", filters.dateTo);

  const { data: transactions, error } = await txQuery;

  if (error) {
    console.error("Fee collection query error:", error);
    return apiError("Failed to generate fee collection report", ErrorCodes.INTERNAL_ERROR, 500);
  }

  // Filter by school and optionally class
  const filtered = (transactions || []).filter((t) => {
    const account = t.student_fee_accounts as Record<string, unknown>;
    const student = account?.students as Record<string, unknown>;
    if (student?.school_id !== schoolId) return false;
    if (filters.classId && student?.class_id !== filters.classId) return false;
    return true;
  });

  // Method breakdown
  const methodBreakdown: Record<string, { count: number; total: number }> = {};
  let totalCollected = 0;

  const data = filtered.map((t) => {
    const account = t.student_fee_accounts as Record<string, unknown>;
    const student = account?.students as Record<string, string>;

    if (!methodBreakdown[t.payment_method]) {
      methodBreakdown[t.payment_method] = { count: 0, total: 0 };
    }
    methodBreakdown[t.payment_method].count++;
    methodBreakdown[t.payment_method].total += t.amount;
    totalCollected += t.amount;

    return {
      transaction_id: t.id,
      student_name: student ? `${student.last_name}, ${student.first_name}` : "Unknown",
      admission_number: student?.admission_number || "",
      amount: t.amount,
      payment_method: t.payment_method,
      payment_date: t.created_at,
      receipt_number: t.receipt_number,
    };
  });

  return apiSuccess({
    report_type: "fee_collection",
    generated_at: new Date().toISOString(),
    filters: { date_from: filters.dateFrom, date_to: filters.dateTo, class_id: filters.classId },
    summary: {
      total_transactions: data.length,
      total_collected: totalCollected,
      method_breakdown: methodBreakdown,
    },
    data,
  });
}

// ─── Outstanding Fees Report ──────────────────────────────────────────
async function outstandingFeesReport(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  schoolId: string,
  filters: { classId?: string | null }
) {
  let query = supabase
    .from("student_fee_accounts")
    .select(`
      id, total_amount, amount_paid, balance, status, due_date,
      students!inner ( id, first_name, last_name, admission_number, class_id, school_id,
        classes ( name )
      )
    `)
    .in("status", ["current", "partial", "overdue"]);

  const { data: accounts, error } = await query;
  if (error) {
    console.error("Outstanding fees query error:", error);
    return apiError("Failed to generate report", ErrorCodes.INTERNAL_ERROR, 500);
  }

  // Filter by school
  const filtered = (accounts || []).filter((a) => {
    const student = a.students as Record<string, unknown>;
    if (student?.school_id !== schoolId) return false;
    if (filters.classId && student?.class_id !== filters.classId) return false;
    return true;
  });

  let totalOutstanding = 0;
  const data = filtered.map((a) => {
    const student = a.students as Record<string, unknown>;
    const cls = student?.classes as Record<string, string> | null;
    const bal = Number(a.balance) || (a.total_amount - a.amount_paid);
    totalOutstanding += bal;

    // Calculate aging
    const dueDate = a.due_date ? new Date(a.due_date) : null;
    const now = new Date();
    let agingDays = 0;
    if (dueDate && dueDate < now) {
      agingDays = Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
    }

    return {
      student_name: student ? `${student.last_name}, ${student.first_name}` : "Unknown",
      admission_number: (student?.admission_number as string) || "",
      class_name: cls?.name || "",
      total_amount: a.total_amount,
      amount_paid: a.amount_paid,
      balance: bal,
      status: a.status,
      due_date: a.due_date,
      aging_days: agingDays,
      aging_bucket:
        agingDays <= 0 ? "Current" :
        agingDays <= 30 ? "1-30 Days" :
        agingDays <= 60 ? "31-60 Days" :
        agingDays <= 90 ? "61-90 Days" : "90+ Days",
    };
  }).sort((a, b) => b.balance - a.balance);

  // Bucket summary
  const buckets: Record<string, { count: number; total: number }> = {
    Current: { count: 0, total: 0 },
    "1-30 Days": { count: 0, total: 0 },
    "31-60 Days": { count: 0, total: 0 },
    "61-90 Days": { count: 0, total: 0 },
    "90+ Days": { count: 0, total: 0 },
  };
  for (const d of data) {
    if (buckets[d.aging_bucket]) {
      buckets[d.aging_bucket].count++;
      buckets[d.aging_bucket].total += d.balance;
    }
  }

  return apiSuccess({
    report_type: "outstanding_fees",
    generated_at: new Date().toISOString(),
    filters: { class_id: filters.classId },
    summary: {
      total_accounts: data.length,
      total_outstanding: totalOutstanding,
      aging_buckets: buckets,
    },
    data,
  });
}
