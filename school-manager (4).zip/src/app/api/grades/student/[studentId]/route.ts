import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

export async function GET(
  request: NextRequest,
  { params }: { params: { studentId: string } }
) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { studentId } = params;
    const { searchParams } = new URL(request.url);
    const termId = searchParams.get("term_id");

    // Get the student's class to determine relevant assessments
    const { data: student } = await supabase
      .from("students")
      .select("class_id")
      .eq("id", studentId)
      .single();

    if (!student) {
      return apiError("Student not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get assessments for the student's class
    let assessmentQuery = supabase
      .from("assessments")
      .select(`
        id, name, max_score, weight, date,
        subjects:subject_id ( id, name, code )
      `)
      .eq("class_id", student.class_id)
      .order("date", { ascending: false });

    if (termId) {
      assessmentQuery = assessmentQuery.eq("term_id", termId);
    }

    const { data: assessments } = await assessmentQuery;

    if (!assessments || assessments.length === 0) {
      return apiSuccess({ subjects: [], overall_average: null });
    }

    // Get grades for this student
    const assessmentIds = assessments.map((a) => a.id);
    const { data: grades } = await supabase
      .from("grades")
      .select("id, assessment_id, score, remarks")
      .eq("student_id", studentId)
      .in("assessment_id", assessmentIds);

    // Get all grades in these assessments (for class average calculation)
    const { data: allGrades } = await supabase
      .from("grades")
      .select("assessment_id, score")
      .in("assessment_id", assessmentIds);

    // Build class averages per assessment
    const classAvgMap: Record<string, number> = {};
    if (allGrades) {
      const grouped: Record<string, number[]> = {};
      for (const g of allGrades) {
        if (!grouped[g.assessment_id]) grouped[g.assessment_id] = [];
        grouped[g.assessment_id].push(g.score);
      }
      for (const [aId, scores] of Object.entries(grouped)) {
        classAvgMap[aId] = scores.reduce((a, b) => a + b, 0) / scores.length;
      }
    }

    // Group by subject
    const subjectMap: Record<
      string,
      {
        id: string;
        name: string;
        code: string;
        assessments: Array<{
          id: string;
          name: string;
          max_score: number;
          weight: number;
          date: string;
          student_score: number | null;
          class_average: number | null;
          percentage: number | null;
        }>;
        average: number | null;
        class_average: number | null;
      }
    > = {};

    for (const assessment of assessments) {
      const subject = assessment.subjects as any;
      if (!subject) continue;

      const subjectId = subject.id;
      if (!subjectMap[subjectId]) {
        subjectMap[subjectId] = {
          id: subjectId,
          name: subject.name,
          code: subject.code,
          assessments: [],
          average: null,
          class_average: null,
        };
      }

      const studentGrade = grades?.find((g) => g.assessment_id === assessment.id);
      const score = studentGrade?.score ?? null;
      const percentage = score !== null ? (score / assessment.max_score) * 100 : null;
      const classAvg = classAvgMap[assessment.id]
        ? (classAvgMap[assessment.id] / assessment.max_score) * 100
        : null;

      subjectMap[subjectId].assessments.push({
        id: assessment.id,
        name: assessment.name,
        max_score: assessment.max_score,
        weight: assessment.weight,
        date: assessment.date,
        student_score: score,
        class_average: classAvg ? Math.round(classAvg * 10) / 10 : null,
        percentage: percentage ? Math.round(percentage * 10) / 10 : null,
      });
    }

    // Calculate subject averages
    const subjects = Object.values(subjectMap).map((subject) => {
      const scored = subject.assessments.filter((a) => a.percentage !== null);
      if (scored.length > 0) {
        // Weighted average if weights provided
        const totalWeight = scored.reduce((sum, a) => sum + a.weight, 0);
        if (totalWeight > 0) {
          subject.average =
            Math.round(
              (scored.reduce((sum, a) => sum + (a.percentage || 0) * a.weight, 0) /
                totalWeight) *
                10
            ) / 10;
        } else {
          subject.average =
            Math.round(
              (scored.reduce((sum, a) => sum + (a.percentage || 0), 0) / scored.length) *
                10
            ) / 10;
        }
      }

      const classScored = subject.assessments.filter((a) => a.class_average !== null);
      if (classScored.length > 0) {
        subject.class_average =
          Math.round(
            (classScored.reduce((sum, a) => sum + (a.class_average || 0), 0) /
              classScored.length) *
              10
          ) / 10;
      }

      return subject;
    });

    // Sort subjects by name
    subjects.sort((a, b) => a.name.localeCompare(b.name));

    // Overall average
    const subjectsWithAvg = subjects.filter((s) => s.average !== null);
    const overallAvg =
      subjectsWithAvg.length > 0
        ? Math.round(
            (subjectsWithAvg.reduce((sum, s) => sum + (s.average || 0), 0) /
              subjectsWithAvg.length) *
              10
          ) / 10
        : null;

    return apiSuccess({
      subjects,
      overall_average: overallAvg,
    });
  } catch (err) {
    console.error("Error fetching grades:", err);
    return apiError("Failed to fetch grades", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
