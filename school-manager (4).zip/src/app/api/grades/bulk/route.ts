import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

interface GradeEntry {
  student_id: string;
  score: number;
  remarks?: string;
}

interface BulkGradeBody {
  assessment_id: string;
  grades: GradeEntry[];
}

// POST: Submit grades for an assessment (bulk upsert)
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const body: BulkGradeBody = await request.json();
    const { assessment_id, grades } = body;

    if (!assessment_id || !grades || !Array.isArray(grades) || grades.length === 0) {
      return apiError("assessment_id and grades array are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Fetch assessment to validate scores
    const { data: assessment, error: assessErr } = await supabase
      .from("assessments")
      .select("id, max_score, class_id")
      .eq("id", assessment_id)
      .single();

    if (assessErr || !assessment) {
      return apiError("Assessment not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Validate all scores
    for (const g of grades) {
      if (!g.student_id) {
        return apiError("Each grade entry requires a student_id", ErrorCodes.VALIDATION_ERROR, 422);
      }
      if (g.score < 0 || g.score > assessment.max_score) {
        return apiError(
          `Score must be between 0 and ${assessment.max_score}`,
          ErrorCodes.VALIDATION_ERROR,
          422
        );
      }
    }

    // Delete existing grades for this assessment, then insert fresh
    // (cleaner than trying to upsert on composite unique)
    const studentIds = grades.map((g) => g.student_id);

    const { error: deleteErr } = await supabase
      .from("grades")
      .delete()
      .eq("assessment_id", assessment_id)
      .in("student_id", studentIds);

    if (deleteErr) {
      console.error("Delete grades error:", deleteErr);
      return apiError("Failed to update grades", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const records = grades.map((g) => ({
      student_id: g.student_id,
      assessment_id,
      score: g.score,
      remarks: g.remarks || null,
      entered_by: session.user.id,
    }));

    const { data: inserted, error: insertErr } = await supabase
      .from("grades")
      .insert(records)
      .select("id, student_id, score");

    if (insertErr) {
      console.error("Insert grades error:", insertErr);
      return apiError("Failed to save grades", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(
      {
        saved: inserted?.length || 0,
        assessment_id,
      },
      201
    );
  } catch (err) {
    console.error("Error saving grades:", err);
    return apiError("Failed to save grades", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// GET: Retrieve grades for an assessment (with student info)
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { searchParams } = new URL(request.url);
    const assessmentId = searchParams.get("assessment_id");

    if (!assessmentId) {
      return apiError("assessment_id is required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    // Get assessment details
    const { data: assessment, error: assessErr } = await supabase
      .from("assessments")
      .select(`
        id, name, max_score, weight, date,
        subjects:subject_id (id, name),
        classes:class_id (id, name)
      `)
      .eq("id", assessmentId)
      .single();

    if (assessErr || !assessment) {
      return apiError("Assessment not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get all students in the class
    const cls = assessment.classes as any;
    const { data: students } = await supabase
      .from("students")
      .select("id, admission_number, first_name, last_name, photo_url")
      .eq("class_id", cls.id)
      .eq("is_active", true)
      .order("last_name")
      .order("first_name");

    // Get existing grades for this assessment
    const { data: grades } = await supabase
      .from("grades")
      .select("id, student_id, score, remarks")
      .eq("assessment_id", assessmentId);

    // Create grade map for quick lookup
    const gradeMap = new Map<string, { score: number; remarks: string | null }>();
    for (const g of grades || []) {
      gradeMap.set(g.student_id, { score: g.score, remarks: g.remarks });
    }

    // Merge students with their grades
    const studentGrades = (students || []).map((s) => {
      const grade = gradeMap.get(s.id);
      return {
        student_id: s.id,
        admission_number: s.admission_number,
        first_name: s.first_name,
        last_name: s.last_name,
        photo_url: s.photo_url,
        score: grade?.score ?? null,
        remarks: grade?.remarks ?? null,
      };
    });

    return apiSuccess({
      assessment: {
        id: assessment.id,
        name: assessment.name,
        max_score: assessment.max_score,
        weight: assessment.weight,
        date: assessment.date,
        subject: assessment.subjects,
        class: assessment.classes,
      },
      students: studentGrades,
    });
  } catch (err) {
    console.error("Error fetching grades:", err);
    return apiError("Failed to fetch grades", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
