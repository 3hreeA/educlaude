import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

type RouteContext = { params: Promise<{ id: string }> };

// ─── GET: Single announcement detail ──────────────────────────────────
export async function GET(_req: NextRequest, ctx: RouteContext) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("role, school_id")
      .eq("auth_id", session.user.id)
      .single();
    if (!user) return apiError("User not found", ErrorCodes.NOT_FOUND, 404);

    const { data: announcement, error } = await supabase
      .from("announcements")
      .select(`*, users:published_by ( first_name, last_name )`)
      .eq("id", id)
      .eq("school_id", user.school_id)
      .single();

    if (error || !announcement) {
      return apiError("Announcement not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get delivery stats if admin
    let deliveryStats = null;
    if (user.role === "admin" && announcement.status === "published") {
      const { data: deliveries } = await supabase
        .from("announcement_deliveries")
        .select("channel, status")
        .eq("announcement_id", id);

      if (deliveries) {
        deliveryStats = {
          total: deliveries.length,
          by_channel: deliveries.reduce(
            (acc: Record<string, { sent: number; failed: number }>, d) => {
              if (!acc[d.channel]) acc[d.channel] = { sent: 0, failed: 0 };
              if (d.status === "sent" || d.status === "delivered") acc[d.channel].sent++;
              else if (d.status === "failed") acc[d.channel].failed++;
              return acc;
            },
            {}
          ),
        };
      }
    }

    const publisher = announcement.users as { first_name: string; last_name: string } | null;
    return apiSuccess({
      ...announcement,
      users: undefined,
      published_by_name: publisher
        ? `${publisher.first_name} ${publisher.last_name}`
        : "School Admin",
      delivery_stats: deliveryStats,
    });
  } catch (err) {
    console.error("Error fetching announcement:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── PUT: Update announcement ─────────────────────────────────────────
export async function PUT(request: NextRequest, ctx: RouteContext) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("id, role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return apiError("Only admins can update announcements", ErrorCodes.FORBIDDEN, 403);
    }

    const body = await request.json();
    const { action, ...fields } = body as {
      action?: "publish" | "archive";
      title?: string;
      content?: string;
      priority?: string;
      target_roles?: string[];
      target_classes?: string[];
      delivery_channels?: string[];
      scheduled_at?: string | null;
      expires_at?: string | null;
    };

    // Handle publish action
    if (action === "publish") {
      const { data: existing } = await supabase
        .from("announcements")
        .select("id, status, title, content, target_roles, delivery_channels, priority")
        .eq("id", id)
        .eq("school_id", user.school_id)
        .single();

      if (!existing) return apiError("Announcement not found", ErrorCodes.NOT_FOUND, 404);
      if (existing.status === "published") {
        return apiError("Already published", ErrorCodes.CONFLICT, 409);
      }

      const { data: updated, error } = await supabase
        .from("announcements")
        .update({
          status: "published",
          published_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select("*")
        .single();

      if (error) return apiError("Failed to publish", ErrorCodes.INTERNAL_ERROR, 500);

      // Trigger delivery
      triggerDelivery(id, user.school_id).catch(console.error);

      return apiSuccess(updated);
    }

    // Handle archive action
    if (action === "archive") {
      const { data: updated, error } = await supabase
        .from("announcements")
        .update({
          status: "archived",
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .eq("school_id", user.school_id)
        .select("*")
        .single();

      if (error) return apiError("Failed to archive", ErrorCodes.INTERNAL_ERROR, 500);
      return apiSuccess(updated);
    }

    // Regular field update (only for drafts)
    const updateData: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (fields.title !== undefined) updateData.title = fields.title;
    if (fields.content !== undefined) updateData.content = fields.content;
    if (fields.priority !== undefined) updateData.priority = fields.priority;
    if (fields.target_roles !== undefined) updateData.target_roles = fields.target_roles;
    if (fields.target_classes !== undefined) updateData.target_classes = fields.target_classes;
    if (fields.delivery_channels !== undefined) updateData.delivery_channels = fields.delivery_channels;
    if (fields.scheduled_at !== undefined) updateData.scheduled_at = fields.scheduled_at;
    if (fields.expires_at !== undefined) updateData.expires_at = fields.expires_at;

    const { data: updated, error } = await supabase
      .from("announcements")
      .update(updateData)
      .eq("id", id)
      .eq("school_id", user.school_id)
      .select("*")
      .single();

    if (error || !updated) {
      return apiError("Failed to update announcement", ErrorCodes.INTERNAL_ERROR, 500);
    }

    return apiSuccess(updated);
  } catch (err) {
    console.error("Error updating announcement:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── DELETE ───────────────────────────────────────────────────────────
export async function DELETE(_req: NextRequest, ctx: RouteContext) {
  try {
    const { id } = await ctx.params;
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return apiError("Only admins can delete announcements", ErrorCodes.FORBIDDEN, 403);
    }

    const { error } = await supabase
      .from("announcements")
      .delete()
      .eq("id", id)
      .eq("school_id", user.school_id);

    if (error) return apiError("Failed to delete", ErrorCodes.INTERNAL_ERROR, 500);
    return apiSuccess({ deleted: true });
  } catch (err) {
    console.error("Error deleting announcement:", err);
    return apiError("Internal error", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

// ─── Helper ───────────────────────────────────────────────────────────

async function triggerDelivery(announcementId: string, schoolId: string) {
  try {
    const { deliverAnnouncement } = await import("@/lib/integrations/notification-service");
    const supabase = createServerSupabaseClient();

    const { data: ann } = await supabase
      .from("announcements")
      .select("*, schools:school_id(name)")
      .eq("id", announcementId)
      .single();

    if (!ann) return;
    const schoolData = ann.schools as Record<string, string> | null;

    await deliverAnnouncement({
      announcementId: ann.id,
      title: ann.title,
      content: ann.content,
      priority: ann.priority,
      schoolName: schoolData?.name || "School",
      channels: ann.delivery_channels || ["in_app"],
      targetRoles: ann.target_roles || ["parent", "teacher"],
      targetClasses: ann.target_classes,
      schoolId,
    });
  } catch (err) {
    console.error("Delivery error:", err);
  }
}
