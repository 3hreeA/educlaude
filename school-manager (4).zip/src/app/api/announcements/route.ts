import { NextRequest } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { apiSuccess, apiError, ErrorCodes } from "@/lib/utils/errors";

// ─── POST: Create a new announcement ──────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);

    const { data: user } = await supabase
      .from("users")
      .select("id, role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user || user.role !== "admin") {
      return apiError("Only admins can create announcements", ErrorCodes.FORBIDDEN, 403);
    }

    const body = await request.json();
    const {
      title, content, priority = "normal",
      target_roles = ["parent", "teacher"],
      target_classes, delivery_channels = ["in_app"],
      scheduled_at, expires_at, status = "draft",
    } = body as {
      title: string; content: string; priority?: string;
      target_roles?: string[]; target_classes?: string[];
      delivery_channels?: string[]; scheduled_at?: string;
      expires_at?: string; status?: string;
    };

    if (!title?.trim() || !content?.trim()) {
      return apiError("Title and content are required", ErrorCodes.VALIDATION_ERROR, 422);
    }

    const insertData: Record<string, unknown> = {
      school_id: user.school_id,
      title: title.trim(),
      content: content.trim(),
      priority,
      status,
      target_roles,
      target_classes: target_classes || null,
      delivery_channels,
      scheduled_at: scheduled_at || null,
      expires_at: expires_at || null,
      published_by: user.id,
    };

    // If publishing immediately, set published_at
    if (status === "published") {
      insertData.published_at = new Date().toISOString();
    }

    const { data: announcement, error } = await supabase
      .from("announcements")
      .insert(insertData)
      .select("*")
      .single();

    if (error) {
      console.error("Create announcement error:", error);
      return apiError("Failed to create announcement", ErrorCodes.INTERNAL_ERROR, 500);
    }

    // If publishing immediately, trigger delivery
    if (status === "published") {
      // Fire-and-forget delivery (don't block the response)
      triggerDelivery(announcement.id, user.school_id).catch(console.error);
    }

    return apiSuccess(announcement, 201);
  } catch (err) {
    console.error("Error creating announcement:", err);
    return apiError("Failed to create announcement", ErrorCodes.INTERNAL_ERROR, 500);
  }
}

async function triggerDelivery(announcementId: string, schoolId: string) {
  try {
    const { deliverAnnouncement } = await import("@/lib/integrations/notification-service");
    const supabase = createServerSupabaseClient();

    const { data: ann } = await supabase
      .from("announcements")
      .select("*, schools:school_id(name)")
      .eq("id", announcementId)
      .single();

    if (!ann) return;

    const schoolData = ann.schools as Record<string, string> | null;
    await deliverAnnouncement({
      announcementId: ann.id,
      title: ann.title,
      content: ann.content,
      priority: ann.priority,
      schoolName: schoolData?.name || "School",
      channels: ann.delivery_channels || ["in_app"],
      targetRoles: ann.target_roles || ["parent", "teacher"],
      targetClasses: ann.target_classes,
      schoolId,
    });
  } catch (err) {
    console.error("Delivery error:", err);
  }
}

// ─── GET: List announcements ──────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
      return apiError("Not authenticated", ErrorCodes.UNAUTHORIZED, 401);
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = Math.min(parseInt(searchParams.get("limit") || "20"), 50);
    const offset = (page - 1) * limit;

    // Get user role and school
    const { data: user } = await supabase
      .from("users")
      .select("role, school_id")
      .eq("auth_id", session.user.id)
      .single();

    if (!user) {
      return apiError("User not found", ErrorCodes.NOT_FOUND, 404);
    }

    // Get announcements that target this user's role, are published, and not expired
    const now = new Date().toISOString();
    const statusFilter = searchParams.get("status"); // admin can filter by status
    const isAdmin = user.role === "admin";

    let query = supabase
      .from("announcements")
      .select(
        `id, title, content, priority, target_roles, target_classes,
         delivery_channels, status, scheduled_at,
         published_at, expires_at, created_at, updated_at,
         users:published_by ( first_name, last_name )`,
        { count: "exact" }
      )
      .eq("school_id", user.school_id)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (isAdmin) {
      // Admin sees all announcements; optionally filtered by status
      if (statusFilter && statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }
    } else {
      // Non-admin: only published, not expired, targeting their role
      query = query
        .eq("status", "published")
        .contains("target_roles", [user.role])
        .or(`expires_at.is.null,expires_at.gt.${now}`);
    }

    const { data: announcements, error, count } = await query;

    if (error) {
      console.error("Announcements query error:", error);
      return apiError("Failed to fetch announcements", ErrorCodes.INTERNAL_ERROR, 500);
    }

    const formatted = (announcements || []).map((a: Record<string, unknown>) => {
      const publisher = a.users as { first_name: string; last_name: string } | null;
      return {
        id: a.id,
        title: a.title,
        content: a.content,
        priority: a.priority,
        status: a.status,
        target_roles: a.target_roles,
        delivery_channels: a.delivery_channels,
        scheduled_at: a.scheduled_at,
        published_at: a.published_at,
        expires_at: a.expires_at,
        created_at: a.created_at,
        published_by: publisher
          ? `${publisher.first_name} ${publisher.last_name}`
          : "School Admin",
      };
    });

    return apiSuccess({
      announcements: formatted,
      pagination: {
        page,
        limit,
        total: count || 0,
        total_pages: Math.ceil((count || 0) / limit),
      },
    });
  } catch (err) {
    console.error("Error fetching announcements:", err);
    return apiError("Failed to fetch announcements", ErrorCodes.INTERNAL_ERROR, 500);
  }
}
