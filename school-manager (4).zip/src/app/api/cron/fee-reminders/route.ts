import { NextRequest, NextResponse } from "next/server";
import { createServerSupabaseClient } from "@/lib/supabase/server";

// This endpoint is called by Vercel Cron (or similar) daily at 9am WAT
// to send automated fee reminders to parents with overdue balances.
// Configure schedule in vercel.json or your cron provider.

export async function GET(request: NextRequest) {
  // Verify cron secret to prevent unauthorized triggers
  const authHeader = request.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const supabase = createServerSupabaseClient();
    const now = new Date().toISOString().split("T")[0];

    // Find overdue accounts (due_date passed, balance > 0)
    const { data: accounts } = await supabase
      .from("student_fee_accounts")
      .select(`id, balance, due_date,
               students:student_id ( first_name, last_name,
                 parents:student_parents ( parents:parent_id ( user_id ) ) )`)
      .gt("balance", 0)
      .lte("due_date", now);

    if (!accounts || accounts.length === 0) {
      return NextResponse.json({ sent: 0, message: "No overdue accounts" });
    }

    // Create in-app notifications for each parent
    const notifications = [];
    for (const acct of accounts) {
      const student = acct.students as Record<string, unknown> | null;
      const name = student ? `${student.first_name} ${student.last_name}` : "your child";
      const balance = Number(acct.balance).toLocaleString("en-NG");
      const parents = (student as Record<string, unknown>)?.parents as Array<Record<string, unknown>> | null;

      if (!parents) continue;
      for (const sp of parents) {
        const parent = sp.parents as Record<string, unknown> | null;
        if (!parent?.user_id) continue;
        notifications.push({
          recipient_id: parent.user_id,
          type: "fee_reminder",
          title: "Fee Payment Reminder",
          message: `Outstanding balance of ₦${balance} for ${name} is overdue. Please make payment.`,
          channel: "push",
        });
      }
    }

    if (notifications.length > 0) {
      await supabase.from("notifications").insert(notifications);
    }

    // Log reminders
    const logs = accounts.map((acct) => ({
      fee_account_id: acct.id,
      channel: "push",
      message: `Auto-reminder: ₦${Number(acct.balance).toLocaleString("en-NG")} overdue`,
      status: "sent",
    }));
    if (logs.length > 0) {
      await supabase.from("fee_reminder_logs").insert(logs);
    }

    return NextResponse.json({
      sent: notifications.length,
      accounts: accounts.length,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error("Cron fee reminders error:", err);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
