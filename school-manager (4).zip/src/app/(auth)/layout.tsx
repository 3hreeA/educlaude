export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(255,255,255,0.15)_0%,_transparent_60%)]" />
        <div className="relative z-10 flex flex-col justify-between p-12 text-primary-foreground">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20 font-bold text-lg backdrop-blur-sm">
                S
              </div>
              <span className="font-display text-xl font-bold">School Manager</span>
            </div>
          </div>
          <div className="space-y-6">
            <blockquote className="space-y-2">
              <p className="text-2xl font-display font-semibold leading-tight">
                &ldquo;Managing our school has never been easier. Everything is in one place.&rdquo;
              </p>
              <footer className="text-sm opacity-80">
                — Mrs. Adebayo, Head Teacher, Greenfield Academy
              </footer>
            </blockquote>
          </div>
          <div className="text-xs opacity-60">
            © 2026 School Manager. Built for Nigerian schools.
          </div>
        </div>
        {/* Decorative shapes */}
        <div className="absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-white/5" />
        <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-white/5" />
        <div className="absolute top-1/3 -left-10 h-32 w-32 rounded-full bg-white/5" />
      </div>

      {/* Right panel — auth forms */}
      <div className="flex w-full lg:w-1/2 items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-[400px]">
          {children}
        </div>
      </div>
    </div>
  );
}
