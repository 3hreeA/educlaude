import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { DashboardShell } from "@/components/layouts/dashboard-shell";
import { ROLE_NAV_ITEMS } from "@/types/api";
import type { UserRole } from "@/types/database";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = createServerSupabaseClient();

  const { data: { session } } = await supabase.auth.getSession();
  if (!session) redirect("/login");

  const { data: user } = await supabase
    .from("users")
    .select("id, first_name, last_name, email, role, avatar_url, school_id")
    .eq("auth_id", session.user.id)
    .single();

  if (!user) redirect("/login");

  // Get school name
  const { data: school } = await supabase
    .from("schools")
    .select("name")
    .eq("id", user.school_id)
    .single();

  const role = user.role as UserRole;
  const navItems = ROLE_NAV_ITEMS[role] || [];

  return (
    <DashboardShell
      user={{
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
        role: user.role,
        avatar_url: user.avatar_url,
      }}
      navItems={navItems}
      role={role}
      schoolName={school?.name || "School Manager"}
    >
      {children}
    </DashboardShell>
  );
}
