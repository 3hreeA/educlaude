"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { ClipboardCheck, BookOpen, Users, MessageSquare } from "lucide-react";
import { useTeacherClasses, useClassStudents } from "@/features/teachers/hooks";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import { Badge } from "@/components/ui/badge";

export default function ClassDetailPage() {
  const params = useParams();
  const classId = params.classId as string;

  const { data: classes, isLoading: loadingClasses } = useTeacherClasses();
  const { data: students, isLoading: loadingStudents } = useClassStudents(classId);

  const cls = classes?.find((c) => c.id === classId);

  if (loadingClasses) {
    return (
      <div className="flex items-center justify-center h-48">
        <LoadingSpinner />
      </div>
    );
  }

  if (!cls) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p>Class not found or you don&apos;t have access.</p>
      </div>
    );
  }

  const actions = [
    {
      href: `/teacher/classes/${classId}/attendance`,
      icon: ClipboardCheck,
      label: "Mark Attendance",
      description: cls.attendance_marked_today ? "Attendance marked today" : "Not yet marked today",
      color: cls.attendance_marked_today ? "text-green-600 bg-green-50" : "text-amber-600 bg-amber-50",
      badge: !cls.attendance_marked_today ? "Pending" : null,
    },
    {
      href: `/teacher/classes/${classId}/grades`,
      icon: BookOpen,
      label: "Grades & Assessments",
      description: "Enter and manage student grades",
      color: "text-violet-600 bg-violet-50",
      badge: null,
    },
    {
      href: `/teacher/feedback?class=${classId}`,
      icon: MessageSquare,
      label: "Student Feedback",
      description: "Provide feedback for students",
      color: "text-blue-600 bg-blue-50",
      badge: null,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={cls.name}
        description={`${cls.level} · ${cls.student_count} students`}
        backHref="/teacher/classes"
      />

      {/* Class Info */}
      <div className="flex flex-wrap gap-2">
        {cls.is_class_teacher && (
          <Badge variant="default">Class Teacher</Badge>
        )}
        {cls.subjects.map((s) => (
          <Badge key={s.id} variant="secondary">{s.name}</Badge>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid gap-3 sm:grid-cols-3">
        {actions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="rounded-lg border bg-card p-4 hover:border-primary/40 hover:shadow-sm transition-all"
          >
            <div className="flex items-start gap-3">
              <div className={`rounded-lg p-2.5 ${action.color}`}>
                <action.icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold">{action.label}</h3>
                  {action.badge && (
                    <Badge variant="outline" className="text-[10px] text-amber-600 border-amber-300">
                      {action.badge}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{action.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Student Roster */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Users className="h-4 w-4 text-muted-foreground" />
          <h2 className="text-lg font-semibold">Class Roster</h2>
          <span className="text-sm text-muted-foreground">({students?.length || 0} students)</span>
        </div>

        {loadingStudents ? (
          <div className="flex items-center justify-center h-32">
            <LoadingSpinner />
          </div>
        ) : students && students.length > 0 ? (
          <div className="rounded-lg border overflow-hidden">
            <div className="grid grid-cols-[40px_1fr_auto] gap-0 bg-muted/50 px-3 py-2 text-xs font-medium text-muted-foreground border-b">
              <span>#</span>
              <span>Student</span>
              <span>Adm. No.</span>
            </div>
            <div className="divide-y max-h-96 overflow-y-auto">
              {students.map((s, idx) => (
                <div key={s.id} className="grid grid-cols-[40px_1fr_auto] gap-0 px-3 py-2 items-center text-sm">
                  <span className="text-xs text-muted-foreground">{idx + 1}</span>
                  <div>
                    <span className="font-medium">{s.last_name}, {s.first_name}</span>
                    {s.medical_notes && (
                      <span className="ml-2 text-[10px] text-amber-600" title={s.medical_notes}>⚕️</span>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">{s.admission_number}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-8">No students in this class.</p>
        )}
      </div>
    </div>
  );
}
