"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { CalendarDays, CheckCircle2 } from "lucide-react";
import {
  useTeacherClasses,
  useClassStudents,
  useClassAttendance,
  useMarkAttendance,
} from "@/features/teachers/hooks";
import { AttendanceMarking } from "@/components/features/attendance/attendance-marking";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import type { AttendanceEntry } from "@/features/teachers/hooks";

export default function AttendanceMarkingPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.classId as string;

  const today = new Date().toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(today);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const { data: classes } = useTeacherClasses();
  const { data: students, isLoading: loadingStudents } = useClassStudents(classId);
  const { data: existingRecords, isLoading: loadingRecords } = useClassAttendance(classId, selectedDate);
  const markAttendance = useMarkAttendance();

  const cls = classes?.find((c) => c.id === classId);

  const handleSubmit = (entries: AttendanceEntry[]) => {
    setSuccessMessage(null);
    markAttendance.mutate(
      { class_id: classId, date: selectedDate, entries },
      {
        onSuccess: (data) => {
          setSuccessMessage(
            `Attendance saved for ${data.saved} students on ${new Date(selectedDate).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })}`
          );
        },
      }
    );
  };

  const isLoading = loadingStudents || loadingRecords;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Mark Attendance"
        description={cls ? `${cls.name} · ${cls.student_count} students` : "Loading..."}
        backHref={`/teacher/classes/${classId}`}
      />

      {/* Date Selector */}
      <div className="flex items-center gap-3">
        <CalendarDays className="h-4 w-4 text-muted-foreground" />
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => {
            setSelectedDate(e.target.value);
            setSuccessMessage(null);
          }}
          max={today}
          className="text-sm px-3 py-1.5 rounded-lg border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
        />
        {selectedDate === today && (
          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">Today</span>
        )}
      </div>

      {/* Success Message */}
      {successMessage && (
        <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-4 py-3">
          <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-800">{successMessage}</p>
        </div>
      )}

      {/* Error Message */}
      {markAttendance.isError && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3">
          <p className="text-sm text-red-800">
            Failed to save attendance. Please try again.
          </p>
        </div>
      )}

      {/* Attendance Grid */}
      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <LoadingSpinner />
        </div>
      ) : students && students.length > 0 ? (
        <AttendanceMarking
          students={students}
          existingRecords={existingRecords}
          onSubmit={handleSubmit}
          isSubmitting={markAttendance.isPending}
        />
      ) : (
        <p className="text-sm text-muted-foreground text-center py-12">
          No students found in this class.
        </p>
      )}
    </div>
  );
}
