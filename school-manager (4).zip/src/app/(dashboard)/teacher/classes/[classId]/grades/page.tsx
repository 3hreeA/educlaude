"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Plus, BookOpen, CheckCircle2, Clock, FileText } from "lucide-react";
import {
  useTeacherClasses,
  useTeacherAssessments,
  useCreateAssessment,
} from "@/features/teachers/hooks";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import { EmptyState } from "@/components/shared/empty-state";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function ClassGradesPage() {
  const params = useParams();
  const classId = params.classId as string;

  const { data: classes } = useTeacherClasses();
  const { data: assessments, isLoading } = useTeacherAssessments(classId);
  const createAssessment = useCreateAssessment();

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    subject_id: "",
    max_score: "20",
    weight: "10",
    date: new Date().toISOString().split("T")[0],
  });

  const cls = classes?.find((c) => c.id === classId);
  const subjects = cls?.subjects || [];

  const handleCreateAssessment = () => {
    if (!formData.name || !formData.subject_id || !formData.max_score) return;
    createAssessment.mutate(
      {
        class_id: classId,
        subject_id: formData.subject_id,
        name: formData.name,
        max_score: parseFloat(formData.max_score),
        weight: parseFloat(formData.weight) || 1,
        date: formData.date,
      },
      {
        onSuccess: () => {
          setShowForm(false);
          setFormData({ name: "", subject_id: "", max_score: "20", weight: "10", date: new Date().toISOString().split("T")[0] });
        },
      }
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Grades & Assessments"
        description={cls ? `${cls.name}` : "Loading..."}
        backHref={`/teacher/classes/${classId}`}
      />

      {/* Create Assessment Button */}
      <div className="flex justify-end">
        <Button onClick={() => setShowForm(!showForm)} className="gap-2" variant={showForm ? "outline" : "default"}>
          <Plus className="h-4 w-4" />
          {showForm ? "Cancel" : "New Assessment"}
        </Button>
      </div>

      {/* Create Assessment Form */}
      {showForm && (
        <div className="rounded-lg border bg-card p-4 space-y-3">
          <h3 className="text-sm font-semibold">Create New Assessment</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Assessment Name *</label>
              <input
                type="text"
                placeholder="e.g., CA Test 1, Mid-Term Exam"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full text-sm px-3 py-2 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Subject *</label>
              <select
                value={formData.subject_id}
                onChange={(e) => setFormData({ ...formData, subject_id: e.target.value })}
                className="w-full text-sm px-3 py-2 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="">Select subject</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Max Score *</label>
              <input
                type="number"
                min="1"
                max="200"
                value={formData.max_score}
                onChange={(e) => setFormData({ ...formData, max_score: e.target.value })}
                className="w-full text-sm px-3 py-2 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Weight (%)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="w-full text-sm px-3 py-2 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full text-sm px-3 py-2 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button
              onClick={handleCreateAssessment}
              disabled={!formData.name || !formData.subject_id || createAssessment.isPending}
            >
              {createAssessment.isPending ? "Creating..." : "Create Assessment"}
            </Button>
          </div>
        </div>
      )}

      {/* Assessments List */}
      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <LoadingSpinner />
        </div>
      ) : assessments && assessments.length > 0 ? (
        <div className="space-y-2">
          {assessments.map((a) => (
            <Link
              key={a.id}
              href={`/teacher/classes/${classId}/grades/${a.id}`}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg border bg-card hover:border-primary/40 hover:shadow-sm transition-all"
              )}
            >
              <div className={cn(
                "rounded-lg p-2",
                a.is_complete ? "bg-green-50 text-green-600" : "bg-muted"
              )}>
                {a.is_complete ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <FileText className="h-5 w-5 text-muted-foreground" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold truncate">{a.name}</h3>
                  {a.subject && (
                    <Badge variant="secondary" className="text-[10px]">{a.subject.name}</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Max: {a.max_score} · Weight: {a.weight}% · {new Date(a.date).toLocaleDateString("en-NG", { day: "numeric", month: "short" })}
                </p>
              </div>

              <div className="text-right flex-shrink-0">
                <p className="text-sm font-medium">
                  {a.grades_entered}/{a.total_students}
                </p>
                <p className="text-[10px] text-muted-foreground">graded</p>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={BookOpen}
          title="No Assessments Yet"
          description="Create your first assessment to start entering grades."
        />
      )}
    </div>
  );
}
