"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import { useAssessmentGrades, useBulkGradeEntry } from "@/features/teachers/hooks";
import { GradeEntryGrid } from "@/components/features/grades/grade-entry-grid";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import { Badge } from "@/components/ui/badge";
import type { GradeEntryInput } from "@/features/teachers/hooks";

export default function GradeEntryPage() {
  const params = useParams();
  const classId = params.classId as string;
  const assessmentId = params.assessmentId as string;

  const { data, isLoading } = useAssessmentGrades(assessmentId);
  const bulkGrade = useBulkGradeEntry();
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSubmit = (grades: GradeEntryInput[]) => {
    setSuccessMessage(null);
    bulkGrade.mutate(
      { assessment_id: assessmentId, grades },
      {
        onSuccess: (result) => {
          setSuccessMessage(`Grades saved for ${result.saved} students.`);
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <LoadingSpinner />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <p>Assessment not found.</p>
      </div>
    );
  }

  const { assessment, students } = data;

  return (
    <div className="space-y-6">
      <PageHeader
        title={assessment.name}
        description={`${assessment.subject?.name || "Subject"} · ${assessment.class?.name || "Class"}`}
        backHref={`/teacher/classes/${classId}/grades`}
      />

      {/* Assessment Info */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="secondary">Max Score: {assessment.max_score}</Badge>
        <Badge variant="secondary">Weight: {assessment.weight}%</Badge>
        <Badge variant="secondary">
          Date: {new Date(assessment.date).toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" })}
        </Badge>
      </div>

      {/* Success Message */}
      {successMessage && (
        <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-4 py-3">
          <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-800">{successMessage}</p>
        </div>
      )}

      {/* Error Message */}
      {bulkGrade.isError && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3">
          <p className="text-sm text-red-800">
            Failed to save grades. Please check scores and try again.
          </p>
        </div>
      )}

      {/* Grade Entry Grid */}
      <GradeEntryGrid
        students={students}
        maxScore={assessment.max_score}
        assessmentName={assessment.name}
        onSubmit={handleSubmit}
        isSubmitting={bulkGrade.isPending}
      />
    </div>
  );
}
