"use client";

import { useTeacherClasses } from "@/features/teachers/hooks";
import { ClassCard } from "@/components/features/teachers/class-card";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import { EmptyState } from "@/components/shared/empty-state";
import { BookOpen } from "lucide-react";

export default function TeacherClassesPage() {
  const { data: classes, isLoading } = useTeacherClasses();

  return (
    <div className="space-y-6">
      <PageHeader
        title="My Classes"
        description="View and manage your assigned classes"
      />

      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <LoadingSpinner />
        </div>
      ) : classes && classes.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((cls) => (
            <ClassCard key={cls.id} cls={cls} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={BookOpen}
          title="No Classes Assigned"
          description="You haven't been assigned any classes yet. Contact your administrator."
        />
      )}
    </div>
  );
}
