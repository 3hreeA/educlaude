"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { CheckCircle2, MessageSquarePlus } from "lucide-react";
import {
  useTeacherClasses,
  useClassStudents,
  useSubmitFeedback,
} from "@/features/teachers/hooks";
import { FeedbackForm } from "@/components/features/feedback/feedback-form";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import type { FeedbackInput } from "@/features/teachers/hooks";

export default function TeacherFeedbackPage() {
  const searchParams = useSearchParams();
  const initialClassId = searchParams.get("class") || "";

  const [selectedClassId, setSelectedClassId] = useState(initialClassId);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const { data: classes, isLoading: loadingClasses } = useTeacherClasses();
  const { data: students, isLoading: loadingStudents } = useClassStudents(selectedClassId);
  const submitFeedback = useSubmitFeedback();

  const handleSubmit = (feedback: FeedbackInput) => {
    setSuccessMessage(null);
    submitFeedback.mutate(feedback, {
      onSuccess: () => {
        const student = students?.find((s) => s.id === feedback.student_id);
        setSuccessMessage(
          `Feedback submitted for ${student ? `${student.first_name} ${student.last_name}` : "student"}.`
        );
      },
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Student Feedback"
        description="Provide behavioral and academic feedback for your students"
        backHref="/teacher"
      />

      {/* Class Selector */}
      <div>
        <label className="text-sm font-medium mb-2 block">Select Class</label>
        {loadingClasses ? (
          <LoadingSpinner />
        ) : (
          <div className="flex flex-wrap gap-2">
            {classes?.map((cls) => (
              <button
                key={cls.id}
                onClick={() => {
                  setSelectedClassId(cls.id);
                  setSuccessMessage(null);
                }}
                className={`px-3 py-1.5 text-sm rounded-lg border transition-colors ${
                  selectedClassId === cls.id
                    ? "border-primary bg-primary/5 text-primary font-medium"
                    : "border-input hover:bg-muted/50"
                }`}
              >
                {cls.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Success Message */}
      {successMessage && (
        <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-4 py-3">
          <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-800">{successMessage}</p>
        </div>
      )}

      {/* Error Message */}
      {submitFeedback.isError && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3">
          <p className="text-sm text-red-800">
            Failed to submit feedback. Please try again.
          </p>
        </div>
      )}

      {/* Feedback Form */}
      {selectedClassId ? (
        loadingStudents ? (
          <div className="flex items-center justify-center h-32">
            <LoadingSpinner />
          </div>
        ) : students && students.length > 0 ? (
          <FeedbackForm
            students={students}
            onSubmit={handleSubmit}
            isSubmitting={submitFeedback.isPending}
          />
        ) : (
          <p className="text-sm text-muted-foreground text-center py-8">
            No students found in this class.
          </p>
        )
      ) : (
        <div className="rounded-lg border bg-card p-8 text-center text-muted-foreground">
          <MessageSquarePlus className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Select a class above to begin providing feedback.</p>
        </div>
      )}
    </div>
  );
}
