"use client";

import { useState } from "react";
import { Megaphone, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { AnnouncementCard } from "@/components/features/announcements/announcement-card";
import { useAnnouncements } from "@/features/announcements/hooks";

export default function TeacherAnnouncementsPage() {
  const [page, setPage] = useState(1);
  const { data, isLoading, error } = useAnnouncements(page, 10);

  const announcements = data?.announcements || [];
  const pagination = data?.pagination;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Announcements"
        description="School news and updates"
      />

      {isLoading && <ListSkeleton rows={5} />}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">Failed to load announcements.</p>
        </div>
      )}

      {!isLoading && announcements.length === 0 && (
        <EmptyState
          icon={Megaphone}
          title="No announcements"
          description="There are no announcements at this time."
        />
      )}

      {!isLoading && announcements.length > 0 && (
        <>
          <div className="space-y-4">
            {announcements.map((announcement, index) => (
              <AnnouncementCard
                key={announcement.id}
                announcement={announcement}
                defaultExpanded={index === 0}
              />
            ))}
          </div>

          {pagination && pagination.total_pages > 1 && (
            <div className="flex items-center justify-center gap-4 pt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {page} of {pagination.total_pages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => p + 1)}
                disabled={page >= pagination.total_pages}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
