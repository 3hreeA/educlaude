"use client";

import { Users, BookOpen, ClipboardCheck, FileText, AlertCircle, ChevronRight } from "lucide-react";
import Link from "next/link";
import { StatCard } from "@/components/shared/stat-card";
import { Badge } from "@/components/ui/badge";
import { useTeacherClasses } from "@/features/teachers/hooks";
import { LoadingSpinner } from "@/components/shared/loading-spinner";

export default function TeacherDashboard() {
  const { data: classes, isLoading } = useTeacherClasses();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  const totalStudents = classes?.reduce((sum, c) => sum + c.student_count, 0) || 0;
  const totalClasses = classes?.length || 0;
  const pendingAttendance = classes?.filter((c) => !c.attendance_marked_today).length || 0;
  const uniqueSubjects = new Set(classes?.flatMap((c) => c.subjects.map((s) => s.id)) || []).size;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold font-display tracking-tight">Teacher Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage your classes, attendance, and grades.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Students"
          value={totalStudents}
          subtitle="Across all classes"
          icon={Users}
          iconColor="text-primary"
          iconBg="bg-primary/10"
        />
        <StatCard
          title="My Classes"
          value={totalClasses}
          subtitle={`${uniqueSubjects} subjects`}
          icon={BookOpen}
          iconColor="text-violet-600"
          iconBg="bg-violet-50"
        />
        <StatCard
          title="Pending Attendance"
          value={pendingAttendance}
          subtitle="Not marked today"
          icon={ClipboardCheck}
          iconColor={pendingAttendance > 0 ? "text-amber-600" : "text-green-600"}
          iconBg={pendingAttendance > 0 ? "bg-amber-50" : "bg-green-50"}
        />
        <StatCard
          title="Subjects"
          value={uniqueSubjects}
          subtitle="Assigned to teach"
          icon={FileText}
          iconColor="text-rose-600"
          iconBg="bg-rose-50"
        />
      </div>

      {pendingAttendance > 0 && (
        <div className="rounded-lg border border-amber-200 bg-amber-50/50 p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium text-amber-800">
                Attendance pending for {pendingAttendance} class{pendingAttendance > 1 ? "es" : ""}
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {classes
                  ?.filter((c) => !c.attendance_marked_today)
                  .map((c) => (
                    <Link
                      key={c.id}
                      href={`/teacher/classes/${c.id}/attendance`}
                      className="inline-flex items-center gap-1.5 text-xs font-medium bg-white px-3 py-1.5 rounded-full border border-amber-200 text-amber-800 hover:bg-amber-100 transition-colors"
                    >
                      {c.name}
                      <ChevronRight className="h-3 w-3" />
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">My Classes</h2>
          <Link href="/teacher/classes" className="text-sm text-primary hover:underline">
            View all →
          </Link>
        </div>

        {classes && classes.length > 0 ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {classes.map((cls) => (
              <Link
                key={cls.id}
                href={`/teacher/classes/${cls.id}`}
                className="block rounded-lg border bg-card p-4 hover:border-primary/40 hover:shadow-sm transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold">{cls.name}</h3>
                  {cls.is_class_teacher && (
                    <Badge variant="default" className="text-[10px] px-2 py-0.5">
                      Class Teacher
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mb-2">
                  {cls.student_count} students · {cls.subjects.length} subjects
                </p>
                <div className="flex flex-wrap gap-1">
                  {cls.subjects.slice(0, 3).map((s) => (
                    <Badge key={s.id} variant="secondary" className="text-[10px] font-normal">
                      {s.name}
                    </Badge>
                  ))}
                  {cls.subjects.length > 3 && (
                    <Badge variant="secondary" className="text-[10px] font-normal">
                      +{cls.subjects.length - 3}
                    </Badge>
                  )}
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="rounded-lg border bg-card p-8 text-center text-muted-foreground">
            <p className="text-sm">No class assignments found.</p>
            <p className="text-xs mt-1">Contact your admin to assign classes and subjects.</p>
          </div>
        )}
      </div>
    </div>
  );
}
