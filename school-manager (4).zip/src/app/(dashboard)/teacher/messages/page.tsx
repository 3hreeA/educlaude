"use client";

import { useState, useRef, useEffect } from "react";
import {
  MessageSquare, Send, ArrowLeft, Mail, MailOpen, User, Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatDateTime } from "@/lib/utils/format";
import { useConversations, useThread, useSendMessage, type Conversation } from "@/features/messages/hooks";

export default function TeacherMessagesPage() {
  const { data: convData, isLoading: convLoading } = useConversations();
  const conversations = convData?.conversations || [];
  const totalUnread = convData?.total_unread || 0;

  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [showCompose, setShowCompose] = useState(false);
  const [composeRecipient, setComposeRecipient] = useState("");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeContent, setComposeContent] = useState("");

  const { data: threadData, isLoading: threadLoading } = useThread(activeConv?.thread_id || null);
  const messages = threadData?.messages || [];
  const sendMessage = useSendMessage();
  const [newMsg, setNewMsg] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend() {
    if (!newMsg.trim() || !activeConv) return;
    await sendMessage.mutateAsync({
      recipient_id: activeConv.contact_id,
      content: newMsg.trim(),
      thread_id: activeConv.thread_id || undefined,
    });
    setNewMsg("");
  }

  async function handleCompose() {
    if (!composeRecipient || !composeContent.trim()) return;
    await sendMessage.mutateAsync({
      recipient_id: composeRecipient,
      content: composeContent.trim(),
      subject: composeSubject || undefined,
    });
    setShowCompose(false);
    setComposeRecipient("");
    setComposeSubject("");
    setComposeContent("");
  }

  // Thread view
  if (activeConv) {
    return (
      <div className="flex flex-col h-[calc(100vh-8rem)] animate-fade-in">
        <div className="flex items-center gap-3 pb-4 border-b mb-4">
          <Button variant="ghost" size="sm" onClick={() => setActiveConv(null)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold text-sm">{activeConv.contact_name}</h2>
            <p className="text-[11px] text-muted-foreground capitalize">{activeConv.contact_role}</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 pb-4">
          {threadLoading && <ListSkeleton rows={4} />}
          {!threadLoading && messages.length === 0 && (
            <p className="text-center text-sm text-muted-foreground py-8">No messages yet.</p>
          )}
          {messages.map((msg) => {
            const isMe = msg.sender?.id !== activeConv.contact_id;
            return (
              <div key={msg.id} className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                  isMe ? "bg-primary text-primary-foreground rounded-br-md" : "bg-muted rounded-bl-md"
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  <p className={`text-[10px] mt-1 ${isMe ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                    {formatDateTime(msg.created_at)}
                  </p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t pt-3 flex gap-2">
          <Input
            value={newMsg}
            onChange={(e) => setNewMsg(e.target.value)}
            placeholder="Type a message..."
            className="flex-1"
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
          />
          <Button onClick={handleSend} disabled={!newMsg.trim() || sendMessage.isPending}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  // Conversation list + compose
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Messages" description={totalUnread > 0 ? `${totalUnread} unread` : "Communicate with parents"}>
        <Button onClick={() => setShowCompose(!showCompose)}>
          <Plus className="h-4 w-4 mr-2" /> New Message
        </Button>
      </PageHeader>

      {/* Compose */}
      {showCompose && (
        <Card>
          <CardHeader><CardTitle className="text-sm">New Message</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label>Recipient (paste parent&apos;s user ID)</Label>
              <Input
                value={composeRecipient}
                onChange={(e) => setComposeRecipient(e.target.value)}
                placeholder="User ID of parent..."
              />
              <p className="text-[10px] text-muted-foreground">Tip: find parent IDs in the class roster</p>
            </div>
            <div className="space-y-1.5">
              <Label>Subject (optional)</Label>
              <Input value={composeSubject} onChange={(e) => setComposeSubject(e.target.value)} placeholder="Message subject..." />
            </div>
            <div className="space-y-1.5">
              <Label>Message</Label>
              <textarea
                value={composeContent}
                onChange={(e) => setComposeContent(e.target.value)}
                placeholder="Write your message..."
                rows={4}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCompose} disabled={!composeRecipient || !composeContent.trim() || sendMessage.isPending}>
                <Send className="h-4 w-4 mr-2" /> Send
              </Button>
              <Button variant="ghost" onClick={() => setShowCompose(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {convLoading && <ListSkeleton rows={5} />}

      {!convLoading && conversations.length === 0 && (
        <EmptyState icon={MessageSquare} title="No messages yet" description="Start a conversation with a parent using the New Message button." />
      )}

      {!convLoading && conversations.length > 0 && (
        <div className="space-y-2">
          {conversations.map((conv) => (
            <Card
              key={conv.contact_id}
              className="hover:shadow-sm transition-shadow cursor-pointer"
              onClick={() => setActiveConv(conv)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    {conv.unread > 0 ? <Mail className="h-4 w-4 text-primary" /> : <MailOpen className="h-4 w-4 text-muted-foreground" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className={`text-sm ${conv.unread > 0 ? "font-bold" : "font-medium"}`}>{conv.contact_name}</h3>
                      <Badge variant="outline" className="text-[9px] capitalize">{conv.contact_role}</Badge>
                      {conv.unread > 0 && <Badge className="text-[9px] h-5 min-w-[20px] flex items-center justify-center">{conv.unread}</Badge>}
                    </div>
                    <p className={`text-xs truncate ${conv.unread > 0 ? "text-foreground" : "text-muted-foreground"}`}>{conv.last_message}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">{formatDateTime(conv.last_at)}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
