"use client";

import Link from "next/link";
import { CheckCircle2, AlertCircle, ChevronRight, CalendarDays } from "lucide-react";
import { useTeacherClasses } from "@/features/teachers/hooks";
import { PageHeader } from "@/components/shared/page-header";
import { LoadingSpinner } from "@/components/shared/loading-spinner";
import { cn } from "@/lib/utils";

export default function AttendanceOverviewPage() {
  const { data: classes, isLoading } = useTeacherClasses();

  const today = new Date().toLocaleDateString("en-NG", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const pending = classes?.filter((c) => !c.attendance_marked_today) || [];
  const completed = classes?.filter((c) => c.attendance_marked_today) || [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Attendance"
        description={today}
      />

      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <LoadingSpinner />
        </div>
      ) : (
        <>
          {/* Pending */}
          {pending.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                <h2 className="text-sm font-semibold text-amber-800">
                  Pending ({pending.length})
                </h2>
              </div>
              <div className="space-y-2">
                {pending.map((cls) => (
                  <Link
                    key={cls.id}
                    href={`/teacher/classes/${cls.id}/attendance`}
                    className="flex items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50/50 px-4 py-3 hover:bg-amber-50 transition-colors"
                  >
                    <div>
                      <p className="text-sm font-semibold text-amber-900">{cls.name}</p>
                      <p className="text-xs text-amber-700">{cls.student_count} students</p>
                    </div>
                    <div className="flex items-center gap-1 text-amber-700">
                      <span className="text-xs font-medium">Mark now</span>
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Completed */}
          {completed.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <h2 className="text-sm font-semibold text-green-800">
                  Completed ({completed.length})
                </h2>
              </div>
              <div className="space-y-2">
                {completed.map((cls) => (
                  <Link
                    key={cls.id}
                    href={`/teacher/classes/${cls.id}/attendance`}
                    className="flex items-center justify-between gap-3 rounded-lg border border-green-200 bg-green-50/30 px-4 py-3 hover:bg-green-50 transition-colors"
                  >
                    <div>
                      <p className="text-sm font-semibold text-green-900">{cls.name}</p>
                      <p className="text-xs text-green-700">{cls.student_count} students</p>
                    </div>
                    <div className="flex items-center gap-1 text-green-700">
                      <span className="text-xs font-medium">Edit</span>
                      <ChevronRight className="h-4 w-4" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* All done */}
          {pending.length === 0 && completed.length > 0 && (
            <div className="rounded-lg border border-green-200 bg-green-50 p-4 text-center">
              <CheckCircle2 className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <p className="text-sm font-medium text-green-800">
                All attendance marked for today!
              </p>
            </div>
          )}

          {/* No classes */}
          {classes?.length === 0 && (
            <div className="rounded-lg border bg-card p-8 text-center text-muted-foreground">
              <CalendarDays className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No classes assigned.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
