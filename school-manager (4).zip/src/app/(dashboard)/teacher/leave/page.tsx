"use client";

import { useState } from "react";
import {
  Calendar, Plus, Clock, Check, X, Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatDate } from "@/lib/utils/format";
import { useLeaveRequests } from "@/features/admin/hooks";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/utils/api-client";

const LEAVE_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  pending: "warning",
  approved: "success",
  rejected: "destructive",
  cancelled: "default",
};

const LEAVE_TYPES = [
  { value: "sick", label: "Sick Leave" },
  { value: "personal", label: "Personal Leave" },
  { value: "annual", label: "Annual Leave" },
  { value: "maternity", label: "Maternity Leave" },
  { value: "compassionate", label: "Compassionate Leave" },
  { value: "study", label: "Study Leave" },
];

export default function TeacherLeavePage() {
  const { data, isLoading } = useLeaveRequests();
  const leaves = data?.leaves || [];
  const [showForm, setShowForm] = useState(false);

  const [form, setForm] = useState({
    leave_type: "personal",
    start_date: "",
    end_date: "",
    reason: "",
  });

  const qc = useQueryClient();
  const createLeave = useMutation({
    mutationFn: (input: typeof form) =>
      apiFetch("/api/leave", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leave-requests"] });
      setShowForm(false);
      setForm({ leave_type: "personal", start_date: "", end_date: "", reason: "" });
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.start_date || !form.end_date || !form.reason) return;
    createLeave.mutate(form);
  }

  const pendingCount = leaves.filter((l) => l.status === "pending").length;
  const approvedCount = leaves.filter((l) => l.status === "approved").length;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Leave Requests" description="Submit and track your leave requests">
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4 mr-2" /> New Request
        </Button>
      </PageHeader>

      {/* Quick stats */}
      <div className="flex gap-4 text-sm">
        <div className="flex items-center gap-1.5">
          <Clock className="h-4 w-4 text-warning" />
          <span>{pendingCount} pending</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Check className="h-4 w-4 text-success" />
          <span>{approvedCount} approved</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span>{leaves.length} total</span>
        </div>
      </div>

      {/* New request form */}
      {showForm && (
        <Card>
          <CardHeader><CardTitle className="text-sm">New Leave Request</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Leave Type</Label>
                  <select
                    value={form.leave_type}
                    onChange={(e) => setForm((f) => ({ ...f, leave_type: e.target.value }))}
                    className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                  >
                    {LEAVE_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
                <div />
                <div className="space-y-1.5">
                  <Label>Start Date *</Label>
                  <Input
                    type="date"
                    value={form.start_date}
                    onChange={(e) => setForm((f) => ({ ...f, start_date: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>End Date *</Label>
                  <Input
                    type="date"
                    value={form.end_date}
                    onChange={(e) => setForm((f) => ({ ...f, end_date: e.target.value }))}
                    min={form.start_date}
                    required
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Reason *</Label>
                <textarea
                  value={form.reason}
                  onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))}
                  placeholder="Provide a reason for your leave request..."
                  rows={3}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  required
                />
              </div>
              <div className="flex gap-3">
                <Button type="submit" disabled={createLeave.isPending}>
                  <Send className="h-4 w-4 mr-2" />
                  {createLeave.isPending ? "Submitting..." : "Submit Request"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading && <ListSkeleton rows={4} />}

      {!isLoading && leaves.length === 0 && (
        <EmptyState icon={Calendar} title="No leave requests" description="You haven't submitted any leave requests yet." />
      )}

      {!isLoading && leaves.length > 0 && (
        <div className="space-y-3">
          {leaves.map((leave) => (
            <Card key={leave.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold text-sm capitalize">
                        {LEAVE_TYPES.find((t) => t.value === leave.leave_type)?.label || leave.leave_type}
                      </span>
                      <Badge variant={LEAVE_VARIANT[leave.status] || "default"} className="text-[10px] capitalize">
                        {leave.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(leave.start_date)} — {formatDate(leave.end_date)}
                      <span className="ml-1">({leave.days_count} day{leave.days_count !== 1 ? "s" : ""})</span>
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">{leave.reason}</p>
                    {leave.review_notes && (
                      <p className="text-xs mt-2 bg-muted/50 rounded px-2 py-1">
                        <span className="font-medium">Admin: </span>{leave.review_notes}
                      </p>
                    )}
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">{formatDate(leave.created_at)}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
