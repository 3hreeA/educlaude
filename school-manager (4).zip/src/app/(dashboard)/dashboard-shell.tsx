'use client';

import React from 'react';
import { Sidebar } from '@/components/layouts/sidebar';
import { Header } from '@/components/layouts/header';
import { MobileNav } from '@/components/layouts/mobile-nav';
import type { SessionUser } from '@/types/api';

interface DashboardShellProps {
  children: React.ReactNode;
  user: SessionUser;
  schoolName: string;
}

export function DashboardShell({ children, user, schoolName }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop sidebar */}
      <Sidebar role={user.role} schoolName={schoolName} />

      {/* Mobile navigation sheet */}
      <MobileNav role={user.role} schoolName={schoolName} />

      {/* Main content area */}
      <div className="flex flex-1 flex-col">
        <Header user={user} />
        <main className="flex-1 px-4 py-6 md:px-6 lg:px-8 animate-fade-in">
          {children}
        </main>
      </div>
    </div>
  );
}
