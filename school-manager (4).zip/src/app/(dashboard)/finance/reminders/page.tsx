"use client";

import { useState } from "react";
import {
  Bell, Send, MessageSquare, Mail, Smartphone, Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira, formatDateTime } from "@/lib/utils/format";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

interface ReminderLog {
  id: string;
  channel: string;
  message: string;
  status: string;
  sent_at: string;
  student_name: string;
  admission_number: string;
  balance: number;
}

function useReminderHistory() {
  return useQuery({
    queryKey: ["fee-reminders"],
    queryFn: () => apiFetch<{ reminders: ReminderLog[] }>("/api/finance/reminders"),
  });
}

function useSendReminders() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { aging?: string; channels: string[] }) =>
      apiFetch<{ sent: number; accounts_notified: number; channels: string[] }>(
        "/api/finance/reminders",
        { method: "POST", body: JSON.stringify(input) }
      ),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["fee-reminders"] }),
  });
}

const CHANNEL_ICONS: Record<string, typeof Mail> = {
  push: Bell,
  sms: Smartphone,
  whatsapp: MessageSquare,
  email: Mail,
};

const AGING_OPTIONS = [
  { value: "", label: "All overdue" },
  { value: "30", label: "30+ days overdue" },
  { value: "60", label: "60+ days overdue" },
  { value: "90", label: "90+ days overdue" },
];

export default function FeeRemindersPage() {
  const { data, isLoading } = useReminderHistory();
  const sendReminders = useSendReminders();
  const reminders = data?.reminders || [];

  const [aging, setAging] = useState("");
  const [channels, setChannels] = useState<string[]>(["push"]);

  function toggleChannel(ch: string) {
    setChannels((prev) =>
      prev.includes(ch) ? prev.filter((c) => c !== ch) : [...prev, ch]
    );
  }

  async function handleSend() {
    if (channels.length === 0) return;
    await sendReminders.mutateAsync({ aging: aging || undefined, channels });
  }

  const sentToday = reminders.filter((r) => {
    const today = new Date().toISOString().split("T")[0];
    return r.sent_at.startsWith(today);
  }).length;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Fee Reminders" description="Send automated payment reminders to parents" />

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <StatCard title="Total Sent" value={reminders.length} icon={Send} />
        <StatCard title="Sent Today" value={sentToday} icon={Clock} />
        <StatCard title="Channels Available" value="4" icon={MessageSquare} />
      </div>

      {/* Send reminders */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Send Reminders</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Target Accounts</Label>
            <select
              value={aging}
              onChange={(e) => setAging(e.target.value)}
              className="w-full h-10 rounded-md border bg-background px-3 text-sm max-w-xs"
            >
              {AGING_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <Label>Delivery Channels</Label>
            <div className="flex gap-2 flex-wrap">
              {(["push", "sms", "whatsapp", "email"] as const).map((ch) => {
                const Icon = CHANNEL_ICONS[ch] || Bell;
                const selected = channels.includes(ch);
                return (
                  <button
                    key={ch}
                    onClick={() => toggleChannel(ch)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-sm transition-colors ${
                      selected
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card hover:bg-muted"
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span className="capitalize">{ch === "push" ? "In-App" : ch}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex gap-2 items-center">
            <Button onClick={handleSend} disabled={channels.length === 0 || sendReminders.isPending}>
              <Send className="h-4 w-4 mr-2" />
              {sendReminders.isPending ? "Sending..." : "Send Reminders"}
            </Button>
            {sendReminders.data && (
              <p className="text-sm text-success">
                Sent {sendReminders.data.sent} reminders to {sendReminders.data.accounts_notified} accounts
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* History */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Reminder History</CardTitle></CardHeader>
        <CardContent className="p-0">
          {isLoading && <div className="p-4"><ListSkeleton rows={5} /></div>}

          {!isLoading && reminders.length === 0 && (
            <div className="p-8">
              <EmptyState icon={Bell} title="No reminders sent" description="Send your first batch of fee reminders above." />
            </div>
          )}

          {!isLoading && reminders.length > 0 && (
            <div className="divide-y max-h-[400px] overflow-y-auto">
              {reminders.map((r) => {
                const Icon = CHANNEL_ICONS[r.channel] || Bell;
                return (
                  <div key={r.id} className="px-4 py-3 flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                      <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-medium text-sm">{r.student_name}</span>
                        <span className="text-[10px] text-muted-foreground">{r.admission_number}</span>
                        <Badge variant={r.status === "sent" ? "success" : "warning"} className="text-[9px] capitalize">
                          {r.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{r.message}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-medium tabular-nums">{formatNaira(r.balance)}</p>
                      <p className="text-[10px] text-muted-foreground">{formatDateTime(r.sent_at)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
