"use client";

import { use } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, CheckCircle, Download, Banknote,
  FileSpreadsheet, Users, Receipt,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatNaira } from "@/lib/utils/format";
import { usePayrollDetail, useApprovePayroll } from "@/features/payroll/hooks";

const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "info"> = {
  draft: "warning",
  approved: "info",
  paid: "success",
};

export default function PayrollDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const { data, isLoading } = usePayrollDetail(id);
  const approvePayroll = useApprovePayroll();

  if (isLoading) return <ListSkeleton rows={8} />;
  if (!data) return <div className="p-8 text-center text-muted-foreground">Payroll run not found.</div>;

  const { run, payslips, summary } = data;
  const title = `${MONTH_NAMES[run.month - 1]} ${run.year} Payroll`;

  async function handleApprove() {
    await approvePayroll.mutateAsync({ id: run.id, action: "approve" });
  }

  async function handleMarkPaid() {
    await approvePayroll.mutateAsync({ id: run.id, action: "paid" });
  }

  function downloadNibss() {
    window.open(`/api/finance/payroll/${run.id}?format=nibss`, "_blank");
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title={title} description={`Status: ${run.status}`}>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" /> Back
          </Button>
          {run.status === "draft" && (
            <Button onClick={handleApprove} disabled={approvePayroll.isPending}>
              <CheckCircle className="h-4 w-4 mr-2" /> Approve
            </Button>
          )}
          {run.status === "approved" && (
            <>
              <Button variant="outline" onClick={downloadNibss}>
                <Download className="h-4 w-4 mr-2" /> NIBSS File
              </Button>
              <Button onClick={handleMarkPaid} disabled={approvePayroll.isPending}>
                <Banknote className="h-4 w-4 mr-2" /> Mark as Paid
              </Button>
            </>
          )}
          {run.status === "paid" && (
            <Button variant="outline" onClick={downloadNibss}>
              <Download className="h-4 w-4 mr-2" /> NIBSS File
            </Button>
          )}
        </div>
      </PageHeader>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <StatCard title="Staff Count" value={summary.staff_count} icon={Users} />
        <StatCard title="Total Gross" value={formatNaira(summary.total_gross)} icon={FileSpreadsheet} />
        <StatCard title="PAYE Tax" value={formatNaira(summary.total_paye)} icon={Receipt} />
        <StatCard title="Pension" value={formatNaira(summary.total_pension)} icon={Receipt} />
        <StatCard title="NHF" value={formatNaira(summary.total_nhf)} icon={Receipt} />
        <StatCard title="Total Net" value={formatNaira(summary.total_net)} icon={Banknote} />
      </div>

      {/* Payslips table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Payslips ({payslips.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left px-4 py-2 font-medium">Staff</th>
                  <th className="text-right px-4 py-2 font-medium">Gross</th>
                  <th className="text-right px-4 py-2 font-medium hidden md:table-cell">PAYE</th>
                  <th className="text-right px-4 py-2 font-medium hidden md:table-cell">Pension</th>
                  <th className="text-right px-4 py-2 font-medium hidden md:table-cell">NHF</th>
                  <th className="text-right px-4 py-2 font-medium">Net Pay</th>
                  <th className="text-left px-4 py-2 font-medium hidden lg:table-cell">Bank</th>
                </tr>
              </thead>
              <tbody>
                {payslips.map((slip) => (
                  <tr key={slip.id} className="border-b last:border-0 hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <div className="font-medium">{slip.teacher_name}</div>
                      <div className="text-[11px] text-muted-foreground">{slip.staff_id}</div>
                    </td>
                    <td className="text-right px-4 py-3 tabular-nums">{formatNaira(slip.gross_salary)}</td>
                    <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell text-destructive">{formatNaira(slip.tax_paye)}</td>
                    <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell text-destructive">{formatNaira(slip.pension)}</td>
                    <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell text-destructive">{formatNaira(slip.nhf)}</td>
                    <td className="text-right px-4 py-3 tabular-nums font-semibold">{formatNaira(slip.net_salary)}</td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      {slip.bank_name && (
                        <div>
                          <div className="text-xs">{slip.bank_name}</div>
                          <div className="text-[11px] text-muted-foreground">{slip.account_number}</div>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 font-semibold bg-muted/50">
                  <td className="px-4 py-3">Total</td>
                  <td className="text-right px-4 py-3 tabular-nums">{formatNaira(summary.total_gross)}</td>
                  <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(summary.total_paye)}</td>
                  <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(summary.total_pension)}</td>
                  <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(summary.total_nhf)}</td>
                  <td className="text-right px-4 py-3 tabular-nums">{formatNaira(summary.total_net)}</td>
                  <td className="hidden lg:table-cell" />
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
