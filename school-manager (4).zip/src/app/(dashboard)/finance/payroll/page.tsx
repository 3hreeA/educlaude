"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Banknote, Plus, ChevronRight, CheckCircle, Clock,
  FileText, AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira } from "@/lib/utils/format";
import { usePayrollRuns, useGeneratePayroll } from "@/features/payroll/hooks";

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "info"> = {
  draft: "warning",
  approved: "info",
  paid: "success",
};

export default function PayrollPage() {
  const router = useRouter();
  const { data, isLoading } = usePayrollRuns();
  const generatePayroll = useGeneratePayroll();
  const runs = data?.runs || [];

  const [showForm, setShowForm] = useState(false);
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());

  async function handleGenerate() {
    try {
      const result = await generatePayroll.mutateAsync({ month, year });
      setShowForm(false);
      router.push(`/finance/payroll/${result.run_id}`);
    } catch {
      // Error handled by mutation
    }
  }

  const totalPaid = runs.filter((r) => r.status === "paid").reduce((s, r) => s + r.total_net, 0);
  const pendingApproval = runs.filter((r) => r.status === "draft").length;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Payroll" description="Process and manage staff payroll">
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => router.push("/finance/salary")}>
            <Banknote className="h-4 w-4 mr-2" /> Salary Setup
          </Button>
          <Button onClick={() => setShowForm(!showForm)}>
            <Plus className="h-4 w-4 mr-2" /> New Payroll
          </Button>
        </div>
      </PageHeader>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Total Runs" value={runs.length} icon={FileText} />
        <StatCard title="Total Disbursed" value={formatNaira(totalPaid)} icon={Banknote} />
        <StatCard title="Pending Approval" value={pendingApproval} icon={Clock} />
        <StatCard
          title="Latest Staff Count"
          value={runs.length > 0 ? runs[0].staff_count : 0}
          icon={CheckCircle}
        />
      </div>

      {/* Generate form */}
      {showForm && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Generate Payroll</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-end gap-4 flex-wrap">
              <div className="space-y-1.5">
                <Label>Month</Label>
                <select
                  value={month}
                  onChange={(e) => setMonth(Number(e.target.value))}
                  className="h-10 rounded-md border bg-background px-3 text-sm w-40"
                >
                  {MONTH_NAMES.map((m, i) => (
                    <option key={i} value={i + 1}>{m}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Year</Label>
                <select
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  className="h-10 rounded-md border bg-background px-3 text-sm w-28"
                >
                  {[now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1].map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
              <Button onClick={handleGenerate} disabled={generatePayroll.isPending}>
                {generatePayroll.isPending ? "Generating..." : "Generate"}
              </Button>
              <Button variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
            {generatePayroll.isError && (
              <p className="text-sm text-destructive mt-2 flex items-center gap-1">
                <AlertTriangle className="h-3.5 w-3.5" />
                {(generatePayroll.error as Error)?.message || "Failed to generate payroll"}
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {isLoading && <ListSkeleton rows={5} />}

      {!isLoading && runs.length === 0 && (
        <EmptyState icon={Banknote} title="No payroll runs" description="Generate your first payroll to get started." />
      )}

      {!isLoading && runs.length > 0 && (
        <div className="space-y-3">
          {runs.map((run) => (
            <Card
              key={run.id}
              className="hover:shadow-sm transition-shadow cursor-pointer"
              onClick={() => router.push(`/finance/payroll/${run.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex flex-col items-center justify-center shrink-0">
                    <span className="text-[10px] font-medium text-muted-foreground">{MONTH_NAMES[run.month - 1]}</span>
                    <span className="text-sm font-bold text-primary">{run.year}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="font-semibold text-sm">
                        {MONTH_NAMES[run.month - 1]} {run.year} Payroll
                      </h3>
                      <Badge variant={STATUS_VARIANT[run.status] || "default"} className="text-[10px] capitalize">
                        {run.status}
                      </Badge>
                    </div>
                    <div className="flex gap-4 text-[11px] text-muted-foreground">
                      <span>{run.staff_count} staff</span>
                      <span>Gross: {formatNaira(run.total_gross)}</span>
                      <span className="font-medium text-foreground">Net: {formatNaira(run.total_net)}</span>
                      {run.processed_by_name && <span>by {run.processed_by_name}</span>}
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
