"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, Banknote, Save, Edit, Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira } from "@/lib/utils/format";
import { useSalaryStructures, useSaveSalary } from "@/features/payroll/hooks";

export default function SalarySetupPage() {
  const router = useRouter();
  const { data, isLoading } = useSalaryStructures();
  const saveSalary = useSaveSalary();
  const salaries = data?.salaries || [];

  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({
    basic_salary: 0,
    housing_allowance: 0,
    transport_allowance: 0,
    meal_allowance: 0,
  });

  function startEdit(s: { teacher_id: string; basic_salary: number; housing_allowance: number; transport_allowance: number; meal_allowance: number }) {
    setEditingId(s.teacher_id);
    setForm({
      basic_salary: s.basic_salary,
      housing_allowance: s.housing_allowance,
      transport_allowance: s.transport_allowance,
      meal_allowance: s.meal_allowance,
    });
  }

  async function handleSave(teacherId: string) {
    await saveSalary.mutateAsync({
      teacher_id: teacherId,
      ...form,
    });
    setEditingId(null);
  }

  const activeCount = salaries.filter((s) => s.is_active).length;
  const totalMonthly = salaries.filter((s) => s.is_active).reduce((s, sal) => s + sal.gross_salary, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Salary Setup" description="Configure teacher salary structures">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
      </PageHeader>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <StatCard title="Staff Configured" value={activeCount} icon={Users} />
        <StatCard title="Monthly Payroll" value={formatNaira(totalMonthly)} icon={Banknote} />
        <StatCard title="Annual Cost" value={formatNaira(totalMonthly * 12)} icon={Banknote} />
      </div>

      {isLoading && <ListSkeleton rows={6} />}

      {!isLoading && salaries.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Salary Structures ({salaries.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left px-4 py-2 font-medium">Teacher</th>
                    <th className="text-right px-4 py-2 font-medium">Basic</th>
                    <th className="text-right px-4 py-2 font-medium hidden md:table-cell">Housing</th>
                    <th className="text-right px-4 py-2 font-medium hidden md:table-cell">Transport</th>
                    <th className="text-right px-4 py-2 font-medium hidden md:table-cell">Meal</th>
                    <th className="text-right px-4 py-2 font-medium">Gross</th>
                    <th className="px-4 py-2 font-medium w-20" />
                  </tr>
                </thead>
                <tbody>
                  {salaries.map((s) => {
                    const isEditing = editingId === s.teacher_id;
                    return (
                      <tr key={s.id} className="border-b last:border-0 hover:bg-muted/30">
                        <td className="px-4 py-3">
                          <div className="font-medium">{s.teacher_name}</div>
                          <div className="text-[11px] text-muted-foreground">{s.staff_id}</div>
                        </td>
                        {isEditing ? (
                          <>
                            <td className="px-2 py-2">
                              <Input type="number" value={form.basic_salary} onChange={(e) => setForm((f) => ({ ...f, basic_salary: Number(e.target.value) }))} className="h-8 text-right text-sm w-28" />
                            </td>
                            <td className="px-2 py-2 hidden md:table-cell">
                              <Input type="number" value={form.housing_allowance} onChange={(e) => setForm((f) => ({ ...f, housing_allowance: Number(e.target.value) }))} className="h-8 text-right text-sm w-24" />
                            </td>
                            <td className="px-2 py-2 hidden md:table-cell">
                              <Input type="number" value={form.transport_allowance} onChange={(e) => setForm((f) => ({ ...f, transport_allowance: Number(e.target.value) }))} className="h-8 text-right text-sm w-24" />
                            </td>
                            <td className="px-2 py-2 hidden md:table-cell">
                              <Input type="number" value={form.meal_allowance} onChange={(e) => setForm((f) => ({ ...f, meal_allowance: Number(e.target.value) }))} className="h-8 text-right text-sm w-24" />
                            </td>
                            <td className="text-right px-4 py-3 tabular-nums font-semibold">
                              {formatNaira(form.basic_salary + form.housing_allowance + form.transport_allowance + form.meal_allowance)}
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex gap-1">
                                <Button size="sm" onClick={() => handleSave(s.teacher_id)} disabled={saveSalary.isPending}>
                                  <Save className="h-3.5 w-3.5" />
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>✕</Button>
                              </div>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="text-right px-4 py-3 tabular-nums">{formatNaira(s.basic_salary)}</td>
                            <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(s.housing_allowance)}</td>
                            <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(s.transport_allowance)}</td>
                            <td className="text-right px-4 py-3 tabular-nums hidden md:table-cell">{formatNaira(s.meal_allowance)}</td>
                            <td className="text-right px-4 py-3 tabular-nums font-semibold">{formatNaira(s.gross_salary)}</td>
                            <td className="px-4 py-3">
                              <Button variant="ghost" size="sm" onClick={() => startEdit(s)}>
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
