"use client";

import { useState } from "react";
import {
  Calendar, Plus, CheckCircle, Clock, AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira, formatDate } from "@/lib/utils/format";
import { usePaymentPlans, useCreatePaymentPlan } from "@/features/payroll/hooks";
import { useOutstandingFees } from "@/features/finance/hooks";

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  active: "info",
  completed: "success",
  defaulted: "destructive",
  cancelled: "default",
};

const STATUS_TABS = ["all", "active", "completed", "defaulted"];

export default function PaymentPlansPage() {
  const [status, setStatus] = useState("active");
  const { data, isLoading } = usePaymentPlans(status);
  const createPlan = useCreatePaymentPlan();
  const plans = data?.plans || [];

  const [showCreate, setShowCreate] = useState(false);
  const [selectedAccountId, setSelectedAccountId] = useState("");
  const [installments, setInstallments] = useState(3);
  const [startDate, setStartDate] = useState(new Date().toISOString().split("T")[0]);
  const [planNotes, setPlanNotes] = useState("");

  // Get outstanding accounts for dropdown
  const { data: outstandingData } = useOutstandingFees({ aging: "all", page: 1 });
  const outstandingAccounts = (outstandingData?.accounts || []).filter((a) => a.balance > 0);

  async function handleCreatePlan() {
    if (!selectedAccountId || !installments || !startDate) return;
    await createPlan.mutateAsync({
      fee_account_id: selectedAccountId,
      installments,
      start_date: startDate,
      notes: planNotes || undefined,
    });
    setShowCreate(false);
    setSelectedAccountId("");
    setPlanNotes("");
  }

  const activePlans = plans.filter((p) => p.status === "active");
  const totalPlanned = activePlans.reduce((s, p) => s + p.total_amount, 0);
  const paidInstallments = activePlans.reduce((s, p) => s + p.items.filter((i) => i.paid).length, 0);
  const totalInstallments = activePlans.reduce((s, p) => s + p.items.length, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Payment Plans" description="Manage student fee installment plans">
        <Button onClick={() => setShowCreate(!showCreate)}>
          <Plus className="h-4 w-4 mr-2" /> New Plan
        </Button>
      </PageHeader>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Active Plans" value={activePlans.length} icon={Calendar} />
        <StatCard title="Total Planned" value={formatNaira(totalPlanned)} icon={AlertTriangle} />
        <StatCard
          title="Installments Paid"
          value={`${paidInstallments}/${totalInstallments}`}
          icon={CheckCircle}
        />
        <StatCard title="All Plans" value={plans.length} icon={Clock} />
      </div>

      {/* Create form */}
      {showCreate && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Create Payment Plan</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Student Fee Account *</Label>
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="w-full h-10 rounded-md border bg-background px-3 text-sm"
              >
                <option value="">Select student with outstanding balance...</option>
                {outstandingAccounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.students ? `${a.students.first_name} ${a.students.last_name}` : "Unknown"} — {formatNaira(a.balance)} outstanding
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Number of Installments *</Label>
                <select
                  value={installments}
                  onChange={(e) => setInstallments(Number(e.target.value))}
                  className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                >
                  {[2, 3, 4, 5, 6].map((n) => (
                    <option key={n} value={n}>{n} installments (monthly)</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>Start Date *</Label>
                <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <textarea
                value={planNotes}
                onChange={(e) => setPlanNotes(e.target.value)}
                placeholder="Any special arrangements or notes..."
                rows={2}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleCreatePlan} disabled={!selectedAccountId || createPlan.isPending}>
                {createPlan.isPending ? "Creating..." : "Create Plan"}
              </Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Status tabs */}
      <div className="flex rounded-lg border overflow-hidden text-sm w-fit">
        {STATUS_TABS.map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={`px-3 py-1.5 capitalize transition-colors ${
              status === s ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
            } ${s !== "all" ? "border-l" : ""}`}
          >
            {s}
          </button>
        ))}
      </div>

      {isLoading && <ListSkeleton rows={5} />}

      {!isLoading && plans.length === 0 && (
        <EmptyState icon={Calendar} title="No payment plans" description="No plans match this filter." />
      )}

      {!isLoading && plans.length > 0 && (
        <div className="space-y-4">
          {plans.map((plan) => {
            const paidCount = plan.items.filter((i) => i.paid).length;
            const progress = plan.items.length > 0 ? Math.round((paidCount / plan.items.length) * 100) : 0;

            return (
              <Card key={plan.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="font-semibold text-sm">{plan.student_name}</h3>
                        <span className="text-xs text-muted-foreground">{plan.admission_number}</span>
                        <Badge variant={STATUS_VARIANT[plan.status] || "default"} className="text-[10px] capitalize">
                          {plan.status}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {plan.fee_name} · {plan.class_name} · {plan.installments} installments
                      </div>
                      {plan.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{plan.notes}</p>}
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-sm tabular-nums">{formatNaira(plan.total_amount)}</p>
                      <p className="text-[11px] text-muted-foreground">{formatNaira(plan.amount_per_installment)}/mo</p>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="mb-3">
                    <div className="flex justify-between text-[11px] text-muted-foreground mb-1">
                      <span>{paidCount} of {plan.items.length} paid</span>
                      <span>{progress}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-success rounded-full transition-all" style={{ width: `${progress}%` }} />
                    </div>
                  </div>

                  {/* Installments */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {plan.items.map((item) => {
                      const isOverdue = !item.paid && new Date(item.due_date) < new Date();
                      return (
                        <div
                          key={item.id}
                          className={`flex items-center justify-between p-2 rounded-md border text-xs ${
                            item.paid
                              ? "bg-success/5 border-success/30"
                              : isOverdue
                              ? "bg-destructive/5 border-destructive/30"
                              : "bg-card border-muted"
                          }`}
                        >
                          <div>
                            <span className="font-medium">#{item.number}</span>
                            <span className="text-muted-foreground ml-1.5">{formatDate(item.due_date)}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="tabular-nums font-medium">{formatNaira(item.amount)}</span>
                            {item.paid ? (
                              <CheckCircle className="h-3.5 w-3.5 text-success" />
                            ) : isOverdue ? (
                              <AlertTriangle className="h-3.5 w-3.5 text-destructive" />
                            ) : (
                              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
