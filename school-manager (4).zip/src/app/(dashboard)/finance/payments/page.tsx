"use client";

import { useState } from "react";
import { Receipt, ChevronLeft, ChevronRight, Filter } from "lucide-react";
import { useFinancePayments } from "@/features/finance/hooks";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { PageHeader } from "@/components/shared/page-header";
import { formatNaira, formatDateTime, getInitials } from "@/lib/utils/format";

const STATUS_VARIANT: Record<string, "default" | "success" | "destructive" | "warning" | "outline"> = {
  success: "success",
  pending: "warning",
  failed: "destructive",
  refunded: "outline",
};

const METHOD_LABELS: Record<string, string> = {
  card: "Card",
  bank_transfer: "Bank Transfer",
  ussd: "USSD",
  cash: "Cash",
};

export default function FinancePaymentsPage() {
  const [statusFilter, setStatusFilter] = useState("");
  const [methodFilter, setMethodFilter] = useState("");
  const [page, setPage] = useState(1);

  const { data, isLoading } = useFinancePayments({
    status: statusFilter || undefined,
    method: methodFilter || undefined,
    page,
  });

  const payments = data?.payments || [];
  const pagination = data?.pagination;

  // Compute summary from current data
  const successPayments = payments.filter((p) => p.status === "success");
  const totalSuccess = successPayments.reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Payment Transactions"
        description={`${pagination?.total ?? 0} transactions found`}
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[160px]">
            <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="success">Successful</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>

        <Select value={methodFilter} onValueChange={(v) => { setMethodFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="All Methods" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Methods</SelectItem>
            <SelectItem value="card">Card</SelectItem>
            <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
            <SelectItem value="ussd">USSD</SelectItem>
            <SelectItem value="cash">Cash</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Payments Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : payments.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Receipt className="h-10 w-10 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No payment transactions found.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead className="hidden sm:table-cell">Method</TableHead>
                  <TableHead className="hidden md:table-cell">Reference</TableHead>
                  <TableHead className="hidden lg:table-cell">Receipt</TableHead>
                  <TableHead className="hidden sm:table-cell">Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((payment) => {
                  const account = payment.student_fee_accounts;
                  const student = account?.students as Record<string, unknown> | null;
                  const cls = (student?.classes as Record<string, string>) ?? null;
                  const feeName = (account?.fee_structures as Record<string, string>)?.name;

                  return (
                    <TableRow key={payment.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                              {student
                                ? getInitials(student.first_name as string, student.last_name as string)
                                : "?"}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">
                              {student
                                ? `${student.first_name} ${student.last_name}`
                                : "—"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {feeName || cls?.name || ""}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-sm">
                        {formatNaira(payment.amount)}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-sm">
                        {METHOD_LABELS[payment.payment_method] || payment.payment_method}
                      </TableCell>
                      <TableCell className="hidden md:table-cell font-mono text-xs text-muted-foreground">
                        {payment.payment_reference}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell font-mono text-xs">
                        {payment.receipt_number || "—"}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-xs text-muted-foreground">
                        {formatDateTime(payment.created_at)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={STATUS_VARIANT[payment.status] || "outline"}
                          className="text-xs capitalize"
                        >
                          {payment.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {pagination && pagination.total_pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {pagination.total_pages} ({pagination.total} transactions)
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" disabled={page >= pagination.total_pages} onClick={() => setPage(page + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
