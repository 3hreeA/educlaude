"use client";

import { useState } from "react";
import { AlertCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { useOutstandingFees } from "@/features/finance/hooks";
import { useAdminClasses } from "@/features/admin/hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { PageHeader } from "@/components/shared/page-header";
import { formatNaira, formatDate, getInitials } from "@/lib/utils/format";

export default function OutstandingFeesPage() {
  const [classFilter, setClassFilter] = useState("");
  const [agingFilter, setAgingFilter] = useState("");
  const [page, setPage] = useState(1);
  const { data: classes } = useAdminClasses();
  const { data, isLoading } = useOutstandingFees({
    class_id: classFilter || undefined,
    aging: agingFilter || undefined,
    page,
  });

  const accounts = data?.accounts || [];
  const summary = data?.summary;
  const pagination = data?.pagination;

  const statusColor = (status: string) => {
    if (status === "overdue") return "destructive";
    if (status === "partial") return "secondary";
    return "outline";
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Outstanding Fees" description="Track unpaid and overdue fee accounts" />

      {/* Aging Summary */}
      {summary && (
        <div className="grid gap-3 sm:grid-cols-4">
          {[
            { label: "Current", value: summary.current, color: "text-emerald-600" },
            { label: "30 Days", value: summary.days_30, color: "text-amber-600" },
            { label: "60 Days", value: summary.days_60, color: "text-orange-600" },
            { label: "90+ Days", value: summary.days_90_plus, color: "text-rose-600" },
          ].map((item) => (
            <Card key={item.label}>
              <CardContent className="pt-4 pb-3">
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className={`text-lg font-bold ${item.color}`}>{formatNaira(item.value)}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3">
        <Select value={classFilter} onValueChange={(v) => { setClassFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="All Classes" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Classes</SelectItem>
            {(classes || []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={agingFilter} onValueChange={(v) => { setAgingFilter(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="All Ages" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Ages</SelectItem>
            <SelectItem value="30">30+ days overdue</SelectItem>
            <SelectItem value="60">60+ days overdue</SelectItem>
            <SelectItem value="90">90+ days overdue</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Outstanding Accounts Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : accounts.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No outstanding fees found.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead className="hidden sm:table-cell">Class</TableHead>
                  <TableHead>Total Due</TableHead>
                  <TableHead className="hidden md:table-cell">Paid</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead className="hidden lg:table-cell">Due Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts.map((acc) => {
                  const student = acc.students as Record<string, unknown> | null;
                  const cls = (student?.classes as Record<string, string>) ?? null;
                  return (
                    <TableRow key={acc.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-7 w-7">
                            <AvatarFallback className="text-[10px] bg-primary/10 text-primary">
                              {student ? getInitials(student.first_name as string, student.last_name as string) : "?"}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{student ? `${student.last_name}, ${student.first_name}` : "—"}</p>
                            <p className="text-xs text-muted-foreground sm:hidden">{cls?.name}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Badge variant="outline" className="text-xs">{cls?.name}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">{formatNaira(acc.total_amount)}</TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">{formatNaira(acc.amount_paid)}</TableCell>
                      <TableCell className="text-sm font-medium text-rose-600">{formatNaira(acc.balance)}</TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{formatDate(acc.due_date)}</TableCell>
                      <TableCell>
                        <Badge variant={statusColor(acc.status) as "default" | "secondary" | "destructive" | "outline"} className="text-xs capitalize">
                          {acc.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {pagination && pagination.total_pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {pagination.total_pages} ({pagination.total} accounts)
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" disabled={page >= pagination.total_pages} onClick={() => setPage(page + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
