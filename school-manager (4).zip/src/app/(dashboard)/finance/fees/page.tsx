"use client";

import { useState } from "react";
import { Plus, Loader2, Users, Calendar, CheckCircle2 } from "lucide-react";
import {
  useFeeTypes, useCreateFeeType, useFeeStructures,
  useCreateFeeStructure, useAssignFeeAccounts,
} from "@/features/finance/hooks";
import { useAdminClasses } from "@/features/admin/hooks";
import { useCurrentTerm } from "@/features/terms/hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/shared/page-header";
import { formatNaira, formatDate } from "@/lib/utils/format";

export default function FeeSetupPage() {
  const { data: feeTypes, isLoading: typesLoading } = useFeeTypes();
  const { data: structures, isLoading: structLoading } = useFeeStructures();
  const { data: classes } = useAdminClasses();
  const { data: currentTerm } = useCurrentTerm();
  const createTypeMutation = useCreateFeeType();
  const createStructMutation = useCreateFeeStructure();
  const assignMutation = useAssignFeeAccounts();

  const [showAddType, setShowAddType] = useState(false);
  const [showAddStruct, setShowAddStruct] = useState(false);
  const [newType, setNewType] = useState({ name: "", description: "" });
  const [newStruct, setNewStruct] = useState({
    name: "", class_id: "", due_date: "", items: [] as { fee_type_id: string; amount: string }[],
  });
  const [error, setError] = useState("");
  const [assignMsg, setAssignMsg] = useState("");

  const handleCreateType = async () => {
    setError("");
    try {
      await createTypeMutation.mutateAsync({ name: newType.name, description: newType.description });
      setShowAddType(false);
      setNewType({ name: "", description: "" });
    } catch (err: unknown) { setError((err as Error).message); }
  };

  const handleCreateStruct = async () => {
    setError("");
    if (!currentTerm?.id) { setError("No active term"); return; }
    if (!newStruct.items.length) { setError("Add at least one fee item"); return; }
    try {
      await createStructMutation.mutateAsync({
        name: newStruct.name,
        class_id: newStruct.class_id || undefined,
        term_id: currentTerm.id,
        due_date: newStruct.due_date,
        items: newStruct.items.map((i) => ({ fee_type_id: i.fee_type_id, amount: parseFloat(i.amount) || 0 })),
      });
      setShowAddStruct(false);
      setNewStruct({ name: "", class_id: "", due_date: "", items: [] });
    } catch (err: unknown) { setError((err as Error).message); }
  };

  const handleAssign = async (structureId: string) => {
    setAssignMsg("");
    try {
      const result = await assignMutation.mutateAsync({ fee_structure_id: structureId }) as { assigned: number; message: string };
      setAssignMsg(result.message || `Assigned to ${result.assigned} students`);
    } catch (err: unknown) { setAssignMsg((err as Error).message); }
  };

  const addItemRow = () => {
    setNewStruct((prev) => ({ ...prev, items: [...prev.items, { fee_type_id: "", amount: "" }] }));
  };

  const updateItem = (idx: number, field: "fee_type_id" | "amount", value: string) => {
    setNewStruct((prev) => {
      const items = [...prev.items];
      items[idx] = { ...items[idx], [field]: value };
      return { ...prev, items };
    });
  };

  const removeItem = (idx: number) => {
    setNewStruct((prev) => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Fee Setup" description="Configure fee types and fee structures" />

      <Tabs defaultValue="structures">
        <TabsList>
          <TabsTrigger value="structures">Fee Structures</TabsTrigger>
          <TabsTrigger value="types">Fee Types</TabsTrigger>
        </TabsList>

        {/* Fee Structures Tab */}
        <TabsContent value="structures" className="space-y-4">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setShowAddStruct(true)}>
              <Plus className="h-4 w-4 mr-2" />
              New Fee Structure
            </Button>
          </div>

          {assignMsg && (
            <div className="rounded-md bg-emerald-50 border border-emerald-200 p-3 text-sm text-emerald-700 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" />
              {assignMsg}
            </div>
          )}

          {structLoading ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
          ) : !structures?.length ? (
            <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">No fee structures yet.</CardContent></Card>
          ) : (
            <div className="space-y-4">
              {structures.map((s) => (
                <Card key={s.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-base">{s.name}</CardTitle>
                        <div className="flex gap-2 mt-1">
                          {s.terms && <Badge variant="outline" className="text-xs">{s.terms.name}</Badge>}
                          {s.classes && <Badge variant="secondary" className="text-xs">{s.classes.name}</Badge>}
                        </div>
                      </div>
                      <span className="text-lg font-bold">{formatNaira(s.total_amount)}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />Due: {formatDate(s.due_date)}</span>
                      <span className="flex items-center gap-1"><Users className="h-3 w-3" />{s.assigned_students} students assigned</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {s.fee_structure_items.map((item) => (
                        <Badge key={item.id} variant="outline" className="text-xs">
                          {item.fee_types?.name}: {formatNaira(item.amount)}
                        </Badge>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleAssign(s.id)}
                      disabled={assignMutation.isPending}
                    >
                      {assignMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
                      Assign to All Students
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Fee Types Tab */}
        <TabsContent value="types" className="space-y-4">
          <div className="flex justify-end">
            <Button size="sm" onClick={() => setShowAddType(true)}>
              <Plus className="h-4 w-4 mr-2" />
              New Fee Type
            </Button>
          </div>
          {typesLoading ? (
            <Skeleton className="h-48" />
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Recurring</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(feeTypes || []).map((ft) => (
                      <TableRow key={ft.id}>
                        <TableCell className="font-medium">{ft.name}</TableCell>
                        <TableCell className="text-muted-foreground text-sm">{ft.description || "—"}</TableCell>
                        <TableCell><Badge variant={ft.is_recurring ? "default" : "secondary"} className="text-xs">{ft.is_recurring ? "Yes" : "No"}</Badge></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Add Fee Type Dialog */}
      <Dialog open={showAddType} onOpenChange={setShowAddType}>
        <DialogContent>
          <DialogHeader><DialogTitle>New Fee Type</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Name *</Label><Input value={newType.name} onChange={(e) => setNewType({ ...newType, name: e.target.value })} placeholder="e.g. Transport Fee" /></div>
            <div className="space-y-2"><Label>Description</Label><Input value={newType.description} onChange={(e) => setNewType({ ...newType, description: e.target.value })} placeholder="Optional description" /></div>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddType(false)}>Cancel</Button>
            <Button onClick={handleCreateType} disabled={!newType.name || createTypeMutation.isPending}>
              {createTypeMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Fee Structure Dialog */}
      <Dialog open={showAddStruct} onOpenChange={setShowAddStruct}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>New Fee Structure</DialogTitle></DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="space-y-2"><Label>Structure Name *</Label><Input value={newStruct.name} onChange={(e) => setNewStruct({ ...newStruct, name: e.target.value })} placeholder="e.g. Primary 5 - Second Term" /></div>
            <div className="grid gap-4 grid-cols-2">
              <div className="space-y-2">
                <Label>Class</Label>
                <Select value={newStruct.class_id} onValueChange={(v) => setNewStruct({ ...newStruct, class_id: v })}>
                  <SelectTrigger><SelectValue placeholder="All classes" /></SelectTrigger>
                  <SelectContent>
                    {(classes || []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Due Date *</Label><Input type="date" value={newStruct.due_date} onChange={(e) => setNewStruct({ ...newStruct, due_date: e.target.value })} /></div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label>Fee Items</Label>
                <Button size="sm" variant="outline" onClick={addItemRow}><Plus className="h-3 w-3 mr-1" />Add Item</Button>
              </div>
              {newStruct.items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-end">
                  <div className="flex-1">
                    <Select value={item.fee_type_id} onValueChange={(v) => updateItem(idx, "fee_type_id", v)}>
                      <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select type" /></SelectTrigger>
                      <SelectContent>
                        {(feeTypes || []).map((ft) => <SelectItem key={ft.id} value={ft.id}>{ft.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <Input className="w-28 h-9 text-xs" type="number" placeholder="Amount (₦)" value={item.amount} onChange={(e) => updateItem(idx, "amount", e.target.value)} />
                  <Button size="sm" variant="ghost" className="h-9 text-destructive" onClick={() => removeItem(idx)}>✕</Button>
                </div>
              ))}
              {newStruct.items.length > 0 && (
                <p className="text-sm font-medium text-right">
                  Total: {formatNaira(newStruct.items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0))}
                </p>
              )}
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddStruct(false)}>Cancel</Button>
            <Button onClick={handleCreateStruct} disabled={!newStruct.name || !newStruct.due_date || !newStruct.items.length || createStructMutation.isPending}>
              {createStructMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Create Structure
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
