"use client";

import { useState } from "react";
import {
  BarChart3, Download, FileSpreadsheet, FileText,
  Banknote, AlertCircle, RefreshCcw, TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ListSkeleton } from "@/components/shared/skeletons";
import { useReport, type ReportFilters, type ReportType } from "@/features/reports/hooks";
import { exportToExcel, exportToPdf, REPORT_COLUMNS, REPORT_TITLES } from "@/features/reports/export";
import { useAdminClasses } from "@/features/admin/hooks";
import { formatNaira } from "@/lib/utils/format";

const FINANCE_REPORTS: { value: ReportType; label: string; icon: typeof BarChart3; description: string }[] = [
  { value: "fee_collection", label: "Fee Collection", icon: Banknote, description: "Payments received — filter by date range and class" },
  { value: "outstanding_fees", label: "Outstanding Fees", icon: AlertCircle, description: "Unpaid fees with aging buckets" },
];

export default function FinanceReportsPage() {
  const [selectedType, setSelectedType] = useState<ReportType>("fee_collection");
  const [classId, setClassId] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [activeFilters, setActiveFilters] = useState<ReportFilters | null>(null);

  const { data: classes } = useAdminClasses();
  const { data: report, isLoading, error } = useReport(activeFilters);

  function handleGenerate() {
    const filters: ReportFilters = { type: selectedType };
    if (classId) filters.class_id = classId;
    if (dateFrom) filters.date_from = dateFrom;
    if (dateTo) filters.date_to = dateTo;
    setActiveFilters(filters);
  }

  function handleExportExcel() {
    if (!report) return;
    const columns = REPORT_COLUMNS[selectedType] || [];
    exportToExcel(report, columns, `${selectedType}_report_${Date.now()}`);
  }

  function handleExportPdf() {
    if (!report) return;
    const columns = REPORT_COLUMNS[selectedType] || [];
    const title = REPORT_TITLES[selectedType] || "Financial Report";
    exportToPdf(report, columns, `${selectedType}_report_${Date.now()}`, title);
  }

  const columns = REPORT_COLUMNS[selectedType] || [];

  // Extract aging buckets for outstanding fees summary
  const agingBuckets = report?.report_type === "outstanding_fees"
    ? (report.summary.aging_buckets as Record<string, { count: number; total: number }>) || {}
    : null;

  // Extract method breakdown for fee collection
  const methodBreakdown = report?.report_type === "fee_collection"
    ? (report.summary.method_breakdown as Record<string, { count: number; total: number }>) || {}
    : null;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Financial Reports"
        description="Generate fee collection and outstanding balance reports"
      />

      {/* Report Type Selection */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {FINANCE_REPORTS.map((rt) => {
          const Icon = rt.icon;
          const isSelected = selectedType === rt.value;
          return (
            <button
              key={rt.value}
              onClick={() => { setSelectedType(rt.value); setActiveFilters(null); }}
              className={`flex items-start gap-3 p-4 rounded-lg border-2 text-left transition-all ${
                isSelected
                  ? "border-primary bg-primary/5"
                  : "border-gray-200 hover:border-gray-300"
              }`}
            >
              <Icon className={`h-5 w-5 mt-0.5 shrink-0 ${isSelected ? "text-primary" : "text-gray-400"}`} />
              <div>
                <p className="text-sm font-medium">{rt.label}</p>
                <p className="text-xs text-muted-foreground">{rt.description}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="class_filter">Class</Label>
              <select
                id="class_filter"
                value={classId}
                onChange={(e) => setClassId(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="">All Classes</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            {selectedType === "fee_collection" && (
              <>
                <div>
                  <Label htmlFor="date_from">From Date</Label>
                  <Input id="date_from" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="date_to">To Date</Label>
                  <Input id="date_to" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                </div>
              </>
            )}

            <div className="flex items-end">
              <Button onClick={handleGenerate} className="w-full">
                <RefreshCcw className="h-4 w-4 mr-2" />
                Generate
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {isLoading && <ListSkeleton rows={8} />}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">Failed to generate report.</p>
        </div>
      )}

      {report && !isLoading && (
        <>
          {/* Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {Object.entries(report.summary)
              .filter(([, v]) => typeof v !== "object")
              .map(([key, value]) => {
                const label = key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
                const formatted = typeof value === "number" && (key.includes("amount") || key.includes("collected") || key.includes("outstanding"))
                  ? formatNaira(value)
                  : String(value);
                return <StatCard key={key} title={label} value={formatted} />;
              })}
          </div>

          {/* Aging Buckets for outstanding fees */}
          {agingBuckets && Object.keys(agingBuckets).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Aging Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {Object.entries(agingBuckets).map(([bucket, stats]) => (
                    <div key={bucket} className="rounded-lg border p-3 text-center">
                      <p className="text-xs text-muted-foreground mb-1">{bucket}</p>
                      <p className="text-lg font-bold">{stats.count}</p>
                      <p className="text-xs font-medium text-primary">{formatNaira(stats.total)}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Method Breakdown for fee collection */}
          {methodBreakdown && Object.keys(methodBreakdown).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Payment Method Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {Object.entries(methodBreakdown).map(([method, stats]) => (
                    <div key={method} className="rounded-lg border p-3 text-center">
                      <p className="text-xs text-muted-foreground mb-1 capitalize">{method.replace(/_/g, " ")}</p>
                      <p className="text-lg font-bold">{stats.count}</p>
                      <p className="text-xs font-medium text-primary">{formatNaira(stats.total)}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Export Buttons */}
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleExportExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
            <Button variant="outline" onClick={handleExportPdf}>
              <FileText className="h-4 w-4 mr-2" />
              Export PDF
            </Button>
            <span className="text-sm text-muted-foreground">
              {report.data.length} records
            </span>
          </div>

          {/* Data Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      {columns.map((col) => (
                        <th key={col.key} className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                          {col.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {report.data.slice(0, 100).map((row, i) => (
                      <tr key={i} className="border-b last:border-0 hover:bg-muted/30">
                        {columns.map((col) => {
                          const val = row[col.key];
                          let display: string;
                          if (val === null || val === undefined) display = "—";
                          else if (col.format === "currency") display = formatNaira(Number(val));
                          else if (col.format === "percentage") display = `${val}%`;
                          else if (col.format === "date" && typeof val === "string")
                            display = new Date(val).toLocaleDateString("en-NG");
                          else display = String(val);

                          return (
                            <td key={col.key} className="px-4 py-3 whitespace-nowrap">
                              {col.key === "status" ? (
                                <Badge variant={
                                  val === "overdue" ? "destructive" :
                                  val === "partial" ? "warning" :
                                  val === "paid" ? "success" : "default"
                                } className="text-[10px] capitalize">
                                  {String(val)}
                                </Badge>
                              ) : col.key === "aging_bucket" ? (
                                <Badge variant={
                                  val === "90+ Days" ? "destructive" :
                                  val === "61-90 Days" ? "destructive" :
                                  val === "31-60 Days" ? "warning" :
                                  val === "1-30 Days" ? "info" : "default"
                                } className="text-[10px]">
                                  {String(val)}
                                </Badge>
                              ) : (
                                display
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                    {report.data.length === 0 && (
                      <tr>
                        <td colSpan={columns.length} className="px-4 py-8 text-center text-muted-foreground">
                          No data found for this report.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
                {report.data.length > 100 && (
                  <div className="px-4 py-3 text-xs text-muted-foreground border-t bg-muted/20">
                    Showing 100 of {report.data.length} records. Export to see all data.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
