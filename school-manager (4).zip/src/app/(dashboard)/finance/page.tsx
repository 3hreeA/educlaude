"use client";

import Link from "next/link";
import { Banknote, CreditCard, TrendingUp, AlertCircle, Settings, FileText, Receipt } from "lucide-react";
import { useFinanceStats } from "@/features/finance/hooks";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { formatNaira } from "@/lib/utils/format";

export default function FinanceDashboard() {
  const { data: stats, isLoading } = useFinanceStats();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Finance Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Fee management, payments, and financial reporting
        </p>
      </div>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-[120px] rounded-xl" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              title="Total Revenue"
              value={formatNaira(stats?.total_revenue ?? 0)}
              description="All payments received"
              icon={Banknote}
              iconColor="text-emerald-600"
            />
            <StatCard
              title="Outstanding Fees"
              value={formatNaira(stats?.total_outstanding ?? 0)}
              description={`${stats?.overdue_count ?? 0} overdue accounts`}
              icon={CreditCard}
              iconColor="text-amber-600"
            />
            <StatCard
              title="This Month"
              value={formatNaira(stats?.this_month_revenue ?? 0)}
              description="Collections this month"
              icon={TrendingUp}
              iconColor="text-primary"
            />
            <StatCard
              title="Overdue"
              value={stats?.overdue_count ?? 0}
              description="Accounts past due date"
              icon={AlertCircle}
              iconColor="text-rose-600"
            />
          </div>

          {/* Collection Rate */}
          {stats && stats.total_accounts > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Collection Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <Progress value={stats.collection_rate} className="flex-1 h-3" />
                  <span className="text-lg font-bold">{stats.collection_rate}%</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {stats.paid_accounts} of {stats.total_accounts} accounts fully paid
                </p>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Quick Actions */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Link href="/finance/fees">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Settings className="h-4 w-4 text-primary" />
                Fee Setup
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Configure fee types and fee structures</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/finance/fees/outstanding">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-amber-600" />
                Outstanding Fees
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Track and manage unpaid fee accounts</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/finance/payment-plans">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <FileText className="h-4 w-4 text-blue-600" />
                Payment Plans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Manage installment payment arrangements</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/finance/payments">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Receipt className="h-4 w-4 text-emerald-600" />
                Payment Transactions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">View all payment records and receipts</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/finance/reconciliation">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <CreditCard className="h-4 w-4 text-violet-600" />
                Reconciliation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Match payments with gateway transactions</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/finance/payroll">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Banknote className="h-4 w-4 text-orange-600" />
                Payroll
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Process staff salaries with PAYE and pension</p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
