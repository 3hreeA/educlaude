"use client";

import { useState } from "react";
import {
  CheckCircle, XCircle, Clock, ChevronLeft, ChevronRight,
  CreditCard, Banknote, AlertTriangle, Link2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ListSkeleton } from "@/components/shared/skeletons";
import { EmptyState } from "@/components/shared/empty-state";
import { formatNaira, formatDateTime } from "@/lib/utils/format";
import { useReconciliation, useReconcileTransaction } from "@/features/payroll/hooks";

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  success: "success",
  pending: "warning",
  failed: "destructive",
  refunded: "default",
};

const METHOD_LABELS: Record<string, string> = {
  card: "Card",
  bank_transfer: "Bank Transfer",
  ussd: "USSD",
  cash: "Cash",
};

export default function ReconciliationPage() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const { data, isLoading } = useReconciliation(date);
  const reconcile = useReconcileTransaction();

  const transactions = data?.transactions || [];
  const summary = data?.summary;

  const [reconcileId, setReconcileId] = useState<string | null>(null);
  const [gatewayRef, setGatewayRef] = useState("");
  const [notes, setNotes] = useState("");

  function changeDate(delta: number) {
    const d = new Date(date);
    d.setDate(d.getDate() + delta);
    setDate(d.toISOString().split("T")[0]);
  }

  async function handleReconcile(txnId: string) {
    await reconcile.mutateAsync({
      transaction_id: txnId,
      gateway_reference: gatewayRef || undefined,
      notes: notes || undefined,
    });
    setReconcileId(null);
    setGatewayRef("");
    setNotes("");
  }

  const isToday = date === new Date().toISOString().split("T")[0];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Reconciliation" description="Match payments with gateway transactions" />

      {/* Date picker */}
      <div className="flex items-center gap-3">
        <Button variant="outline" size="icon" onClick={() => changeDate(-1)}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        />
        <Button variant="outline" size="icon" onClick={() => changeDate(1)} disabled={isToday}>
          <ChevronRight className="h-4 w-4" />
        </Button>
        {isToday && <Badge variant="info" className="text-[10px]">Today</Badge>}
      </div>

      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <StatCard title="Total Txns" value={summary.total_transactions} icon={CreditCard} />
          <StatCard title="Successful" value={formatNaira(summary.successful_amount)} icon={CheckCircle} />
          <StatCard title="Pending" value={summary.pending_count} icon={Clock} />
          <StatCard title="Reconciled" value={summary.reconciled} icon={Link2} />
          <StatCard title="Unreconciled" value={summary.unreconciled} icon={AlertTriangle} />
        </div>
      )}

      {/* Method breakdown */}
      {summary && Object.keys(summary.method_breakdown).length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Payment Method Breakdown</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(summary.method_breakdown).map(([method, info]) => (
                <div key={method} className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground capitalize">{METHOD_LABELS[method] || method}</p>
                  <p className="text-lg font-bold tabular-nums">{formatNaira(info.amount)}</p>
                  <p className="text-xs text-muted-foreground">{info.count} transaction{info.count !== 1 ? "s" : ""}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading && <ListSkeleton rows={5} />}

      {!isLoading && transactions.length === 0 && (
        <EmptyState icon={CreditCard} title="No transactions" description="No payment transactions found for this date." />
      )}

      {!isLoading && transactions.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Transactions ({transactions.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {transactions.map((txn) => (
                <div key={txn.id} className="px-4 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="font-semibold text-sm">{txn.student_name}</span>
                        <span className="text-xs text-muted-foreground">{txn.admission_number}</span>
                        <Badge variant={STATUS_VARIANT[txn.status] || "default"} className="text-[10px] capitalize">
                          {txn.status}
                        </Badge>
                        {txn.reconciled && <Badge variant="success" className="text-[10px]">Reconciled</Badge>}
                      </div>
                      <div className="flex gap-3 text-[11px] text-muted-foreground flex-wrap">
                        <span>{txn.fee_name}</span>
                        <span className="capitalize">{METHOD_LABELS[txn.payment_method] || txn.payment_method}</span>
                        <span>Ref: {txn.payment_reference}</span>
                        {txn.gateway_reference && <span>GW: {txn.gateway_reference}</span>}
                        <span>{formatDateTime(txn.created_at)}</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-semibold text-sm tabular-nums">{formatNaira(txn.amount)}</p>
                      {txn.status === "success" && !txn.reconciled && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-1 text-[10px] h-7"
                          onClick={() => setReconcileId(reconcileId === txn.id ? null : txn.id)}
                        >
                          <Link2 className="h-3 w-3 mr-1" /> Reconcile
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Reconcile form */}
                  {reconcileId === txn.id && (
                    <div className="mt-3 p-3 bg-muted/30 rounded-md space-y-2">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <Input
                          placeholder="Gateway reference..."
                          value={gatewayRef}
                          onChange={(e) => setGatewayRef(e.target.value)}
                          className="h-8 text-sm"
                        />
                        <Input
                          placeholder="Notes..."
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          className="h-8 text-sm"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleReconcile(txn.id)} disabled={reconcile.isPending}>
                          Confirm
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setReconcileId(null)}>Cancel</Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
