"use client";

import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { CheckCircle2, XCircle, Loader2, Receipt, ArrowRight, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useVerifyPayment } from "@/features/finance/hooks";
import { formatNaira } from "@/lib/utils/format";

type VerifyStatus = "verifying" | "success" | "failed" | "error";

export default function VerifyPaymentPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const reference = searchParams.get("reference");
  const verifyMutation = useVerifyPayment();

  const [status, setStatus] = useState<VerifyStatus>("verifying");
  const [result, setResult] = useState<{
    receipt_number?: string | null;
    amount?: number;
    message?: string;
  }>({});

  useEffect(() => {
    if (!reference) {
      setStatus("error");
      return;
    }

    const verify = async () => {
      try {
        const res = await verifyMutation.mutateAsync({ reference });
        if (res.status === "success") {
          setStatus("success");
          setResult({
            receipt_number: res.receipt_number,
            amount: res.amount,
            message: "Payment verified successfully",
          });
        } else {
          setStatus("failed");
          setResult({ message: "Payment could not be verified" });
        }
      } catch (err: unknown) {
        setStatus("error");
        setResult({ message: (err as Error).message || "Verification failed" });
      }
    };

    verify();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reference]);

  return (
    <div className="max-w-md mx-auto py-12 animate-fade-in">
      <Card>
        <CardContent className="pt-8 pb-6 text-center space-y-4">
          {status === "verifying" && (
            <>
              <Loader2 className="h-12 w-12 mx-auto animate-spin text-primary" />
              <h2 className="text-lg font-bold">Verifying Payment...</h2>
              <p className="text-sm text-muted-foreground">
                Please wait while we confirm your payment with Paystack.
              </p>
            </>
          )}

          {status === "success" && (
            <>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
                <CheckCircle2 className="h-8 w-8 text-emerald-600" />
              </div>
              <h2 className="text-lg font-bold text-emerald-700">Payment Successful!</h2>
              {result.amount && (
                <p className="text-2xl font-bold">{formatNaira(result.amount)}</p>
              )}
              {result.receipt_number && (
                <p className="text-sm text-muted-foreground">
                  Receipt: <span className="font-mono font-medium">{result.receipt_number}</span>
                </p>
              )}
              <p className="text-sm text-muted-foreground">
                Your fee account has been updated. A receipt has been generated.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                {result.receipt_number && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push(`/parent/fees/receipt?ref=${reference}`)}
                  >
                    <Receipt className="h-4 w-4 mr-2" />
                    View Receipt
                  </Button>
                )}
                <Button size="sm" onClick={() => router.push("/parent/fees")}>
                  Back to Fees
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </>
          )}

          {status === "failed" && (
            <>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-red-100">
                <XCircle className="h-8 w-8 text-red-600" />
              </div>
              <h2 className="text-lg font-bold text-red-700">Payment Failed</h2>
              <p className="text-sm text-muted-foreground">
                {result.message || "The payment could not be verified. No charges have been applied."}
              </p>
              <div className="flex gap-3 justify-center pt-2">
                <Button variant="outline" size="sm" onClick={() => router.push("/parent/fees")}>
                  Back to Fees
                </Button>
                <Button size="sm" onClick={() => { setStatus("verifying"); window.location.reload(); }}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Retry
                </Button>
              </div>
            </>
          )}

          {status === "error" && (
            <>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-100">
                <XCircle className="h-8 w-8 text-amber-600" />
              </div>
              <h2 className="text-lg font-bold">Verification Error</h2>
              <p className="text-sm text-muted-foreground">
                {!reference
                  ? "No payment reference found. Please check the URL."
                  : result.message || "Something went wrong during verification."}
              </p>
              <Button size="sm" onClick={() => router.push("/parent/fees")}>
                Back to Fees
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
