"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Download, Printer, CheckCircle2, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { apiFetch } from "@/lib/utils/api-client";
import { formatNaira, formatDateTime } from "@/lib/utils/format";

interface ReceiptData {
  transaction: {
    id: string;
    amount: number;
    payment_method: string;
    payment_reference: string;
    gateway_reference: string | null;
    status: string;
    receipt_number: string | null;
    created_at: string;
    metadata: Record<string, unknown> | null;
    student_fee_accounts: {
      id: string;
      total_amount: number;
      amount_paid: number;
      balance: number;
      students: {
        id: string;
        first_name: string;
        last_name: string;
        admission_number: string;
        classes: { id: string; name: string } | null;
      } | null;
      fee_structures: {
        id: string;
        name: string;
        terms: { name: string } | null;
        academic_years: { name: string } | null;
      } | null;
    } | null;
  };
  school: {
    name: string;
    address: string;
    phone: string;
    email: string;
    logo_url?: string;
  };
}

const METHOD_LABELS: Record<string, string> = {
  card: "Debit/Credit Card",
  bank_transfer: "Bank Transfer",
  ussd: "USSD",
  cash: "Cash",
};

export default function ReceiptPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const ref = searchParams.get("ref");

  const { data, isLoading, error } = useQuery({
    queryKey: ["receipt", ref],
    queryFn: () => apiFetch<ReceiptData>(`/api/payments/receipt?ref=${ref}`),
    enabled: !!ref,
  });

  const handlePrint = () => window.print();

  if (!ref) {
    return (
      <div className="max-w-md mx-auto py-12 text-center space-y-4">
        <p className="text-muted-foreground text-sm">No payment reference specified.</p>
        <Button size="sm" onClick={() => router.push("/parent/fees")}>Back to Fees</Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-md mx-auto py-8 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-md mx-auto py-12 text-center space-y-4">
        <p className="text-muted-foreground text-sm">Receipt not found.</p>
        <Button size="sm" onClick={() => router.push("/parent/fees")}>Back to Fees</Button>
      </div>
    );
  }

  const { transaction: tx, school } = data;
  const account = tx.student_fee_accounts;
  const student = account?.students;
  const feeStruct = account?.fee_structures;

  return (
    <div className="max-w-md mx-auto space-y-4 animate-fade-in">
      {/* Actions (hidden in print) */}
      <div className="flex items-center justify-between print:hidden">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
        <Button variant="outline" size="sm" onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" /> Print
        </Button>
      </div>

      {/* Receipt Card */}
      <Card className="print:shadow-none print:border-2 print:border-black">
        <CardContent className="pt-6 space-y-5">
          {/* Header */}
          <div className="text-center space-y-1">
            <h1 className="text-lg font-bold">{school.name}</h1>
            {school.address && <p className="text-xs text-muted-foreground">{school.address}</p>}
            {school.phone && <p className="text-xs text-muted-foreground">{school.phone}</p>}
            <Separator className="my-3" />
            <h2 className="text-base font-semibold tracking-wide uppercase">Payment Receipt</h2>
          </div>

          {/* Receipt Details */}
          <div className="space-y-3 text-sm">
            <ReceiptRow label="Receipt No." value={tx.receipt_number || "Pending"} bold />
            <ReceiptRow label="Date" value={formatDateTime(tx.created_at)} />
            <ReceiptRow label="Reference" value={tx.payment_reference} mono />

            <Separator />

            {student && (
              <>
                <ReceiptRow label="Student" value={`${student.first_name} ${student.last_name}`} />
                <ReceiptRow label="Admission No." value={student.admission_number} mono />
                {student.classes && <ReceiptRow label="Class" value={student.classes.name} />}
              </>
            )}

            {feeStruct && (
              <ReceiptRow
                label="Fee"
                value={`${feeStruct.name}${feeStruct.terms ? ` (${feeStruct.terms.name})` : ""}`}
              />
            )}

            <Separator />

            <ReceiptRow label="Payment Method" value={METHOD_LABELS[tx.payment_method] || tx.payment_method} />

            <div className="flex items-center justify-between pt-1">
              <span className="text-muted-foreground">Amount Paid</span>
              <span className="text-xl font-bold">{formatNaira(tx.amount)}</span>
            </div>

            {account && (
              <ReceiptRow
                label="Outstanding Balance"
                value={formatNaira(account.balance)}
                valueColor={account.balance > 0 ? "text-amber-600" : "text-emerald-600"}
              />
            )}

            <Separator />

            <div className="flex items-center justify-center gap-2 pt-2">
              {tx.status === "success" ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                  <Badge variant="success" className="text-xs">Verified</Badge>
                </>
              ) : (
                <Badge variant="warning" className="text-xs capitalize">{tx.status}</Badge>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-[10px] text-muted-foreground pt-3 border-t">
            <p>This is a computer-generated receipt and does not require a signature.</p>
            <p>Generated by School Manager</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ReceiptRow({
  label,
  value,
  bold,
  mono,
  valueColor,
}: {
  label: string;
  value: string;
  bold?: boolean;
  mono?: boolean;
  valueColor?: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-muted-foreground shrink-0">{label}</span>
      <span
        className={`text-right ${bold ? "font-bold" : "font-medium"} ${mono ? "font-mono text-xs" : ""} ${valueColor || ""}`}
      >
        {value}
      </span>
    </div>
  );
}
