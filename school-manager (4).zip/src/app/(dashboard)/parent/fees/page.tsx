"use client";

import Link from "next/link";
import { CreditCard, ArrowRight, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { StatGridSkeleton, ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira } from "@/lib/utils/format";
import { useMyChildren } from "@/features/students/hooks";

export default function ParentFeesPage() {
  const { data: children, isLoading, error } = useMyChildren();

  // Aggregate fee data
  const totalBalance = children?.reduce((sum, c) => sum + c.fee_balance, 0) || 0;
  const childrenWithFees = children?.filter((c) => c.fee_balance > 0) || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Fees & Payments"
        description="Overview of school fees for all your children"
      />

      {isLoading && <StatGridSkeleton count={3} />}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load fee information. Please try again.
          </p>
        </div>
      )}

      {!isLoading && children && children.length === 0 && (
        <EmptyState
          icon={Users}
          title="No children found"
          description="No children are linked to your account."
        />
      )}

      {!isLoading && children && children.length > 0 && (
        <>
          {/* Summary */}
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard
              title="Total Outstanding"
              value={formatNaira(totalBalance)}
              icon={CreditCard}
              description="All children combined"
              iconColor={totalBalance > 0 ? "text-amber-600" : "text-emerald-600"}
            />
            <StatCard
              title="Children"
              value={children.length}
              icon={Users}
              description={`${childrenWithFees.length} with outstanding fees`}
            />
            <StatCard
              title="Status"
              value={totalBalance === 0 ? "All Clear" : "Pending"}
              icon={CreditCard}
              description={
                totalBalance === 0
                  ? "No outstanding fees"
                  : `${formatNaira(totalBalance)} remaining`
              }
              iconColor={totalBalance === 0 ? "text-emerald-600" : "text-amber-600"}
            />
          </div>

          {/* Per-child breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Fee Breakdown by Child</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {children.map((child) => {
                const feeStatus = child.fee_status || "current";
                return (
                  <Link
                    key={child.id}
                    href={`/parent/children/${child.id}/fees`}
                    className="flex items-center justify-between py-3 px-1 border-b last:border-0 hover:bg-muted/50 rounded transition-colors group"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">
                          {child.first_name} {child.last_name}
                        </span>
                        <Badge
                          variant={
                            feeStatus === "paid"
                              ? "success"
                              : feeStatus === "overdue"
                                ? "destructive"
                                : "warning"
                          }
                          className="text-[10px] capitalize"
                        >
                          {feeStatus === "paid" ? "Paid" : feeStatus}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {child.class_name}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {child.fee_balance > 0 ? (
                        <span className="text-sm font-semibold text-amber-600">
                          {formatNaira(child.fee_balance)}
                        </span>
                      ) : (
                        <span className="text-sm text-emerald-600 font-medium">
                          Paid
                        </span>
                      )}
                      <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </Link>
                );
              })}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
