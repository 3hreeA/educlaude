"use client";

import Link from "next/link";
import { Users, CreditCard, Bell, BookOpen, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { StatCard } from "@/components/shared/stat-card";
import { StatGridSkeleton, ListSkeleton } from "@/components/shared/skeletons";
import { ChildCard } from "@/components/features/students/child-card";
import { AnnouncementCard } from "@/components/features/announcements/announcement-card";
import { formatNaira } from "@/lib/utils/format";
import { useMyChildren } from "@/features/students/hooks";
import { useAnnouncements } from "@/features/announcements/hooks";

export default function ParentDashboard() {
  const { data: children, isLoading: loadingChildren } = useMyChildren();
  const { data: announcementsData, isLoading: loadingAnn } = useAnnouncements(1, 3);

  const isLoading = loadingChildren;

  // Compute stats
  const childrenCount = children?.length || 0;
  const totalFees = children?.reduce((sum, c) => sum + c.fee_balance, 0) || 0;
  const avgAttendance =
    children && children.length > 0
      ? Math.round(
          children
            .filter((c) => c.attendance_percentage !== null)
            .reduce((sum, c) => sum + (c.attendance_percentage || 0), 0) /
            Math.max(
              children.filter((c) => c.attendance_percentage !== null).length,
              1
            )
        )
      : null;

  const recentAnnouncements = announcementsData?.announcements?.slice(0, 3) || [];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-heading font-bold tracking-tight">
          Welcome back
        </h1>
        <p className="text-muted-foreground mt-1">
          Here&apos;s an overview of your children&apos;s school activities
        </p>
      </div>

      {/* Stats Grid */}
      {isLoading ? (
        <StatGridSkeleton count={4} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link href="/parent/children">
            <StatCard
              title="My Children"
              value={childrenCount}
              icon={Users}
              description="Enrolled students"
            />
          </Link>
          <Link href="/parent/fees">
            <StatCard
              title="Outstanding Fees"
              value={formatNaira(totalFees)}
              icon={CreditCard}
              description={totalFees > 0 ? "Payment required" : "All fees paid"}
              iconColor={totalFees > 0 ? "text-amber-600" : "text-emerald-600"}
            />
          </Link>
          <StatCard
            title="Avg Attendance"
            value={avgAttendance !== null ? `${avgAttendance}%` : "—"}
            icon={BookOpen}
            description="This term"
            iconColor={
              avgAttendance !== null
                ? avgAttendance >= 80
                  ? "text-emerald-600"
                  : "text-amber-600"
                : undefined
            }
          />
          <Link href="/parent/announcements">
            <StatCard
              title="Announcements"
              value={announcementsData?.pagination.total || 0}
              icon={Bell}
              description="Active announcements"
              iconColor="text-blue-600"
            />
          </Link>
        </div>
      )}

      {/* Children Grid */}
      {!isLoading && children && children.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">My Children</h2>
            <Link
              href="/parent/children"
              className="text-sm text-primary font-medium hover:underline inline-flex items-center gap-1"
            >
              View all
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {children.slice(0, 3).map((child) => (
              <ChildCard key={child.id} child={child} />
            ))}
          </div>
        </div>
      )}

      {/* Recent Announcements */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Recent Announcements</h2>
          <Link
            href="/parent/announcements"
            className="text-sm text-primary font-medium hover:underline inline-flex items-center gap-1"
          >
            View all
            <ArrowRight className="h-3 w-3" />
          </Link>
        </div>

        {loadingAnn ? (
          <ListSkeleton rows={3} />
        ) : recentAnnouncements.length > 0 ? (
          <div className="space-y-3">
            {recentAnnouncements.map((announcement) => (
              <AnnouncementCard
                key={announcement.id}
                announcement={announcement}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-8">
              <p className="text-sm text-muted-foreground text-center">
                No announcements at this time.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
