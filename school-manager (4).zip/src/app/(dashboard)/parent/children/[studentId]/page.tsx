"use client";

import { useParams } from "next/navigation";
import Link from "next/link";
import { CalendarCheck, BookOpen, CreditCard, MessageSquare, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatCard } from "@/components/shared/stat-card";
import { StatGridSkeleton } from "@/components/shared/skeletons";
import { formatNaira, getGradeLetter, formatDateTime } from "@/lib/utils/format";
import { useStudentAttendance } from "@/features/attendance/hooks";
import { useStudentGrades } from "@/features/grades/hooks";
import { useStudentFees } from "@/features/fees/hooks";
import { useStudentFeedback } from "@/features/feedback/hooks";
import { useTerms } from "@/features/terms/hooks";

export default function StudentOverviewPage() {
  const { studentId } = useParams() as { studentId: string };
  const { data: termsData } = useTerms();
  const currentTermId = termsData?.current_term?.id;

  const { data: attendance, isLoading: loadingAtt } = useStudentAttendance(
    studentId,
    currentTermId
  );
  const { data: grades, isLoading: loadingGrades } = useStudentGrades(
    studentId,
    currentTermId
  );
  const { data: fees, isLoading: loadingFees } = useStudentFees(studentId);
  const { data: feedback, isLoading: loadingFeedback } = useStudentFeedback(studentId);

  const isLoading = loadingAtt || loadingGrades || loadingFees || loadingFeedback;

  if (isLoading) {
    return <StatGridSkeleton count={4} />;
  }

  const attPct = attendance?.summary.percentage;
  const overallAvg = grades?.overall_average;
  const feeBalance = fees?.summary.total_balance || 0;
  const recentFeedback = feedback?.slice(0, 3) || [];

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Link href={`/parent/children/${studentId}/attendance`}>
          <StatCard
            title="Attendance"
            value={attPct !== null && attPct !== undefined ? `${attPct}%` : "—"}
            icon={CalendarCheck}
            description={
              attendance
                ? `${attendance.summary.present + attendance.summary.late}/${attendance.summary.total} days`
                : "This term"
            }
            iconColor={
              attPct !== null && attPct !== undefined
                ? attPct >= 80
                  ? "text-emerald-600"
                  : "text-amber-600"
                : undefined
            }
          />
        </Link>

        <Link href={`/parent/children/${studentId}/grades`}>
          <StatCard
            title="Overall Grade"
            value={
              overallAvg !== null && overallAvg !== undefined
                ? `${overallAvg}% (${getGradeLetter(overallAvg)})`
                : "—"
            }
            icon={BookOpen}
            description={
              grades
                ? `${grades.subjects.length} subjects`
                : "This term"
            }
            iconColor={
              overallAvg !== null && overallAvg !== undefined
                ? overallAvg >= 60
                  ? "text-emerald-600"
                  : "text-amber-600"
                : undefined
            }
          />
        </Link>

        <Link href={`/parent/children/${studentId}/fees`}>
          <StatCard
            title="Fee Balance"
            value={formatNaira(feeBalance)}
            icon={CreditCard}
            description={
              feeBalance > 0 ? "Outstanding" : "All paid"
            }
            iconColor={feeBalance > 0 ? "text-amber-600" : "text-emerald-600"}
          />
        </Link>

        <Link href={`/parent/children/${studentId}/feedback`}>
          <StatCard
            title="Feedback"
            value={feedback?.length || 0}
            icon={MessageSquare}
            description="Total entries"
            iconColor="text-blue-600"
          />
        </Link>
      </div>

      {/* Recent Feedback */}
      {recentFeedback.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Recent Feedback</CardTitle>
              <Link
                href={`/parent/children/${studentId}/feedback`}
                className="text-xs text-primary font-medium hover:underline inline-flex items-center gap-1"
              >
                View all
                <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentFeedback.map((entry) => (
              <div key={entry.id} className="flex items-start gap-3 text-sm">
                <Badge
                  variant={
                    entry.category === "positive"
                      ? "success"
                      : entry.category === "concern" || entry.category === "serious"
                        ? "warning"
                        : "default"
                  }
                  className="text-[10px] mt-0.5 shrink-0"
                >
                  {entry.category}
                </Badge>
                <div className="flex-1 min-w-0">
                  <p className="line-clamp-2">{entry.description}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {entry.teacher_name} · {formatDateTime(entry.date)}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
