"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { CalendarDays } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AttendanceCalendar } from "@/components/features/attendance/attendance-calendar";
import { AttendanceSummary } from "@/components/features/attendance/attendance-summary";
import { TermSelector } from "@/components/shared/term-selector";
import { EmptyState } from "@/components/shared/empty-state";
import { StatGridSkeleton } from "@/components/shared/skeletons";
import { Skeleton } from "@/components/ui/skeleton";
import { useStudentAttendance } from "@/features/attendance/hooks";
import { useTerms } from "@/features/terms/hooks";

export default function StudentAttendancePage() {
  const { studentId } = useParams() as { studentId: string };
  const { data: termsData } = useTerms();
  const [selectedTerm, setSelectedTerm] = useState<string | null>(null);

  const termId = selectedTerm || termsData?.current_term?.id || null;

  const { data, isLoading, error } = useStudentAttendance(studentId, termId);

  return (
    <div className="space-y-6">
      {/* Term Selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Attendance Records</h3>
        <TermSelector value={selectedTerm} onChange={setSelectedTerm} />
      </div>

      {/* Summary */}
      {isLoading && <StatGridSkeleton count={4} />}
      {!isLoading && data && <AttendanceSummary summary={data.summary} />}

      {/* Calendar */}
      {isLoading && (
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      )}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load attendance records. Please try again.
          </p>
        </div>
      )}

      {!isLoading && data && data.records.length === 0 && (
        <EmptyState
          icon={CalendarDays}
          title="No attendance records"
          description="No attendance has been recorded for this term yet."
        />
      )}

      {!isLoading && data && data.records.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Monthly View</CardTitle>
          </CardHeader>
          <CardContent>
            <AttendanceCalendar records={data.records} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
