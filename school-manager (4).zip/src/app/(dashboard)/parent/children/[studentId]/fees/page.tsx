"use client";

import { useParams } from "next/navigation";
import { CreditCard } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  FeeSummaryCards,
  FeeAccountList,
  PaymentHistory,
} from "@/components/features/fees/fee-components";
import { EmptyState } from "@/components/shared/empty-state";
import { StatGridSkeleton, ListSkeleton } from "@/components/shared/skeletons";
import { useStudentFees } from "@/features/fees/hooks";

export default function StudentFeesPage() {
  const { studentId } = useParams() as { studentId: string };
  const { data, isLoading, error } = useStudentFees(studentId);

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Fees & Payments</h3>

      {/* Loading */}
      {isLoading && (
        <>
          <StatGridSkeleton count={4} />
          <ListSkeleton rows={3} />
        </>
      )}

      {/* Error */}
      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load fee information. Please try again.
          </p>
        </div>
      )}

      {/* Empty */}
      {!isLoading && data && data.accounts.length === 0 && (
        <EmptyState
          icon={CreditCard}
          title="No fee records"
          description="No fee accounts have been set up for this student yet."
        />
      )}

      {/* Content */}
      {!isLoading && data && data.accounts.length > 0 && (
        <>
          {/* Summary */}
          <FeeSummaryCards summary={data.summary} />

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Fee Accounts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Fee Accounts</CardTitle>
              </CardHeader>
              <CardContent>
                <FeeAccountList accounts={data.accounts} />
              </CardContent>
            </Card>

            {/* Payment History */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Payment History</CardTitle>
              </CardHeader>
              <CardContent>
                <PaymentHistory payments={data.payments} />
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
