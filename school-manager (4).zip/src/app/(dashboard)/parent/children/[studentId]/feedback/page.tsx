"use client";

import { useParams } from "next/navigation";
import { MessageSquare } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FeedbackTimeline } from "@/components/features/feedback/feedback-timeline";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { useStudentFeedback } from "@/features/feedback/hooks";

export default function StudentFeedbackPage() {
  const { studentId } = useParams() as { studentId: string };
  const { data: feedback, isLoading, error } = useStudentFeedback(studentId);

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Teacher Feedback</h3>

      {isLoading && <ListSkeleton rows={5} />}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load feedback. Please try again.
          </p>
        </div>
      )}

      {!isLoading && feedback && feedback.length === 0 && (
        <EmptyState
          icon={MessageSquare}
          title="No feedback yet"
          description="Teachers haven't submitted any feedback for this student yet."
        />
      )}

      {!isLoading && feedback && feedback.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Feedback Timeline ({feedback.length} entries)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <FeedbackTimeline entries={feedback} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
