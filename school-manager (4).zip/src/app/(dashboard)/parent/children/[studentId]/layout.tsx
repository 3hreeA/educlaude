"use client";

import { useParams, usePathname } from "next/navigation";
import Link from "next/link";
import { CalendarCheck, BookOpen, CreditCard, MessageSquare, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils/cn";
import { getInitials, formatDate } from "@/lib/utils/format";
import { useStudent } from "@/features/students/hooks";

const TABS = [
  { href: "", label: "Overview", icon: User },
  { href: "/attendance", label: "Attendance", icon: CalendarCheck },
  { href: "/grades", label: "Grades", icon: BookOpen },
  { href: "/fees", label: "Fees", icon: CreditCard },
  { href: "/feedback", label: "Feedback", icon: MessageSquare },
];

export default function StudentDetailLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const params = useParams();
  const pathname = usePathname();
  const studentId = params.studentId as string;
  const { data: student, isLoading } = useStudent(studentId);

  const basePath = `/parent/children/${studentId}`;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="" backHref="/parent/children" />

      {/* Student Header */}
      {isLoading ? (
        <div className="flex items-center gap-4">
          <Skeleton className="h-16 w-16 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
      ) : student ? (
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage
              src={student.photo_url || undefined}
              alt={student.first_name}
            />
            <AvatarFallback className="bg-primary/10 text-primary text-lg font-semibold">
              {getInitials(student.first_name, student.last_name)}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-xl font-heading font-bold">
              {student.first_name}{" "}
              {student.middle_name ? `${student.middle_name} ` : ""}
              {student.last_name}
            </h2>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <span className="text-sm text-muted-foreground">
                {student.classes?.name || "Unassigned"}
              </span>
              <span className="text-muted-foreground">·</span>
              <span className="text-sm text-muted-foreground">
                {student.admission_number}
              </span>
              <Badge variant="outline" className="text-xs capitalize">
                {student.gender}
              </Badge>
            </div>
          </div>
        </div>
      ) : null}

      {/* Tab Navigation */}
      <nav className="border-b" aria-label="Student detail tabs">
        <div className="flex gap-0 overflow-x-auto -mb-px">
          {TABS.map((tab) => {
            const fullHref = `${basePath}${tab.href}`;
            const isActive =
              tab.href === ""
                ? pathname === basePath
                : pathname === fullHref || pathname.startsWith(fullHref + "/");

            return (
              <Link
                key={tab.href}
                href={fullHref}
                className={cn(
                  "flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap",
                  isActive
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30"
                )}
                aria-current={isActive ? "page" : undefined}
              >
                <tab.icon className="h-4 w-4" aria-hidden="true" />
                <span className="hidden sm:inline">{tab.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Tab Content */}
      <div>{children}</div>
    </div>
  );
}
