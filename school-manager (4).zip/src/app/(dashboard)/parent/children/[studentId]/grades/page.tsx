"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { BookOpen } from "lucide-react";
import { GradeOverview } from "@/components/features/grades/grade-overview";
import { SubjectGradeCard } from "@/components/features/grades/subject-grade-card";
import { TermSelector } from "@/components/shared/term-selector";
import { EmptyState } from "@/components/shared/empty-state";
import { StatGridSkeleton, ListSkeleton } from "@/components/shared/skeletons";
import { useStudentGrades } from "@/features/grades/hooks";
import { useTerms } from "@/features/terms/hooks";

export default function StudentGradesPage() {
  const { studentId } = useParams() as { studentId: string };
  const { data: termsData } = useTerms();
  const [selectedTerm, setSelectedTerm] = useState<string | null>(null);

  const termId = selectedTerm || termsData?.current_term?.id || null;

  const { data, isLoading, error } = useStudentGrades(studentId, termId);

  return (
    <div className="space-y-6">
      {/* Header with term selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Academic Grades</h3>
        <TermSelector value={selectedTerm} onChange={setSelectedTerm} />
      </div>

      {/* Overview Stats */}
      {isLoading && <StatGridSkeleton count={4} />}
      {!isLoading && data && <GradeOverview data={data} />}

      {/* Error */}
      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load grades. Please try again.
          </p>
        </div>
      )}

      {/* Empty */}
      {!isLoading && data && data.subjects.length === 0 && (
        <EmptyState
          icon={BookOpen}
          title="No grades yet"
          description="No assessments or grades have been recorded for this term."
        />
      )}

      {/* Subject Grade Cards */}
      {isLoading && <ListSkeleton rows={4} />}

      {!isLoading && data && data.subjects.length > 0 && (
        <div className="space-y-3">
          {data.subjects.map((subject) => (
            <SubjectGradeCard key={subject.id} subject={subject} />
          ))}
        </div>
      )}
    </div>
  );
}
