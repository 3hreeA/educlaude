"use client";

import { Users } from "lucide-react";
import { useMyChildren } from "@/features/students/hooks";
import { ChildCard } from "@/components/features/students/child-card";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { StatGridSkeleton, ListSkeleton } from "@/components/shared/skeletons";

export default function MyChildrenPage() {
  const { data: children, isLoading, error } = useMyChildren();

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="My Children"
        description="View your children's school information"
      />

      {isLoading && (
        <div className="space-y-4">
          <ListSkeleton rows={3} />
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">
            Failed to load children. Please try again later.
          </p>
        </div>
      )}

      {!isLoading && !error && children && children.length === 0 && (
        <EmptyState
          icon={Users}
          title="No children found"
          description="Your children haven't been linked to your account yet. Please contact the school administration."
        />
      )}

      {!isLoading && children && children.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {children.map((child) => (
            <ChildCard key={child.id} child={child} />
          ))}
        </div>
      )}
    </div>
  );
}
