"use client";

import { useState } from "react";
import {
  Calendar, Check, X, Clock, Filter,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { formatDate } from "@/lib/utils/format";
import { useLeaveRequests, useReviewLeave } from "@/features/admin/hooks";

const LEAVE_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  pending: "warning",
  approved: "success",
  rejected: "destructive",
  cancelled: "default",
};

const STATUS_TABS = ["all", "pending", "approved", "rejected"];

const LEAVE_TYPE_LABELS: Record<string, string> = {
  sick: "Sick Leave",
  personal: "Personal Leave",
  annual: "Annual Leave",
  maternity: "Maternity Leave",
  compassionate: "Compassionate Leave",
  study: "Study Leave",
};

export default function AdminLeavePage() {
  const [status, setStatus] = useState("pending");
  const { data, isLoading } = useLeaveRequests(status);
  const reviewLeave = useReviewLeave();
  const leaves = data?.leaves || [];

  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");

  async function handleReview(id: string, action: "approved" | "rejected") {
    await reviewLeave.mutateAsync({ id, action, review_notes: reviewNotes || undefined });
    setReviewingId(null);
    setReviewNotes("");
  }

  // Quick stats from all leaves
  const { data: allData } = useLeaveRequests("all");
  const allLeaves = allData?.leaves || [];
  const pendingCount = allLeaves.filter((l) => l.status === "pending").length;
  const approvedCount = allLeaves.filter((l) => l.status === "approved").length;
  const totalDaysApproved = allLeaves
    .filter((l) => l.status === "approved")
    .reduce((sum, l) => sum + l.days_count, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Leave Management" description="Review and manage teacher leave requests" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Pending" value={pendingCount} icon={Clock} />
        <StatCard title="Approved" value={approvedCount} icon={Check} />
        <StatCard title="Total Requests" value={allLeaves.length} icon={Calendar} />
        <StatCard title="Days Approved" value={totalDaysApproved} icon={Calendar} />
      </div>

      {/* Filter tabs */}
      <div className="flex rounded-lg border overflow-hidden text-sm w-fit">
        {STATUS_TABS.map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={`px-3 py-1.5 capitalize transition-colors ${
              status === s ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
            } ${s !== "all" ? "border-l" : ""}`}
          >
            {s}
            {s === "pending" && pendingCount > 0 && (
              <span className="ml-1 text-[10px] bg-warning/20 text-warning px-1.5 rounded-full">{pendingCount}</span>
            )}
          </button>
        ))}
      </div>

      {isLoading && <ListSkeleton rows={5} />}

      {!isLoading && leaves.length === 0 && (
        <EmptyState icon={Calendar} title="No leave requests" description="No leave requests match this filter." />
      )}

      {!isLoading && leaves.length > 0 && (
        <div className="space-y-3">
          {leaves.map((leave) => (
            <Card key={leave.id}>
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-sm">{leave.teacher_name}</h3>
                      <span className="text-xs text-muted-foreground">{leave.staff_id}</span>
                      <Badge variant={LEAVE_VARIANT[leave.status] || "default"} className="text-[10px] capitalize">
                        {leave.status}
                      </Badge>
                    </div>
                    <div className="text-sm mb-1">
                      <span className="font-medium">{LEAVE_TYPE_LABELS[leave.leave_type] || leave.leave_type}</span>
                      <span className="text-muted-foreground"> · {leave.days_count} day{leave.days_count !== 1 ? "s" : ""}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(leave.start_date)} — {formatDate(leave.end_date)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">{leave.reason}</p>

                    {leave.review_notes && (
                      <p className="text-xs mt-2 bg-muted/50 rounded px-2 py-1">
                        <span className="font-medium">Review notes: </span>{leave.review_notes}
                        {leave.reviewed_by_name && <span className="text-muted-foreground"> — {leave.reviewed_by_name}</span>}
                      </p>
                    )}

                    {/* Review form */}
                    {leave.status === "pending" && reviewingId === leave.id && (
                      <div className="mt-3 space-y-2 p-3 bg-muted/30 rounded-md">
                        <textarea
                          placeholder="Add review notes (optional)..."
                          value={reviewNotes}
                          onChange={(e) => setReviewNotes(e.target.value)}
                          rows={2}
                          className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                        />
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleReview(leave.id, "approved")}
                            disabled={reviewLeave.isPending}
                          >
                            <Check className="h-3.5 w-3.5 mr-1" /> Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleReview(leave.id, "rejected")}
                            disabled={reviewLeave.isPending}
                          >
                            <X className="h-3.5 w-3.5 mr-1" /> Reject
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => { setReviewingId(null); setReviewNotes(""); }}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  {leave.status === "pending" && reviewingId !== leave.id && (
                    <div className="flex gap-1 shrink-0">
                      <Button variant="outline" size="sm" onClick={() => setReviewingId(leave.id)}>
                        Review
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
