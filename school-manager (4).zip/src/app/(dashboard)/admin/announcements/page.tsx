"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Megaphone, Plus, Send, Archive, Trash2, Eye,
  ChevronLeft, ChevronRight, Clock, CheckCircle, FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatDateTime } from "@/lib/utils/format";
import {
  useAnnouncements,
  usePublishAnnouncement,
  useArchiveAnnouncement,
  useDeleteAnnouncement,
} from "@/features/announcements/hooks";
import type { AnnouncementItem } from "@/features/announcements/hooks";

const STATUS_TABS = [
  { label: "All", value: "all", icon: Megaphone },
  { label: "Drafts", value: "draft", icon: FileText },
  { label: "Published", value: "published", icon: CheckCircle },
  { label: "Archived", value: "archived", icon: Archive },
];

const PRIORITY_VARIANT: Record<string, "default" | "warning" | "destructive" | "info"> = {
  low: "default",
  normal: "info",
  high: "warning",
  urgent: "destructive",
};

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "info"> = {
  draft: "warning",
  published: "success",
  archived: "default",
};

const CHANNEL_LABELS: Record<string, string> = {
  in_app: "In-App",
  whatsapp: "WhatsApp",
  sms: "SMS",
  email: "Email",
};

export default function AdminAnnouncementsPage() {
  const router = useRouter();
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(1);

  const { data, isLoading, error } = useAnnouncements(page, 10, status);
  const publish = usePublishAnnouncement();
  const archive = useArchiveAnnouncement();
  const remove = useDeleteAnnouncement();

  const announcements = data?.announcements || [];
  const pagination = data?.pagination;

  function handlePublish(id: string) {
    if (confirm("Publish this announcement? It will be delivered to all targeted recipients.")) {
      publish.mutate(id);
    }
  }

  function handleArchive(id: string) {
    if (confirm("Archive this announcement?")) {
      archive.mutate(id);
    }
  }

  function handleDelete(id: string) {
    if (confirm("Delete this announcement? This cannot be undone.")) {
      remove.mutate(id);
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Announcements"
        description="Create and manage school announcements"
      >
        <Button onClick={() => router.push("/admin/announcements/compose")}>
          <Plus className="h-4 w-4 mr-2" />
          New Announcement
        </Button>
      </PageHeader>

      {/* Status Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {STATUS_TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <Button
              key={tab.value}
              variant={status === tab.value ? "default" : "outline"}
              size="sm"
              onClick={() => { setStatus(tab.value); setPage(1); }}
            >
              <Icon className="h-4 w-4 mr-1.5" />
              {tab.label}
            </Button>
          );
        })}
      </div>

      {isLoading && <ListSkeleton rows={5} />}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4">
          <p className="text-sm text-red-700">Failed to load announcements.</p>
        </div>
      )}

      {!isLoading && announcements.length === 0 && (
        <EmptyState
          icon={Megaphone}
          title="No announcements"
          description={
            status === "draft"
              ? "No draft announcements. Create one to get started."
              : "No announcements found for this filter."
          }
        />
      )}

      {!isLoading && announcements.length > 0 && (
        <div className="space-y-3">
          {announcements.map((ann) => (
            <AnnouncementRow
              key={ann.id}
              announcement={ann}
              onPublish={handlePublish}
              onArchive={handleArchive}
              onDelete={handleDelete}
              onView={(id) => router.push(`/admin/announcements/compose?edit=${id}`)}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination && pagination.total_pages > 1 && (
        <div className="flex items-center justify-center gap-4 pt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Previous
          </Button>
          <span className="text-sm text-muted-foreground">
            Page {page} of {pagination.total_pages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= pagination.total_pages}
          >
            Next
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}

// ─── Row component ────────────────────────────────────────────────────

function AnnouncementRow({
  announcement: ann,
  onPublish,
  onArchive,
  onDelete,
  onView,
}: {
  announcement: AnnouncementItem;
  onPublish: (id: string) => void;
  onArchive: (id: string) => void;
  onDelete: (id: string) => void;
  onView: (id: string) => void;
}) {
  const truncated =
    ann.content.length > 120 ? ann.content.slice(0, 117) + "..." : ann.content;

  return (
    <Card className="hover:shadow-sm transition-shadow">
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row sm:items-start gap-3">
          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="font-semibold text-sm truncate">{ann.title}</h3>
              <Badge
                variant={STATUS_VARIANT[ann.status] || "default"}
                className="text-[10px] capitalize"
              >
                {ann.status}
              </Badge>
              <Badge
                variant={PRIORITY_VARIANT[ann.priority] || "default"}
                className="text-[10px] capitalize"
              >
                {ann.priority}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mb-2">{truncated}</p>
            <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
              <span>By {ann.published_by}</span>
              {ann.published_at && (
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Published {formatDateTime(ann.published_at)}
                </span>
              )}
              {!ann.published_at && ann.created_at && (
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Created {formatDateTime(ann.created_at)}
                </span>
              )}
              {ann.target_roles && (
                <span>To: {ann.target_roles.map((r) => r.charAt(0).toUpperCase() + r.slice(1)).join(", ")}</span>
              )}
              {ann.delivery_channels && ann.delivery_channels.length > 0 && (
                <span>
                  Via: {ann.delivery_channels.map((c) => CHANNEL_LABELS[c] || c).join(", ")}
                </span>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 shrink-0">
            <Button variant="ghost" size="sm" onClick={() => onView(ann.id)} title="View/Edit">
              <Eye className="h-4 w-4" />
            </Button>
            {ann.status === "draft" && (
              <Button variant="ghost" size="sm" onClick={() => onPublish(ann.id)} title="Publish">
                <Send className="h-4 w-4 text-green-600" />
              </Button>
            )}
            {ann.status === "published" && (
              <Button variant="ghost" size="sm" onClick={() => onArchive(ann.id)} title="Archive">
                <Archive className="h-4 w-4 text-amber-600" />
              </Button>
            )}
            {ann.status !== "published" && (
              <Button variant="ghost" size="sm" onClick={() => onDelete(ann.id)} title="Delete">
                <Trash2 className="h-4 w-4 text-red-500" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
