"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  ArrowLeft, Send, Save, Megaphone,
  Smartphone, MessageSquare, Mail, Bell,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import {
  useAnnouncementDetail,
  useCreateAnnouncement,
  useUpdateAnnouncement,
  usePublishAnnouncement,
} from "@/features/announcements/hooks";
import type { CreateAnnouncementInput } from "@/features/announcements/hooks";

const PRIORITY_OPTIONS = [
  { value: "low", label: "Low", color: "bg-gray-100 text-gray-700" },
  { value: "normal", label: "Normal", color: "bg-blue-100 text-blue-700" },
  { value: "high", label: "High", color: "bg-amber-100 text-amber-700" },
  { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-700" },
];

const ROLE_OPTIONS = [
  { value: "parent", label: "Parents" },
  { value: "teacher", label: "Teachers" },
  { value: "admin", label: "Admins" },
  { value: "finance", label: "Finance" },
];

const CHANNEL_OPTIONS = [
  { value: "in_app", label: "In-App", icon: Bell, description: "Push notification in the app" },
  { value: "whatsapp", label: "WhatsApp", icon: MessageSquare, description: "Message via WhatsApp Business" },
  { value: "sms", label: "SMS", icon: Smartphone, description: "Text message to phone" },
  { value: "email", label: "Email", icon: Mail, description: "Email notification" },
];

export default function ComposeAnnouncementPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const editId = searchParams.get("edit");

  const { data: existing } = useAnnouncementDetail(editId);
  const create = useCreateAnnouncement();
  const update = useUpdateAnnouncement();
  const publish = usePublishAnnouncement();

  const [form, setForm] = useState<CreateAnnouncementInput>({
    title: "",
    content: "",
    priority: "normal",
    target_roles: ["parent", "teacher"],
    delivery_channels: ["in_app"],
    expires_at: null,
  });

  // Pre-fill form when editing
  useEffect(() => {
    if (existing) {
      setForm({
        title: existing.title,
        content: existing.content,
        priority: existing.priority,
        target_roles: existing.target_roles || ["parent", "teacher"],
        delivery_channels: existing.delivery_channels || ["in_app"],
        expires_at: existing.expires_at,
      });
    }
  }, [existing]);

  function toggleRole(role: string) {
    setForm((prev) => {
      const roles = prev.target_roles || [];
      return {
        ...prev,
        target_roles: roles.includes(role)
          ? roles.filter((r) => r !== role)
          : [...roles, role],
      };
    });
  }

  function toggleChannel(channel: string) {
    setForm((prev) => {
      const channels = prev.delivery_channels || [];
      // in_app is always required
      if (channel === "in_app") return prev;
      return {
        ...prev,
        delivery_channels: channels.includes(channel)
          ? channels.filter((c) => c !== channel)
          : [...channels, channel],
      };
    });
  }

  async function handleSaveDraft() {
    if (!form.title.trim() || !form.content.trim()) {
      alert("Please fill in the title and content.");
      return;
    }

    if (editId && existing?.status === "draft") {
      await update.mutateAsync({ id: editId, ...form });
    } else {
      await create.mutateAsync({ ...form, status: "draft" });
    }
    router.push("/admin/announcements");
  }

  async function handlePublish() {
    if (!form.title.trim() || !form.content.trim()) {
      alert("Please fill in the title and content.");
      return;
    }
    if ((form.target_roles || []).length === 0) {
      alert("Please select at least one target audience.");
      return;
    }

    const channelList = (form.delivery_channels || ["in_app"])
      .map((c) => CHANNEL_OPTIONS.find((o) => o.value === c)?.label || c)
      .join(", ");

    const confirmed = confirm(
      `Publish and deliver this announcement via ${channelList}?\n\nThis will immediately notify all targeted recipients.`
    );
    if (!confirmed) return;

    if (editId && existing?.status === "draft") {
      // Update fields first, then publish
      await update.mutateAsync({ id: editId, ...form });
      await publish.mutateAsync(editId);
    } else {
      await create.mutateAsync({ ...form, status: "published" });
    }
    router.push("/admin/announcements");
  }

  const isEditing = !!editId;
  const isPublished = existing?.status === "published";
  const isSaving = create.isPending || update.isPending || publish.isPending;
  const charCount = form.content.length;

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      <PageHeader
        title={isEditing ? "Edit Announcement" : "New Announcement"}
        description={
          isEditing
            ? "Update your announcement before publishing"
            : "Compose an announcement for your school community"
        }
      >
        <Button variant="ghost" onClick={() => router.push("/admin/announcements")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </PageHeader>

      {isPublished && (
        <div className="rounded-lg border border-blue-200 bg-blue-50 p-3">
          <p className="text-sm text-blue-700">
            This announcement is already published. Edits will not trigger re-delivery.
          </p>
        </div>
      )}

      {/* Delivery Stats — shown for published announcements */}
      {isPublished && existing?.delivery_stats && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Delivery Report</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              Total recipients: <span className="font-semibold text-foreground">{existing.delivery_stats.total}</span>
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {Object.entries(existing.delivery_stats.by_channel).map(([channel, stats]) => {
                const label =
                  channel === "in_app" ? "In-App" :
                  channel === "whatsapp" ? "WhatsApp" :
                  channel === "sms" ? "SMS" :
                  channel === "email" ? "Email" : channel;
                const total = stats.sent + stats.failed;
                const successRate = total > 0 ? Math.round((stats.sent / total) * 100) : 0;
                return (
                  <div key={channel} className="rounded-lg border p-3 text-center">
                    <p className="text-xs text-muted-foreground font-medium mb-1">{label}</p>
                    <p className="text-lg font-bold text-emerald-600">{stats.sent}</p>
                    <p className="text-[10px] text-muted-foreground">
                      sent · {stats.failed > 0 ? (
                        <span className="text-red-500">{stats.failed} failed</span>
                      ) : (
                        <span className="text-emerald-600">{successRate}% success</span>
                      )}
                    </p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Title & Content */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Megaphone className="h-4 w-4" />
            Message
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="e.g. Second Term Fee Payment Deadline"
              value={form.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              maxLength={200}
              disabled={isPublished}
            />
          </div>
          <div>
            <Label htmlFor="content">Content *</Label>
            <textarea
              id="content"
              className="flex min-h-[160px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Write your announcement message here..."
              value={form.content}
              onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))}
              maxLength={5000}
              disabled={isPublished}
            />
            <p className="text-xs text-muted-foreground mt-1 text-right">
              {charCount}/5000
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Priority */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Priority</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {PRIORITY_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => !isPublished && setForm((f) => ({ ...f, priority: opt.value }))}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all border-2 ${
                  form.priority === opt.value
                    ? `${opt.color} border-current`
                    : "bg-white text-gray-500 border-gray-200 hover:border-gray-300"
                } ${isPublished ? "opacity-60 cursor-not-allowed" : "cursor-pointer"}`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Target Audience */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Target Audience</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {ROLE_OPTIONS.map((opt) => {
              const selected = (form.target_roles || []).includes(opt.value);
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => !isPublished && toggleRole(opt.value)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all border-2 ${
                    selected
                      ? "bg-primary/10 text-primary border-primary"
                      : "bg-white text-gray-500 border-gray-200 hover:border-gray-300"
                  } ${isPublished ? "opacity-60 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
          {(form.target_roles || []).length === 0 && (
            <p className="text-xs text-red-500 mt-2">Select at least one audience</p>
          )}
        </CardContent>
      </Card>

      {/* Delivery Channels */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Delivery Channels</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {CHANNEL_OPTIONS.map((opt) => {
              const Icon = opt.icon;
              const selected = (form.delivery_channels || []).includes(opt.value);
              const isRequired = opt.value === "in_app";
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => !isPublished && toggleChannel(opt.value)}
                  className={`flex items-start gap-3 p-3 rounded-lg border-2 text-left transition-all ${
                    selected
                      ? "border-primary bg-primary/5"
                      : "border-gray-200 hover:border-gray-300"
                  } ${isPublished ? "opacity-60 cursor-not-allowed" : "cursor-pointer"}`}
                >
                  <Icon className={`h-5 w-5 mt-0.5 shrink-0 ${selected ? "text-primary" : "text-gray-400"}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{opt.label}</span>
                      {isRequired && (
                        <Badge variant="info" className="text-[9px]">Always on</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{opt.description}</p>
                  </div>
                </button>
              );
            })}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            WhatsApp and SMS require valid phone numbers. Email requires email addresses.
            External channels use configured service providers.
          </p>
        </CardContent>
      </Card>

      {/* Expiry */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Expiry (Optional)</CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="expires_at">Auto-expire after</Label>
            <Input
              id="expires_at"
              type="datetime-local"
              value={form.expires_at ? form.expires_at.slice(0, 16) : ""}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  expires_at: e.target.value ? new Date(e.target.value).toISOString() : null,
                }))
              }
              disabled={isPublished}
            />
            <p className="text-xs text-muted-foreground mt-1">
              Leave empty to keep the announcement visible indefinitely.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      {!isPublished && (
        <div className="flex items-center gap-3 pt-2">
          <Button
            variant="outline"
            onClick={handleSaveDraft}
            disabled={isSaving}
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Saving..." : "Save as Draft"}
          </Button>
          <Button onClick={handlePublish} disabled={isSaving}>
            <Send className="h-4 w-4 mr-2" />
            {isSaving ? "Publishing..." : "Publish Now"}
          </Button>
        </div>
      )}
    </div>
  );
}
