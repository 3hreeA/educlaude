"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Users, Search, ChevronRight, Clock, CalendarCheck,
  BookOpen, Award, TrendingUp,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { StatCard } from "@/components/shared/stat-card";
import { useAdminTeachers } from "@/features/admin/hooks";

export default function AdminTeachersPage() {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const { data, isLoading } = useAdminTeachers(search);
  const teachers = data?.teachers || [];

  const activeTeachers = teachers.filter((t) => t.is_active);
  const avgAttendance = activeTeachers.length > 0
    ? Math.round(
        activeTeachers
          .filter((t) => t.attendance_rate !== null)
          .reduce((sum, t) => sum + (t.attendance_rate || 0), 0) /
        (activeTeachers.filter((t) => t.attendance_rate !== null).length || 1)
      )
    : 0;
  const pendingLeaves = teachers.reduce((sum, t) => sum + t.leave_summary.pending, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Teachers" description="Manage teachers and monitor performance" />

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Active Teachers" value={activeTeachers.length} icon={Users} />
        <StatCard title="Avg. Attendance" value={`${avgAttendance}%`} icon={CalendarCheck} />
        <StatCard title="Pending Leave" value={pendingLeaves} icon={Clock} />
        <StatCard
          title="Class Teachers"
          value={activeTeachers.filter((t) => t.is_class_teacher).length}
          icon={Award}
        />
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or staff ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {isLoading && <ListSkeleton rows={6} />}

      {!isLoading && teachers.length === 0 && (
        <EmptyState icon={Users} title="No teachers found" description="No teachers match your search." />
      )}

      {!isLoading && teachers.length > 0 && (
        <div className="space-y-3">
          {teachers.map((teacher) => (
            <Card
              key={teacher.id}
              className="hover:shadow-sm transition-shadow cursor-pointer"
              onClick={() => router.push(`/admin/teachers/${teacher.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  {/* Avatar */}
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <span className="text-sm font-semibold text-primary">
                      {teacher.first_name[0]}{teacher.last_name[0]}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-sm">
                        {teacher.first_name} {teacher.last_name}
                      </h3>
                      <span className="text-xs text-muted-foreground">{teacher.staff_id}</span>
                      {teacher.is_class_teacher && (
                        <Badge variant="info" className="text-[10px]">Class Teacher</Badge>
                      )}
                      {!teacher.is_active && (
                        <Badge variant="destructive" className="text-[10px]">Inactive</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-[11px] text-muted-foreground mt-1 flex-wrap">
                      {teacher.specialization && <span>{teacher.specialization}</span>}
                      <span className="flex items-center gap-1">
                        <BookOpen className="h-3 w-3" /> {teacher.classes_count} class{teacher.classes_count !== 1 ? "es" : ""}
                      </span>
                      {teacher.attendance_rate !== null && (
                        <span className="flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          <span className={teacher.attendance_rate >= 90 ? "text-success" : teacher.attendance_rate >= 75 ? "text-warning" : "text-destructive"}>
                            {teacher.attendance_rate}% attendance
                          </span>
                        </span>
                      )}
                      {teacher.leave_summary.pending > 0 && (
                        <Badge variant="warning" className="text-[10px]">
                          {teacher.leave_summary.pending} pending leave
                        </Badge>
                      )}
                    </div>
                  </div>

                  <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
