"use client";

import { use } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, Mail, Phone, GraduationCap, Calendar,
  BookOpen, CalendarCheck, Clock, CheckCircle, XCircle,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatDate } from "@/lib/utils/format";
import { useTeacherDetail } from "@/features/admin/hooks";

const STATUS_COLORS: Record<string, string> = {
  present: "bg-success/20 text-success",
  late: "bg-warning/20 text-warning",
  absent: "bg-destructive/20 text-destructive",
  excused: "bg-blue-100 text-blue-800",
  half_day: "bg-orange-100 text-orange-800",
};

const LEAVE_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  pending: "warning",
  approved: "success",
  rejected: "destructive",
  cancelled: "default",
};

export default function TeacherDetailPage({ params }: { params: Promise<{ teacherId: string }> }) {
  const { teacherId } = use(params);
  const router = useRouter();
  const { data: teacher, isLoading } = useTeacherDetail(teacherId);

  if (isLoading) return <ListSkeleton rows={8} />;
  if (!teacher) return <div className="p-8 text-center text-muted-foreground">Teacher not found.</div>;

  const att = teacher.attendance;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title={`${teacher.first_name} ${teacher.last_name}`}
        description={`Staff ID: ${teacher.staff_id}`}
      >
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
      </PageHeader>

      {/* Profile card */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-start gap-4 flex-wrap">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <span className="text-xl font-bold text-primary">
                {teacher.first_name[0]}{teacher.last_name[0]}
              </span>
            </div>
            <div className="flex-1 min-w-0 space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-semibold">{teacher.first_name} {teacher.last_name}</h2>
                {!teacher.is_active && <Badge variant="destructive">Inactive</Badge>}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-2"><Mail className="h-3.5 w-3.5" /> {teacher.email}</span>
                {teacher.phone && <span className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" /> {teacher.phone}</span>}
                {teacher.qualification && <span className="flex items-center gap-2"><GraduationCap className="h-3.5 w-3.5" /> {teacher.qualification}</span>}
                {teacher.specialization && <span className="flex items-center gap-2"><BookOpen className="h-3.5 w-3.5" /> {teacher.specialization}</span>}
                <span className="flex items-center gap-2"><Calendar className="h-3.5 w-3.5" /> Joined {formatDate(teacher.date_joined)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance stats */}
      <div>
        <h3 className="text-sm font-semibold mb-3">Attendance (Last 60 Days)</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <StatCard
            title="Attendance Rate"
            value={att.rate !== null ? `${att.rate}%` : "N/A"}
            icon={CalendarCheck}
          />
          <StatCard title="Present" value={att.stats.present} icon={CheckCircle} />
          <StatCard title="Late" value={att.stats.late} icon={Clock} />
          <StatCard title="Absent" value={att.stats.absent} icon={XCircle} />
          <StatCard title="Excused" value={att.stats.excused} icon={AlertTriangle} />
        </div>
      </div>

      {/* Attendance calendar (recent) */}
      {att.recent.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Recent Attendance</CardTitle></CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-1.5">
              {att.recent.map((a, i) => (
                <div
                  key={i}
                  className={`w-9 h-9 rounded-md flex items-center justify-center text-[10px] font-medium ${STATUS_COLORS[a.status] || "bg-muted text-muted-foreground"}`}
                  title={`${formatDate(a.date)}: ${a.status}`}
                >
                  {new Date(a.date).getDate()}
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-3 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-success/20" /> Present</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-warning/20" /> Late</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-destructive/20" /> Absent</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-blue-100" /> Excused</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Class assignments */}
      {teacher.assignments.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Class Assignments</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {teacher.assignments.map((a) => (
                <div key={a.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{a.class?.name || "—"}</span>
                    {a.subject && <span className="text-xs text-muted-foreground">({a.subject.name})</span>}
                  </div>
                  {a.is_class_teacher && <Badge variant="info" className="text-[10px]">Class Teacher</Badge>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Leave history */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Leave History</CardTitle></CardHeader>
        <CardContent>
          {teacher.leaves.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">No leave requests on record.</p>
          ) : (
            <div className="space-y-3">
              {teacher.leaves.map((l) => (
                <div key={l.id} className="flex items-start justify-between py-2 border-b last:border-0">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium capitalize">{l.leave_type} Leave</span>
                      <Badge variant={LEAVE_VARIANT[l.status] || "default"} className="text-[10px] capitalize">
                        {l.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {formatDate(l.start_date)} — {formatDate(l.end_date)} ({l.days_count} day{l.days_count !== 1 ? "s" : ""})
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{l.reason}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
