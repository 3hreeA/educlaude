"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Shield, Plus, ChevronLeft, ChevronRight, AlertTriangle,
  CheckCircle, Search as SearchIcon, Eye, Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { formatDateTime } from "@/lib/utils/format";
import { useIncidents, useUpdateIncident } from "@/features/disciplinary/hooks";

const SEVERITY_VARIANT: Record<string, "default" | "warning" | "destructive" | "info"> = {
  minor: "default",
  moderate: "warning",
  major: "destructive",
  critical: "destructive",
};

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "info"> = {
  reported: "warning",
  investigating: "info",
  resolved: "success",
  escalated: "destructive",
};

const STATUS_TABS = ["all", "reported", "investigating", "resolved", "escalated"];
const SEVERITY_TABS = ["all", "minor", "moderate", "major", "critical"];

export default function DisciplinaryPage() {
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("all");
  const [severity, setSeverity] = useState("all");

  const { data, isLoading } = useIncidents({ page, status, severity });
  const updateIncident = useUpdateIncident();

  const incidents = data?.incidents || [];
  const pagination = data?.pagination;

  function handleResolve(id: string) {
    const actionTaken = prompt("Enter the action taken to resolve this incident:");
    if (actionTaken) {
      updateIncident.mutate({ id, status: "resolved", action_taken: actionTaken });
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Discipline" description="Track and manage student disciplinary incidents">
        <Button onClick={() => router.push("/admin/disciplinary/new")}>
          <Plus className="h-4 w-4 mr-2" /> Log Incident
        </Button>
      </PageHeader>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex rounded-lg border overflow-hidden text-sm">
          {STATUS_TABS.map((s) => (
            <button
              key={s}
              onClick={() => { setStatus(s); setPage(1); }}
              className={`px-3 py-1.5 capitalize transition-colors ${
                status === s ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
              } ${s !== "all" ? "border-l" : ""}`}
            >
              {s}
            </button>
          ))}
        </div>
        <select
          value={severity}
          onChange={(e) => { setSeverity(e.target.value); setPage(1); }}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        >
          {SEVERITY_TABS.map((s) => (
            <option key={s} value={s}>{s === "all" ? "All Severity" : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
      </div>

      {isLoading && <ListSkeleton rows={5} />}

      {!isLoading && incidents.length === 0 && (
        <EmptyState
          icon={Shield}
          title="No incidents found"
          description="No disciplinary records match your filters."
        />
      )}

      {!isLoading && incidents.length > 0 && (
        <div className="space-y-3">
          {incidents.map((inc) => (
            <Card key={inc.id} className="hover:shadow-sm transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-sm">{inc.category}</h3>
                      <Badge variant={SEVERITY_VARIANT[inc.severity] || "default"} className="text-[10px] capitalize">
                        {inc.severity}
                      </Badge>
                      <Badge variant={STATUS_VARIANT[inc.status] || "default"} className="text-[10px] capitalize">
                        {inc.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{inc.description}</p>
                    <div className="flex items-center gap-4 text-[11px] text-muted-foreground flex-wrap">
                      <span className="font-medium text-foreground">{inc.student_name}</span>
                      <span>{inc.class_name}</span>
                      <span>Reported by {inc.reported_by_name}</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {formatDateTime(inc.created_at)}
                      </span>
                      {inc.parent_notified && (
                        <Badge variant="success" className="text-[9px]">Parent Notified</Badge>
                      )}
                    </div>
                    {inc.action_taken && (
                      <p className="text-xs mt-2 bg-muted/50 rounded px-2 py-1">
                        <span className="font-medium">Action: </span>{inc.action_taken}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {inc.status !== "resolved" && (
                      <Button variant="outline" size="sm" onClick={() => handleResolve(inc.id)}>
                        <CheckCircle className="h-4 w-4 mr-1" /> Resolve
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {pagination && pagination.total_pages > 1 && (
        <div className="flex items-center justify-center gap-4 pt-4">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
            <ChevronLeft className="h-4 w-4 mr-1" /> Previous
          </Button>
          <span className="text-sm text-muted-foreground">Page {page} of {pagination.total_pages}</span>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={page >= pagination.total_pages}>
            Next <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
