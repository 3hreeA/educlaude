"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/shared/page-header";
import { useCreateIncident } from "@/features/disciplinary/hooks";
import { useAdminStudents } from "@/features/admin/hooks";

const CATEGORIES = [
  "Late Coming", "Truancy", "Disruptive Behaviour", "Fighting",
  "Bullying", "Dress Code Violation", "Cheating", "Vandalism",
  "Insubordination", "Use of Phone", "Theft", "Other",
];

const SEVERITIES = [
  { value: "minor", label: "Minor", description: "Warning or verbal correction sufficient" },
  { value: "moderate", label: "Moderate", description: "Requires documented action and parent notification" },
  { value: "major", label: "Major", description: "Suspension or significant intervention required" },
  { value: "critical", label: "Critical", description: "Immediate escalation, possible expulsion" },
];

export default function NewIncidentPage() {
  const router = useRouter();
  const createIncident = useCreateIncident();

  const [search, setSearch] = useState("");
  const { data: studentsData } = useAdminStudents({ search, limit: 10, status: "active" });
  const students = studentsData?.students || [];

  const [form, setForm] = useState({
    student_id: "",
    student_display: "",
    severity: "minor",
    category: "",
    description: "",
    action_taken: "",
    follow_up_date: "",
  });

  const [showDropdown, setShowDropdown] = useState(false);

  function selectStudent(s: { id: string; first_name: string; last_name: string; admission_number: string }) {
    setForm((f) => ({ ...f, student_id: s.id, student_display: `${s.first_name} ${s.last_name} (${s.admission_number})` }));
    setShowDropdown(false);
    setSearch("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.student_id || !form.category || !form.description) return;
    try {
      await createIncident.mutateAsync({
        student_id: form.student_id,
        severity: form.severity,
        category: form.category,
        description: form.description,
        action_taken: form.action_taken || undefined,
        follow_up_date: form.follow_up_date || undefined,
      });
      router.push("/admin/disciplinary");
    } catch {
      // Error handled by mutation
    }
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <PageHeader title="Log Disciplinary Incident" description="Record a new student disciplinary incident">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
      </PageHeader>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader><CardTitle className="text-base">Incident Details</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            {/* Student search */}
            <div className="space-y-1.5">
              <Label>Student *</Label>
              {form.student_id ? (
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{form.student_display}</span>
                  <Button type="button" variant="ghost" size="sm" onClick={() => setForm((f) => ({ ...f, student_id: "", student_display: "" }))}>
                    Change
                  </Button>
                </div>
              ) : (
                <div className="relative">
                  <Input
                    placeholder="Search student by name or admission number..."
                    value={search}
                    onChange={(e) => { setSearch(e.target.value); setShowDropdown(true); }}
                    onFocus={() => setShowDropdown(true)}
                  />
                  {showDropdown && search.length >= 2 && students.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-card border rounded-md shadow-lg max-h-48 overflow-y-auto">
                      {students.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => selectStudent(s)}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors"
                        >
                          <span className="font-medium">{s.first_name} {s.last_name}</span>
                          <span className="text-muted-foreground ml-2">({s.admission_number})</span>
                          {s.classes && <span className="text-muted-foreground ml-2">· {s.classes.name}</span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Category */}
            <div className="space-y-1.5">
              <Label>Category *</Label>
              <select
                value={form.category}
                onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                className="w-full h-10 rounded-md border bg-background px-3 text-sm"
                required
              >
                <option value="">Select category...</option>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            {/* Severity */}
            <div className="space-y-1.5">
              <Label>Severity *</Label>
              <div className="grid grid-cols-2 gap-2">
                {SEVERITIES.map((s) => (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, severity: s.value }))}
                    className={`text-left p-3 rounded-md border-2 transition-colors ${
                      form.severity === s.value
                        ? "border-primary bg-primary/5"
                        : "border-muted hover:border-muted-foreground/30"
                    }`}
                  >
                    <div className="font-medium text-sm capitalize">{s.label}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5">{s.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label>Description *</Label>
              <textarea
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Provide a detailed account of the incident, including what happened, when, and who was involved..."
                rows={4}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                required
              />
            </div>

            {/* Action taken */}
            <div className="space-y-1.5">
              <Label>Action Taken (optional)</Label>
              <textarea
                value={form.action_taken}
                onChange={(e) => setForm((f) => ({ ...f, action_taken: e.target.value }))}
                placeholder="Describe any immediate actions taken (verbal warning, detention, suspension, etc.)"
                rows={2}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            {/* Follow-up date */}
            <div className="space-y-1.5">
              <Label>Follow-up Date (optional)</Label>
              <Input
                type="date"
                value={form.follow_up_date}
                onChange={(e) => setForm((f) => ({ ...f, follow_up_date: e.target.value }))}
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button type="submit" disabled={!form.student_id || !form.category || !form.description || createIncident.isPending}>
                <Save className="h-4 w-4 mr-2" />
                {createIncident.isPending ? "Saving..." : "Log Incident"}
              </Button>
              <Button type="button" variant="outline" onClick={() => router.back()}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
