"use client";

import Link from "next/link";
import {
  GraduationCap, Users, BookOpen, CalendarCheck, Shield,
  Megaphone, UserPlus, Settings,
} from "lucide-react";
import { useAdminStats } from "@/features/admin/hooks";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminDashboard() {
  const { data: stats, isLoading } = useAdminStats();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">School Administration</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Overview of your school&apos;s operations and metrics
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild size="sm">
            <Link href="/admin/students/register">
              <UserPlus className="h-4 w-4 mr-2" />
              Register Student
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-[120px] rounded-xl" />
          ))
        ) : (
          <>
            <StatCard title="Total Students" value={stats?.total_students ?? 0} description="Active enrolment" icon={GraduationCap} iconColor="text-primary" />
            <StatCard title="Total Teachers" value={stats?.total_teachers ?? 0} description="Active staff" icon={Users} iconColor="text-violet-600" />
            <StatCard title="Classes" value={stats?.total_classes ?? 0} description="This academic year" icon={BookOpen} iconColor="text-blue-600" />
            <StatCard title="Attendance Today" value={stats?.attendance_today != null ? `${stats.attendance_today}%` : "—"} description="School-wide present rate" icon={CalendarCheck} iconColor="text-emerald-600" />
            <StatCard title="Pending Incidents" value={stats?.pending_incidents ?? 0} description="Unresolved cases" icon={Shield} iconColor="text-amber-600" />
            <StatCard title="Announcements" value={stats?.active_announcements ?? 0} description="Active notices" icon={Megaphone} iconColor="text-rose-600" />
          </>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Link href="/admin/students">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <GraduationCap className="h-4 w-4 text-primary" />
                Manage Students
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">View, search, and manage student records</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/students/register">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <UserPlus className="h-4 w-4 text-emerald-600" />
                Register New Student
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">Enrol a new student with parent details</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/classes">
          <Card className="hover:border-primary/50 transition-colors cursor-pointer">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Settings className="h-4 w-4 text-blue-600" />
                Class Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">View classes and student allocation</p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
