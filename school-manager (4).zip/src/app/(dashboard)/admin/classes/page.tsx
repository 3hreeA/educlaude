"use client";

import { useState } from "react";
import { BookOpen, Users, Plus, Loader2 } from "lucide-react";
import { useAdminClasses, useCreateClass } from "@/features/admin/hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHeader } from "@/components/shared/page-header";

export default function AdminClassesPage() {
  const { data: classes, isLoading } = useAdminClasses();
  const createMutation = useCreateClass();
  const [showCreate, setShowCreate] = useState(false);
  const [newClass, setNewClass] = useState({ name: "", level: "", arm: "", capacity: "40" });
  const [error, setError] = useState("");

  const handleCreate = async () => {
    setError("");
    try {
      await createMutation.mutateAsync({
        name: newClass.name,
        level: newClass.level,
        arm: newClass.arm || undefined,
        capacity: parseInt(newClass.capacity) || 40,
      });
      setShowCreate(false);
      setNewClass({ name: "", level: "", arm: "", capacity: "40" });
    } catch (err: unknown) {
      setError((err as Error).message || "Failed to create class");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Class Management"
        description={`${classes?.length ?? 0} classes this academic year`}
        action={
          <Button size="sm" onClick={() => setShowCreate(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Class
          </Button>
        }
      />

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-[140px] rounded-xl" />
          ))}
        </div>
      ) : !classes?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <BookOpen className="h-10 w-10 mx-auto mb-3 opacity-50" />
            <p className="text-sm">No classes created yet. Click &quot;Add Class&quot; to get started.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((cls) => {
            const occupancy = cls.capacity > 0 ? Math.round((cls.student_count / cls.capacity) * 100) : 0;
            return (
              <Card key={cls.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base">{cls.name}</CardTitle>
                    <Badge variant="outline" className="text-xs">{cls.level}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{cls.student_count} / {cls.capacity} students</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Capacity</span>
                      <span>{occupancy}%</span>
                    </div>
                    <Progress
                      value={occupancy}
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Create Class Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Class</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Class Name *</Label>
              <Input
                value={newClass.name}
                onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
                placeholder="e.g. Primary 5A"
              />
            </div>
            <div className="grid gap-4 grid-cols-2">
              <div className="space-y-2">
                <Label>Level *</Label>
                <Select value={newClass.level} onValueChange={(v) => setNewClass({ ...newClass, level: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {["Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6",
                      "JSS 1", "JSS 2", "JSS 3", "SSS 1", "SSS 2", "SSS 3",
                    ].map((l) => (
                      <SelectItem key={l} value={l}>{l}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Arm</Label>
                <Input
                  value={newClass.arm}
                  onChange={(e) => setNewClass({ ...newClass, arm: e.target.value })}
                  placeholder="e.g. A, B"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Capacity</Label>
              <Input
                type="number"
                value={newClass.capacity}
                onChange={(e) => setNewClass({ ...newClass, capacity: e.target.value })}
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button
              onClick={handleCreate}
              disabled={!newClass.name || !newClass.level || createMutation.isPending}
            >
              {createMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Create Class
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
