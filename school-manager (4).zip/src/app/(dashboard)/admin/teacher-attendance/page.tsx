"use client";

import { useState, useMemo } from "react";
import {
  CalendarCheck, CheckCircle, Save, Users, Clock,
  XCircle, ChevronLeft, ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ListSkeleton } from "@/components/shared/skeletons";
import { useTeacherAttendance, useMarkTeacherAttendance } from "@/features/admin/hooks";

const STATUSES = [
  { value: "present", label: "Present", color: "bg-success/10 border-success text-success" },
  { value: "late", label: "Late", color: "bg-warning/10 border-warning text-warning" },
  { value: "absent", label: "Absent", color: "bg-destructive/10 border-destructive text-destructive" },
  { value: "excused", label: "Excused", color: "bg-blue-50 border-blue-400 text-blue-700" },
  { value: "half_day", label: "Half Day", color: "bg-orange-50 border-orange-400 text-orange-700" },
];

export default function TeacherAttendancePage() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const { data, isLoading } = useTeacherAttendance(date);
  const markAttendance = useMarkTeacherAttendance();

  const teachers = data?.teachers || [];

  const [entries, setEntries] = useState<Record<string, string>>({});

  // Sync loaded data into entries
  useMemo(() => {
    const init: Record<string, string> = {};
    for (const t of teachers) {
      init[t.teacher_id] = t.status || "present";
    }
    setEntries(init);
  }, [teachers]);

  function setStatus(teacherId: string, status: string) {
    setEntries((prev) => ({ ...prev, [teacherId]: status }));
  }

  function markAllPresent() {
    const all: Record<string, string> = {};
    for (const t of teachers) all[t.teacher_id] = "present";
    setEntries(all);
  }

  async function handleSave() {
    const list = Object.entries(entries).map(([teacher_id, status]) => ({ teacher_id, status }));
    await markAttendance.mutateAsync({ date, entries: list });
  }

  function changeDate(delta: number) {
    const d = new Date(date);
    d.setDate(d.getDate() + delta);
    setDate(d.toISOString().split("T")[0]);
  }

  const stats = useMemo(() => {
    const counts = { present: 0, late: 0, absent: 0, excused: 0, half_day: 0 };
    for (const s of Object.values(entries)) {
      if (s in counts) counts[s as keyof typeof counts]++;
    }
    return counts;
  }, [entries]);

  const isToday = date === new Date().toISOString().split("T")[0];

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Teacher Attendance" description="Mark daily teacher attendance">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={markAllPresent}>
            <CheckCircle className="h-4 w-4 mr-1" /> All Present
          </Button>
          <Button size="sm" onClick={handleSave} disabled={markAttendance.isPending || teachers.length === 0}>
            <Save className="h-4 w-4 mr-1" />
            {markAttendance.isPending ? "Saving..." : "Save"}
          </Button>
        </div>
      </PageHeader>

      {/* Date picker */}
      <div className="flex items-center gap-3">
        <Button variant="outline" size="icon" onClick={() => changeDate(-1)}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="h-9 rounded-md border bg-background px-3 text-sm"
        />
        <Button variant="outline" size="icon" onClick={() => changeDate(1)} disabled={isToday}>
          <ChevronRight className="h-4 w-4" />
        </Button>
        {isToday && <Badge variant="info" className="text-[10px]">Today</Badge>}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatCard title="Total" value={teachers.length} icon={Users} />
        <StatCard title="Present" value={stats.present} icon={CheckCircle} />
        <StatCard title="Late" value={stats.late} icon={Clock} />
        <StatCard title="Absent" value={stats.absent} icon={XCircle} />
        <StatCard title="Excused" value={stats.excused} icon={CalendarCheck} />
      </div>

      {isLoading && <ListSkeleton rows={6} />}

      {!isLoading && teachers.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Staff ({teachers.length})</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {teachers.map((t) => (
                <div key={t.teacher_id} className="flex items-center gap-3 px-4 py-3">
                  {/* Avatar */}
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-xs font-semibold text-primary">
                    {t.name.split(" ").map((n) => n[0]).join("")}
                  </div>

                  {/* Name */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{t.name}</p>
                    <p className="text-[11px] text-muted-foreground">{t.staff_id}</p>
                  </div>

                  {/* Status buttons */}
                  <div className="flex gap-1 flex-wrap">
                    {STATUSES.map((s) => (
                      <button
                        key={s.value}
                        onClick={() => setStatus(t.teacher_id, s.value)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-medium border transition-all ${
                          entries[t.teacher_id] === s.value
                            ? s.color + " border-current"
                            : "bg-card border-muted text-muted-foreground hover:border-muted-foreground/40"
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {markAttendance.isSuccess && (
        <div className="text-sm text-success font-medium text-center">Attendance saved successfully.</div>
      )}
    </div>
  );
}
