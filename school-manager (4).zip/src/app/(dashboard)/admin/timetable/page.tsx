"use client";

import { useState, useMemo } from "react";
import {
  Clock, Plus, Trash2, BookOpen,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ListSkeleton } from "@/components/shared/skeletons";
import { useTimetable, useCreateSlot, useDeleteSlot } from "@/features/timetable/hooks";
import { useAdminClasses } from "@/features/admin/hooks";

const DAYS = [
  { value: 1, label: "Monday" },
  { value: 2, label: "Tuesday" },
  { value: 3, label: "Wednesday" },
  { value: 4, label: "Thursday" },
  { value: 5, label: "Friday" },
];

const DAY_COLORS = [
  "", "bg-blue-50 border-blue-200", "bg-green-50 border-green-200",
  "bg-purple-50 border-purple-200", "bg-orange-50 border-orange-200",
  "bg-pink-50 border-pink-200",
];

export default function TimetablePage() {
  const { data: classesData } = useAdminClasses();
  const classes = classesData?.classes || [];
  const [selectedClass, setSelectedClass] = useState("");

  const { data, isLoading } = useTimetable(selectedClass ? { class_id: selectedClass } : undefined);
  const createSlot = useCreateSlot();
  const deleteSlot = useDeleteSlot();
  const byDay = data?.by_day || {};

  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    day_of_week: 1,
    start_time: "08:00",
    end_time: "08:45",
    subject_id: "",
    teacher_id: "",
    room: "",
  });

  async function handleAdd() {
    if (!selectedClass) return;
    await createSlot.mutateAsync({
      class_id: selectedClass,
      day_of_week: form.day_of_week,
      start_time: form.start_time,
      end_time: form.end_time,
      subject_id: form.subject_id || undefined,
      teacher_id: form.teacher_id || undefined,
      room: form.room || undefined,
    });
    setShowAdd(false);
  }

  const selectedClassName = classes.find((c) => c.id === selectedClass)?.name || "";

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Timetable" description="Manage class schedules">
        {selectedClass && (
          <Button onClick={() => setShowAdd(!showAdd)}>
            <Plus className="h-4 w-4 mr-2" /> Add Slot
          </Button>
        )}
      </PageHeader>

      {/* Class selector */}
      <div className="space-y-1.5 max-w-xs">
        <Label>Select Class</Label>
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="w-full h-10 rounded-md border bg-background px-3 text-sm"
        >
          <option value="">Choose a class...</option>
          {classes.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {/* Add slot form */}
      {showAdd && (
        <Card>
          <CardHeader><CardTitle className="text-sm">Add Timetable Slot — {selectedClassName}</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="space-y-1">
                <Label>Day</Label>
                <select value={form.day_of_week} onChange={(e) => setForm((f) => ({ ...f, day_of_week: Number(e.target.value) }))} className="w-full h-9 rounded-md border bg-background px-3 text-sm">
                  {DAYS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <Label>Start</Label>
                <Input type="time" value={form.start_time} onChange={(e) => setForm((f) => ({ ...f, start_time: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1">
                <Label>End</Label>
                <Input type="time" value={form.end_time} onChange={(e) => setForm((f) => ({ ...f, end_time: e.target.value }))} className="h-9" />
              </div>
              <div className="space-y-1">
                <Label>Room</Label>
                <Input value={form.room} onChange={(e) => setForm((f) => ({ ...f, room: e.target.value }))} placeholder="e.g. Room 3A" className="h-9" />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAdd} disabled={createSlot.isPending}>
                {createSlot.isPending ? "Adding..." : "Add Slot"}
              </Button>
              <Button variant="ghost" onClick={() => setShowAdd(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {!selectedClass && (
        <EmptyState icon={Clock} title="Select a class" description="Choose a class to view and manage its timetable." />
      )}

      {selectedClass && isLoading && <ListSkeleton rows={5} />}

      {/* Timetable grid */}
      {selectedClass && !isLoading && (
        <div className="space-y-4">
          {DAYS.map((day) => {
            const slots = byDay[day.value] || [];
            return (
              <Card key={day.value} className={slots.length > 0 ? DAY_COLORS[day.value] : ""}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{day.label}</CardTitle>
                </CardHeader>
                <CardContent>
                  {slots.length === 0 ? (
                    <p className="text-xs text-muted-foreground py-2">No slots scheduled</p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                      {slots.map((slot) => (
                        <div key={slot.id} className="flex items-start justify-between p-2.5 rounded-lg bg-card border text-sm">
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 mb-0.5">
                              <span className="text-xs font-mono text-muted-foreground">{slot.start_time}–{slot.end_time}</span>
                              {slot.room && <Badge variant="outline" className="text-[9px]">{slot.room}</Badge>}
                            </div>
                            <p className="font-medium text-xs">{slot.subject_name}</p>
                            {slot.teacher_name && <p className="text-[11px] text-muted-foreground">{slot.teacher_name}</p>}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 shrink-0"
                            onClick={() => deleteSlot.mutate(slot.id)}
                          >
                            <Trash2 className="h-3 w-3 text-muted-foreground" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
