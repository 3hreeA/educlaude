"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft, Edit, Save, X, Loader2, Mail, Phone, User,
  CreditCard, BookOpen, Activity, Calendar, Droplets,
} from "lucide-react";
import { useStudentDetail, useUpdateStudent, useAdminClasses } from "@/features/admin/hooks";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { formatDate, formatNaira, getInitials, formatPhone } from "@/lib/utils/format";

export default function StudentDetailPage() {
  const { studentId } = useParams() as { studentId: string };
  const router = useRouter();
  const { data: student, isLoading, error } = useStudentDetail(studentId);
  const { data: classes } = useAdminClasses();
  const updateMutation = useUpdateStudent();

  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<Record<string, unknown>>({});
  const [saveError, setSaveError] = useState("");

  const startEdit = () => {
    if (!student) return;
    setForm({
      first_name: student.first_name,
      last_name: student.last_name,
      middle_name: student.middle_name || "",
      gender: student.gender,
      date_of_birth: student.date_of_birth,
      address: student.address || "",
      blood_group: student.blood_group || "",
      genotype: student.genotype || "",
      medical_notes: student.medical_notes || "",
      class_id: student.classes?.id || "",
      is_active: student.is_active,
    });
    setEditing(true);
    setSaveError("");
  };

  const handleSave = async () => {
    setSaveError("");
    try {
      await updateMutation.mutateAsync({ id: studentId, ...form });
      setEditing(false);
    } catch (err: unknown) {
      setSaveError((err as Error).message || "Failed to save");
    }
  };

  const set = (field: string, value: unknown) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  if (isLoading) {
    return (
      <div className="space-y-6 animate-fade-in max-w-3xl mx-auto">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-48 rounded-xl" />
        <Skeleton className="h-32 rounded-xl" />
      </div>
    );
  }

  if (error || !student) {
    return (
      <div className="max-w-3xl mx-auto space-y-4">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <p className="text-sm">Student not found or access denied.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
        {editing ? (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setEditing(false)}>
              <X className="h-4 w-4 mr-1" /> Cancel
            </Button>
            <Button size="sm" onClick={handleSave} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
              Save
            </Button>
          </div>
        ) : (
          <Button variant="outline" size="sm" onClick={startEdit}>
            <Edit className="h-4 w-4 mr-1" /> Edit
          </Button>
        )}
      </div>

      {saveError && (
        <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{saveError}</div>
      )}

      {/* Student Profile Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="text-xl bg-primary/10 text-primary">
                {getInitials(student.first_name, student.last_name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              {editing ? (
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="space-y-1">
                    <Label className="text-xs">First Name</Label>
                    <Input value={form.first_name as string} onChange={(e) => set("first_name", e.target.value)} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Middle Name</Label>
                    <Input value={form.middle_name as string} onChange={(e) => set("middle_name", e.target.value)} />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Last Name</Label>
                    <Input value={form.last_name as string} onChange={(e) => set("last_name", e.target.value)} />
                  </div>
                </div>
              ) : (
                <>
                  <h2 className="text-xl font-bold">
                    {student.last_name}, {student.first_name}
                    {student.middle_name ? ` ${student.middle_name}` : ""}
                  </h2>
                  <div className="flex flex-wrap gap-2 mt-1">
                    <Badge variant="outline" className="text-xs font-mono">{student.admission_number}</Badge>
                    <Badge variant={student.is_active ? "default" : "secondary"} className="text-xs">
                      {student.is_active ? "Active" : "Inactive"}
                    </Badge>
                    {student.classes && (
                      <Badge variant="outline" className="text-xs">{student.classes.name}</Badge>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Info */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <User className="h-4 w-4" /> Personal Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          {editing ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-xs">Gender</Label>
                <Select value={form.gender as string} onValueChange={(v) => set("gender", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Date of Birth</Label>
                <Input type="date" value={form.date_of_birth as string} onChange={(e) => set("date_of_birth", e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Class</Label>
                <Select value={form.class_id as string} onValueChange={(v) => set("class_id", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(classes || []).map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1 flex items-center gap-3 pt-5">
                <Switch checked={form.is_active as boolean} onCheckedChange={(v) => set("is_active", v)} />
                <Label className="text-xs">Active Student</Label>
              </div>
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">Address</Label>
                <Textarea value={form.address as string} onChange={(e) => set("address", e.target.value)} rows={2} />
              </div>
            </div>
          ) : (
            <div className="grid gap-x-6 gap-y-3 sm:grid-cols-2 text-sm">
              <InfoRow icon={<User className="h-3.5 w-3.5" />} label="Gender" value={student.gender} capitalize />
              <InfoRow icon={<Calendar className="h-3.5 w-3.5" />} label="Date of Birth" value={formatDate(student.date_of_birth)} />
              <InfoRow icon={<BookOpen className="h-3.5 w-3.5" />} label="Class" value={student.classes?.name} />
              <InfoRow icon={<Calendar className="h-3.5 w-3.5" />} label="Admitted" value={formatDate(student.admission_date)} />
              {student.address && (
                <div className="sm:col-span-2">
                  <InfoRow icon={<Activity className="h-3.5 w-3.5" />} label="Address" value={student.address} />
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Medical Info */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Droplets className="h-4 w-4" /> Medical Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          {editing ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-xs">Blood Group</Label>
                <Select value={form.blood_group as string} onValueChange={(v) => set("blood_group", v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map((g) => (
                      <SelectItem key={g} value={g}>{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Genotype</Label>
                <Select value={form.genotype as string} onValueChange={(v) => set("genotype", v)}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {["AA", "AS", "SS", "AC", "SC"].map((g) => (
                      <SelectItem key={g} value={g}>{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">Medical Notes / Allergies</Label>
                <Textarea value={form.medical_notes as string} onChange={(e) => set("medical_notes", e.target.value)} rows={2} />
              </div>
            </div>
          ) : (
            <div className="grid gap-x-6 gap-y-3 sm:grid-cols-2 text-sm">
              <InfoRow icon={<Droplets className="h-3.5 w-3.5" />} label="Blood Group" value={student.blood_group || "Not recorded"} />
              <InfoRow icon={<Activity className="h-3.5 w-3.5" />} label="Genotype" value={student.genotype || "Not recorded"} />
              {student.medical_notes && (
                <div className="sm:col-span-2">
                  <p className="text-xs text-muted-foreground mb-1">Medical Notes</p>
                  <p className="text-sm">{student.medical_notes}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Parent/Guardian Info */}
      {student.parents && student.parents.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <User className="h-4 w-4" /> Parent / Guardian
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {student.parents.map((parent, idx) => (
              <div key={idx} className="space-y-2">
                {idx > 0 && <Separator />}
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{parent.first_name} {parent.last_name}</span>
                  <Badge variant="outline" className="text-xs capitalize">{parent.relationship}</Badge>
                </div>
                <div className="grid gap-2 sm:grid-cols-2 text-sm">
                  {parent.email && (
                    <a href={`mailto:${parent.email}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                      <Mail className="h-3.5 w-3.5" /> {parent.email}
                    </a>
                  )}
                  {parent.phone && (
                    <a href={`tel:${parent.phone}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                      <Phone className="h-3.5 w-3.5" /> {formatPhone(parent.phone)}
                    </a>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Fee Summary */}
      {student.fee_summary && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <CreditCard className="h-4 w-4" /> Fee Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-3 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Total Due</p>
                <p className="text-lg font-bold">{formatNaira(student.fee_summary.total_due)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Paid</p>
                <p className="text-lg font-bold text-emerald-600">{formatNaira(student.fee_summary.total_paid)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Balance</p>
                <p className={`text-lg font-bold ${student.fee_summary.total_balance > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                  {formatNaira(student.fee_summary.total_balance)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function InfoRow({
  icon,
  label,
  value,
  capitalize = false,
}: {
  icon: React.ReactNode;
  label: string;
  value?: string | null;
  capitalize?: boolean;
}) {
  return (
    <div className="flex items-start gap-2">
      <span className="text-muted-foreground mt-0.5 shrink-0">{icon}</span>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`font-medium ${capitalize ? "capitalize" : ""}`}>{value || "—"}</p>
      </div>
    </div>
  );
}
