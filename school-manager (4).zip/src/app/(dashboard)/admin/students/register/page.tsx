"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Check, Loader2 } from "lucide-react";
import { useAdminClasses, useRegisterStudent } from "@/features/admin/hooks";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";

const STEPS = [
  { id: 1, label: "Personal Info" },
  { id: 2, label: "Parent/Guardian" },
  { id: 3, label: "Medical & Class" },
  { id: 4, label: "Review" },
];

interface FormData {
  first_name: string;
  last_name: string;
  middle_name: string;
  gender: string;
  date_of_birth: string;
  address: string;
  parent_name: string;
  parent_email: string;
  parent_phone: string;
  parent_relationship: string;
  blood_group: string;
  genotype: string;
  medical_notes: string;
  class_id: string;
}

const INITIAL: FormData = {
  first_name: "", last_name: "", middle_name: "", gender: "", date_of_birth: "", address: "",
  parent_name: "", parent_email: "", parent_phone: "", parent_relationship: "parent",
  blood_group: "", genotype: "", medical_notes: "", class_id: "",
};

export default function RegisterStudentPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormData>(INITIAL);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const { data: classes } = useAdminClasses();
  const registerMutation = useRegisterStudent();

  const set = (field: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const setSelect = (field: keyof FormData) => (value: string) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const canNext = (): boolean => {
    if (step === 1) return !!form.first_name && !!form.last_name && !!form.gender && !!form.date_of_birth;
    if (step === 2) return true; // Parent info optional
    if (step === 3) return !!form.class_id;
    return true;
  };

  const handleSubmit = async () => {
    setError("");
    try {
      await registerMutation.mutateAsync(form);
      setSuccess(true);
    } catch (err: unknown) {
      setError((err as Error).message || "Registration failed");
    }
  };

  if (success) {
    return (
      <div className="max-w-lg mx-auto py-12 text-center space-y-4">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
          <Check className="h-8 w-8 text-emerald-600" />
        </div>
        <h2 className="text-xl font-bold">Student Registered Successfully!</h2>
        <p className="text-sm text-muted-foreground">
          {form.first_name} {form.last_name} has been enrolled.
        </p>
        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={() => { setForm(INITIAL); setStep(1); setSuccess(false); }}>
            Register Another
          </Button>
          <Button onClick={() => router.push("/admin/students")}>
            View All Students
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <PageHeader title="Register New Student" description="Complete the form to enrol a new student" />

      {/* Step indicator */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold ${
              step > s.id ? "bg-primary text-primary-foreground"
                : step === s.id ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground"
            }`}>
              {step > s.id ? <Check className="h-4 w-4" /> : s.id}
            </div>
            <span className="text-xs hidden sm:inline text-muted-foreground">{s.label}</span>
            {i < STEPS.length - 1 && <div className="h-px w-4 sm:w-8 bg-border" />}
          </div>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{STEPS[step - 1].label}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Step 1: Personal Info */}
          {step === 1 && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>First Name *</Label>
                  <Input value={form.first_name} onChange={set("first_name")} placeholder="e.g. Chidi" />
                </div>
                <div className="space-y-2">
                  <Label>Last Name *</Label>
                  <Input value={form.last_name} onChange={set("last_name")} placeholder="e.g. Okafor" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Middle Name</Label>
                <Input value={form.middle_name} onChange={set("middle_name")} placeholder="Optional" />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Gender *</Label>
                  <Select value={form.gender} onValueChange={setSelect("gender")}>
                    <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Date of Birth *</Label>
                  <Input type="date" value={form.date_of_birth} onChange={set("date_of_birth")} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Home Address</Label>
                <Textarea value={form.address} onChange={set("address")} placeholder="Student's home address" rows={2} />
              </div>
            </>
          )}

          {/* Step 2: Parent/Guardian */}
          {step === 2 && (
            <>
              <p className="text-sm text-muted-foreground">
                Enter the parent/guardian details. If the parent already has an account, they will be linked automatically.
              </p>
              <div className="space-y-2">
                <Label>Parent/Guardian Full Name</Label>
                <Input value={form.parent_name} onChange={set("parent_name")} placeholder="e.g. Ngozi Okafor" />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Email Address</Label>
                  <Input type="email" value={form.parent_email} onChange={set("parent_email")} placeholder="parent@example.com" />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input value={form.parent_phone} onChange={set("parent_phone")} placeholder="08012345678" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Relationship</Label>
                <Select value={form.parent_relationship} onValueChange={setSelect("parent_relationship")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="father">Father</SelectItem>
                    <SelectItem value="mother">Mother</SelectItem>
                    <SelectItem value="guardian">Guardian</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {/* Step 3: Medical & Class */}
          {step === 3 && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Blood Group</Label>
                  <Select value={form.blood_group} onValueChange={setSelect("blood_group")}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map((g) => (
                        <SelectItem key={g} value={g}>{g}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Genotype</Label>
                  <Select value={form.genotype} onValueChange={setSelect("genotype")}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {["AA", "AS", "SS", "AC", "SC"].map((g) => (
                        <SelectItem key={g} value={g}>{g}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Medical Notes / Allergies</Label>
                <Textarea value={form.medical_notes} onChange={set("medical_notes")} placeholder="Any allergies, conditions, or special needs" rows={2} />
              </div>
              <div className="space-y-2">
                <Label>Assign to Class *</Label>
                <Select value={form.class_id} onValueChange={setSelect("class_id")}>
                  <SelectTrigger><SelectValue placeholder="Select a class" /></SelectTrigger>
                  <SelectContent>
                    {(classes || []).map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} ({c.student_count}/{c.capacity})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          {/* Step 4: Review */}
          {step === 4 && (
            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2 text-sm">
                <div>
                  <span className="text-muted-foreground">Name:</span>{" "}
                  <span className="font-medium">{form.first_name} {form.middle_name} {form.last_name}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Gender:</span>{" "}
                  <Badge variant="outline" className="capitalize">{form.gender}</Badge>
                </div>
                <div>
                  <span className="text-muted-foreground">Date of Birth:</span>{" "}
                  <span className="font-medium">{form.date_of_birth}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Class:</span>{" "}
                  <Badge>{classes?.find((c) => c.id === form.class_id)?.name || "—"}</Badge>
                </div>
                {form.blood_group && (
                  <div><span className="text-muted-foreground">Blood Group:</span> {form.blood_group}</div>
                )}
                {form.genotype && (
                  <div><span className="text-muted-foreground">Genotype:</span> {form.genotype}</div>
                )}
              </div>
              {form.parent_name && (
                <div className="border-t pt-3 space-y-1 text-sm">
                  <p className="font-medium">Parent/Guardian</p>
                  <p>{form.parent_name} ({form.parent_relationship})</p>
                  {form.parent_email && <p className="text-muted-foreground">{form.parent_email}</p>}
                  {form.parent_phone && <p className="text-muted-foreground">{form.parent_phone}</p>}
                </div>
              )}
              {form.address && (
                <div className="border-t pt-3 text-sm">
                  <span className="text-muted-foreground">Address:</span> {form.address}
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</div>
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={() => step > 1 ? setStep(step - 1) : router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          {step > 1 ? "Previous" : "Cancel"}
        </Button>
        {step < 4 ? (
          <Button onClick={() => setStep(step + 1)} disabled={!canNext()}>
            Next
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        ) : (
          <Button onClick={handleSubmit} disabled={registerMutation.isPending}>
            {registerMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Register Student
          </Button>
        )}
      </div>
    </div>
  );
}
