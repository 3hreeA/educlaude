"use client";

import { NotificationsPageContent } from "@/components/features/notifications/notifications-page";

export default function NotificationsPage() {
  return <NotificationsPageContent />;
}
