import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

export interface Conversation {
  contact_id: string;
  contact_name: string;
  contact_role: string;
  thread_id: string | null;
  last_message: string;
  last_at: string;
  unread: number;
}

export interface Message {
  id: string;
  content: string;
  subject: string | null;
  created_at: string;
  read_at: string | null;
  sender: {
    id: string;
    first_name: string;
    last_name: string;
    role: string;
  } | null;
}

export function useConversations() {
  return useQuery({
    queryKey: ["conversations"],
    queryFn: () => apiFetch<{ conversations: Conversation[]; total_unread: number }>("/api/messages"),
    refetchInterval: 30_000,
  });
}

export function useThread(threadId: string | null) {
  return useQuery({
    queryKey: ["thread", threadId],
    queryFn: () => apiFetch<{ messages: Message[] }>(buildUrl("/api/messages", { thread_id: threadId })),
    enabled: !!threadId,
    refetchInterval: 15_000,
  });
}

export function useSendMessage() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { recipient_id: string; content: string; subject?: string; thread_id?: string }) =>
      apiFetch<{ id: string; thread_id: string }>("/api/messages", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["conversations"] });
      qc.invalidateQueries({ queryKey: ["thread"] });
    },
  });
}
