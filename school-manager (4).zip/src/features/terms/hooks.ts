import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface TermInfo {
  id: string;
  name: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
}

export interface TermsData {
  terms: TermInfo[];
  current_term: TermInfo | null;
  academic_year: { id: string; name: string } | null;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useTerms() {
  return useQuery({
    queryKey: ["terms"],
    queryFn: () => apiFetch<TermsData>("/api/terms"),
    staleTime: 5 * 60 * 1000, // Terms rarely change
  });
}
