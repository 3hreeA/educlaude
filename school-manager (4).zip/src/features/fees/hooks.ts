import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface FeeAccount {
  id: string;
  total_amount: number;
  amount_paid: number;
  balance: number;
  status: string;
  due_date: string;
  fee_structures: {
    id: string;
    name: string;
    total_amount: number;
    terms: { id: string; name: string } | null;
    academic_years: { id: string; name: string } | null;
  } | null;
}

export interface PaymentRecord {
  id: string;
  amount: number;
  payment_method: string;
  payment_reference: string;
  status: string;
  receipt_number: string | null;
  created_at: string;
  fee_account_id: string;
}

export interface FeeSummary {
  total_due: number;
  total_paid: number;
  total_balance: number;
  overdue_count: number;
}

export interface FeesData {
  accounts: FeeAccount[];
  payments: PaymentRecord[];
  summary: FeeSummary;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useStudentFees(studentId: string) {
  return useQuery({
    queryKey: ["fees", studentId],
    queryFn: () => apiFetch<FeesData>(`/api/fees/student/${studentId}`),
    enabled: !!studentId,
  });
}
