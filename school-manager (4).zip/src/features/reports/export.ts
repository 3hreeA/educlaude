// ============================================================================
// School Manager — Report Export Utilities (PDF + Excel)
// Client-side generation using jsPDF and SheetJS
// ============================================================================

import type { ReportResponse } from "./hooks";

/** Column definition for report tables */
export interface ReportColumn {
  key: string;
  label: string;
  format?: "currency" | "percentage" | "date" | "number";
  width?: number;
}

// ─── Excel Export ─────────────────────────────────────────────────────

export async function exportToExcel(
  report: ReportResponse,
  columns: ReportColumn[],
  filename: string
) {
  const XLSX = await import("xlsx");

  // Build header row
  const headers = columns.map((c) => c.label);

  // Build data rows
  const rows = report.data.map((row) =>
    columns.map((col) => {
      const val = row[col.key];
      if (val === null || val === undefined) return "";
      if (col.format === "currency") return Number(val);
      if (col.format === "percentage") return `${val}%`;
      if (col.format === "date" && typeof val === "string") {
        return val.split("T")[0]; // YYYY-MM-DD
      }
      return val;
    })
  );

  // Create workbook
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);

  // Set column widths
  ws["!cols"] = columns.map((c) => ({ wch: c.width || 16 }));

  // Format currency columns
  columns.forEach((col, i) => {
    if (col.format === "currency") {
      for (let r = 1; r <= rows.length; r++) {
        const cell = ws[XLSX.utils.encode_cell({ r, c: i })];
        if (cell) cell.z = "#,##0.00";
      }
    }
  });

  // Add summary sheet
  const summaryRows = Object.entries(report.summary).map(([key, value]) => {
    const label = key
      .replace(/_/g, " ")
      .replace(/\b\w/g, (l) => l.toUpperCase());
    if (typeof value === "object" && value !== null) {
      return [label, JSON.stringify(value)];
    }
    return [label, value];
  });

  const summaryWs = XLSX.utils.aoa_to_sheet([
    ["Report Summary"],
    ["Generated", new Date(report.generated_at).toLocaleString()],
    ["Report Type", report.report_type.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())],
    [],
    ...summaryRows,
  ]);
  summaryWs["!cols"] = [{ wch: 24 }, { wch: 40 }];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Data");
  XLSX.utils.book_append_sheet(wb, summaryWs, "Summary");

  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// ─── PDF Export ───────────────────────────────────────────────────────

export async function exportToPdf(
  report: ReportResponse,
  columns: ReportColumn[],
  filename: string,
  title: string
) {
  const { default: jsPDF } = await import("jspdf");
  const { default: autoTable } = await import("jspdf-autotable");

  const doc = new jsPDF({ orientation: columns.length > 6 ? "landscape" : "portrait" });

  // Title
  doc.setFontSize(16);
  doc.setTextColor(30, 58, 95); // Dark blue
  doc.text(title, 14, 20);

  // Subtitle with generated date
  doc.setFontSize(9);
  doc.setTextColor(107, 114, 128); // Gray
  doc.text(
    `Generated: ${new Date(report.generated_at).toLocaleString("en-NG")}`,
    14,
    28
  );

  // Summary section
  let yPos = 36;
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  const summaryEntries = Object.entries(report.summary).filter(
    ([, v]) => typeof v !== "object"
  );
  for (const [key, value] of summaryEntries) {
    const label = key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
    doc.setFont("helvetica", "bold");
    doc.text(`${label}: `, 14, yPos);
    doc.setFont("helvetica", "normal");
    const formattedVal = typeof value === "number" && key.includes("amount" || "collected" || "outstanding")
      ? `₦${Number(value).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`
      : String(value);
    doc.text(formattedVal, 60, yPos);
    yPos += 6;
  }

  // Data table
  const headers = columns.map((c) => c.label);
  const rows = report.data.map((row) =>
    columns.map((col) => {
      const val = row[col.key];
      if (val === null || val === undefined) return "";
      if (col.format === "currency") {
        return `₦${Number(val).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
      }
      if (col.format === "percentage") return `${val}%`;
      if (col.format === "date" && typeof val === "string") {
        const d = new Date(val);
        return d.toLocaleDateString("en-NG");
      }
      return String(val);
    })
  );

  autoTable(doc, {
    startY: yPos + 4,
    head: [headers],
    body: rows,
    theme: "striped",
    headStyles: {
      fillColor: [30, 64, 175], // Blue
      textColor: 255,
      fontSize: 8,
      fontStyle: "bold",
    },
    bodyStyles: { fontSize: 7 },
    alternateRowStyles: { fillColor: [243, 244, 246] },
    margin: { left: 14, right: 14 },
    styles: { cellPadding: 2 },
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7);
    doc.setTextColor(156, 163, 175);
    doc.text(
      `School Manager — Page ${i} of ${pageCount}`,
      doc.internal.pageSize.getWidth() / 2,
      doc.internal.pageSize.getHeight() - 8,
      { align: "center" }
    );
  }

  doc.save(`${filename}.pdf`);
}

// ─── Column definitions per report type ───────────────────────────────

export const REPORT_COLUMNS: Record<string, ReportColumn[]> = {
  attendance: [
    { key: "student_name", label: "Student Name", width: 24 },
    { key: "admission_number", label: "Adm No.", width: 12 },
    { key: "class_name", label: "Class", width: 14 },
    { key: "total_days", label: "Total Days", format: "number", width: 10 },
    { key: "present", label: "Present", format: "number", width: 10 },
    { key: "absent", label: "Absent", format: "number", width: 10 },
    { key: "late", label: "Late", format: "number", width: 10 },
    { key: "attendance_rate", label: "Rate (%)", format: "percentage", width: 10 },
  ],
  grades: [
    { key: "student_name", label: "Student Name", width: 24 },
    { key: "admission_number", label: "Adm No.", width: 12 },
    { key: "class_name", label: "Class", width: 14 },
    { key: "overall_average", label: "Overall Avg (%)", format: "percentage", width: 14 },
  ],
  enrollment: [
    { key: "class_name", label: "Class", width: 18 },
    { key: "level", label: "Level", width: 12 },
    { key: "enrolled", label: "Enrolled", format: "number", width: 10 },
    { key: "male", label: "Male", format: "number", width: 10 },
    { key: "female", label: "Female", format: "number", width: 10 },
    { key: "capacity", label: "Capacity", format: "number", width: 10 },
    { key: "utilization", label: "Utilization (%)", format: "percentage", width: 14 },
  ],
  fee_collection: [
    { key: "student_name", label: "Student Name", width: 24 },
    { key: "admission_number", label: "Adm No.", width: 12 },
    { key: "amount", label: "Amount", format: "currency", width: 14 },
    { key: "payment_method", label: "Method", width: 12 },
    { key: "payment_date", label: "Date", format: "date", width: 14 },
    { key: "receipt_number", label: "Receipt", width: 16 },
  ],
  outstanding_fees: [
    { key: "student_name", label: "Student Name", width: 24 },
    { key: "admission_number", label: "Adm No.", width: 12 },
    { key: "class_name", label: "Class", width: 14 },
    { key: "total_amount", label: "Total Due", format: "currency", width: 14 },
    { key: "amount_paid", label: "Paid", format: "currency", width: 14 },
    { key: "balance", label: "Balance", format: "currency", width: 14 },
    { key: "aging_bucket", label: "Aging", width: 12 },
    { key: "status", label: "Status", width: 10 },
  ],
};

export const REPORT_TITLES: Record<string, string> = {
  attendance: "Attendance Report",
  grades: "Academic Performance Report",
  enrollment: "Enrollment Report",
  fee_collection: "Fee Collection Report",
  outstanding_fees: "Outstanding Fees Report",
};
