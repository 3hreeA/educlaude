import { useQuery } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export type ReportType = "attendance" | "grades" | "enrollment" | "fee_collection" | "outstanding_fees";

export interface ReportFilters {
  type: ReportType;
  class_id?: string;
  term_id?: string;
  date_from?: string;
  date_to?: string;
}

export interface ReportResponse {
  report_type: string;
  generated_at: string;
  filters?: Record<string, unknown>;
  summary: Record<string, unknown>;
  data: Record<string, unknown>[];
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useReport(filters: ReportFilters | null) {
  return useQuery({
    queryKey: ["report", filters],
    queryFn: () =>
      apiFetch<ReportResponse>(
        buildUrl("/api/reports", filters as Record<string, string>)
      ),
    enabled: !!filters,
    staleTime: 0, // Always refetch reports
  });
}
