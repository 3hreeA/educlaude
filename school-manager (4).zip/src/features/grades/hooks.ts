import { useQuery } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface AssessmentGrade {
  id: string;
  name: string;
  max_score: number;
  weight: number;
  date: string;
  student_score: number | null;
  class_average: number | null;
  percentage: number | null;
}

export interface SubjectGrades {
  id: string;
  name: string;
  code: string;
  assessments: AssessmentGrade[];
  average: number | null;
  class_average: number | null;
}

export interface GradesData {
  subjects: SubjectGrades[];
  overall_average: number | null;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useStudentGrades(studentId: string, termId?: string | null) {
  return useQuery({
    queryKey: ["grades", studentId, termId],
    queryFn: () =>
      apiFetch<GradesData>(
        buildUrl(`/api/grades/student/${studentId}`, {
          term_id: termId,
        })
      ),
    enabled: !!studentId,
  });
}
