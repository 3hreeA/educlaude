import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface AnnouncementItem {
  id: string;
  title: string;
  content: string;
  priority: string;
  status: string;
  target_roles: string[];
  delivery_channels: string[];
  scheduled_at: string | null;
  published_at: string | null;
  expires_at: string | null;
  created_at: string;
  published_by: string;
}

export interface AnnouncementsResponse {
  announcements: AnnouncementItem[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    total_pages: number;
  };
}

export interface AnnouncementDetail extends AnnouncementItem {
  target_classes: string[] | null;
  updated_at: string;
  published_by_name: string;
  delivery_stats: {
    total: number;
    by_channel: Record<string, { sent: number; failed: number }>;
  } | null;
}

export interface CreateAnnouncementInput {
  title: string;
  content: string;
  priority?: string;
  target_roles?: string[];
  target_classes?: string[];
  delivery_channels?: string[];
  scheduled_at?: string | null;
  expires_at?: string | null;
  status?: "draft" | "published";
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useAnnouncements(page = 1, limit = 20, status?: string) {
  return useQuery({
    queryKey: ["announcements", page, limit, status],
    queryFn: () =>
      apiFetch<AnnouncementsResponse>(
        buildUrl("/api/announcements", { page, limit, status })
      ),
  });
}

export function useAnnouncementDetail(id: string | null) {
  return useQuery({
    queryKey: ["announcement", id],
    queryFn: () => apiFetch<AnnouncementDetail>(`/api/announcements/${id}`),
    enabled: !!id,
  });
}

export function useCreateAnnouncement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateAnnouncementInput) =>
      apiFetch("/api/announcements", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function useUpdateAnnouncement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: { id: string } & Record<string, unknown>) =>
      apiFetch(`/api/announcements/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function usePublishAnnouncement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiFetch(`/api/announcements/${id}`, {
        method: "PUT",
        body: JSON.stringify({ action: "publish" }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function useArchiveAnnouncement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiFetch(`/api/announcements/${id}`, {
        method: "PUT",
        body: JSON.stringify({ action: "archive" }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}

export function useDeleteAnnouncement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiFetch(`/api/announcements/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["announcements"] });
    },
  });
}
