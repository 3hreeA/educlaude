import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface TeacherClass {
  id: string;
  name: string;
  level: string;
  is_class_teacher: boolean;
  subjects: { id: string; name: string; code: string }[];
  student_count: number;
  attendance_marked_today: boolean;
}

export interface ClassStudent {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: string;
  photo_url: string | null;
  medical_notes: string | null;
}

export interface AttendanceEntry {
  student_id: string;
  status: "present" | "absent" | "late" | "excused";
  notes?: string;
}

export interface ExistingAttendance {
  id: string;
  student_id: string;
  status: "present" | "absent" | "late" | "excused";
  notes: string | null;
}

export interface TeacherAssessment {
  id: string;
  name: string;
  max_score: number;
  weight: number;
  date: string;
  subject: { id: string; name: string; code: string } | null;
  class: { id: string; name: string } | null;
  grades_entered: number;
  total_students: number;
  is_complete: boolean;
}

export interface StudentGradeEntry {
  student_id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  photo_url: string | null;
  score: number | null;
  remarks: string | null;
}

export interface AssessmentWithGrades {
  assessment: {
    id: string;
    name: string;
    max_score: number;
    weight: number;
    date: string;
    subject: { id: string; name: string } | null;
    class: { id: string; name: string } | null;
  };
  students: StudentGradeEntry[];
}

export interface GradeEntryInput {
  student_id: string;
  score: number;
  remarks?: string;
}

export interface FeedbackInput {
  student_id: string;
  feedback_type: "behavioral" | "academic" | "social" | "attendance";
  category: "positive" | "neutral" | "concern" | "serious";
  description: string;
}

// ─── Query Hooks ───────────────────────────────────────────────────────

export function useTeacherClasses() {
  return useQuery({
    queryKey: ["teacher-classes"],
    queryFn: () => apiFetch<TeacherClass[]>("/api/teachers/classes"),
  });
}

export function useClassStudents(classId: string) {
  return useQuery({
    queryKey: ["class-students", classId],
    queryFn: () => apiFetch<ClassStudent[]>(`/api/teachers/class/${classId}/students`),
    enabled: !!classId,
  });
}

export function useClassAttendance(classId: string, date: string) {
  return useQuery({
    queryKey: ["class-attendance", classId, date],
    queryFn: () =>
      apiFetch<ExistingAttendance[]>(
        buildUrl("/api/attendance/mark", { class_id: classId, date })
      ),
    enabled: !!classId && !!date,
  });
}

export function useTeacherAssessments(classId?: string, subjectId?: string, termId?: string) {
  return useQuery({
    queryKey: ["teacher-assessments", classId, subjectId, termId],
    queryFn: () =>
      apiFetch<TeacherAssessment[]>(
        buildUrl("/api/assessments", {
          class_id: classId,
          subject_id: subjectId,
          term_id: termId,
        })
      ),
  });
}

export function useAssessmentGrades(assessmentId: string) {
  return useQuery({
    queryKey: ["assessment-grades", assessmentId],
    queryFn: () =>
      apiFetch<AssessmentWithGrades>(
        buildUrl("/api/grades/bulk", { assessment_id: assessmentId })
      ),
    enabled: !!assessmentId,
  });
}

// ─── Mutation Hooks ────────────────────────────────────────────────────

export function useMarkAttendance() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: { class_id: string; date: string; entries: AttendanceEntry[] }) =>
      apiFetch<{ saved: number; date: string; class_id: string }>("/api/attendance/mark", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["class-attendance", variables.class_id] });
      queryClient.invalidateQueries({ queryKey: ["teacher-classes"] });
    },
  });
}

export function useCreateAssessment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: {
      class_id: string;
      subject_id: string;
      name: string;
      max_score: number;
      weight?: number;
      date: string;
    }) =>
      apiFetch<{ id: string; name: string }>("/api/assessments", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["teacher-assessments"] });
    },
  });
}

export function useBulkGradeEntry() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: { assessment_id: string; grades: GradeEntryInput[] }) =>
      apiFetch<{ saved: number; assessment_id: string }>("/api/grades/bulk", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: ["assessment-grades", variables.assessment_id],
      });
      queryClient.invalidateQueries({ queryKey: ["teacher-assessments"] });
    },
  });
}

export function useSubmitFeedback() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: FeedbackInput) =>
      apiFetch<{ id: string }>("/api/feedback", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["student-feedback"] });
    },
  });
}
