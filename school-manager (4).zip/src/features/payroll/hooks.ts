import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface SalaryStructure {
  id: string;
  teacher_id: string;
  staff_id: string;
  teacher_name: string;
  is_active: boolean;
  basic_salary: number;
  housing_allowance: number;
  transport_allowance: number;
  meal_allowance: number;
  gross_salary: number;
  effective_date: string;
}

export interface PayrollRun {
  id: string;
  month: number;
  year: number;
  status: string;
  processed_at: string | null;
  processed_by_name: string | null;
  staff_count: number;
  total_gross: number;
  total_net: number;
}

export interface PayslipItem {
  id: string;
  teacher_id: string;
  staff_id: string;
  teacher_name: string;
  gross_salary: number;
  tax_paye: number;
  pension: number;
  nhf: number;
  other_deductions: number;
  net_salary: number;
  bank_name: string | null;
  account_number: string | null;
}

export interface PayrollDetail {
  run: { id: string; month: number; year: number; status: string; processed_at: string | null };
  payslips: PayslipItem[];
  summary: {
    staff_count: number;
    total_gross: number;
    total_paye: number;
    total_pension: number;
    total_nhf: number;
    total_net: number;
  };
}

export interface ReconciliationTransaction {
  id: string;
  amount: number;
  payment_method: string;
  payment_reference: string;
  gateway_reference: string | null;
  status: string;
  receipt_number: string | null;
  created_at: string;
  student_name: string;
  admission_number: string;
  fee_name: string;
  reconciled: boolean;
}

export interface ReconciliationData {
  date: string;
  transactions: ReconciliationTransaction[];
  summary: {
    total_transactions: number;
    successful_count: number;
    successful_amount: number;
    pending_count: number;
    pending_amount: number;
    failed_count: number;
    method_breakdown: Record<string, { count: number; amount: number }>;
    reconciled: number;
    unreconciled: number;
  };
}

export interface PlanItem {
  id: string;
  number: number;
  due_date: string;
  amount: number;
  paid: boolean;
  paid_at: string | null;
}

export interface PaymentPlan {
  id: string;
  total_amount: number;
  installments: number;
  amount_per_installment: number;
  start_date: string;
  status: string;
  notes: string | null;
  created_at: string;
  student_name: string;
  admission_number: string;
  class_name: string;
  fee_name: string;
  fee_account_balance: number;
  items: PlanItem[];
}

// ─── Salary Hooks ─────────────────────────────────────────────────────

export function useSalaryStructures() {
  return useQuery({
    queryKey: ["salaries"],
    queryFn: () => apiFetch<{ salaries: SalaryStructure[] }>("/api/finance/salary"),
  });
}

export function useSaveSalary() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: {
      teacher_id: string;
      basic_salary: number;
      housing_allowance: number;
      transport_allowance: number;
      meal_allowance: number;
      effective_date?: string;
    }) => apiFetch("/api/finance/salary", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["salaries"] }),
  });
}

// ─── Payroll Hooks ────────────────────────────────────────────────────

export function usePayrollRuns() {
  return useQuery({
    queryKey: ["payroll-runs"],
    queryFn: () => apiFetch<{ runs: PayrollRun[] }>("/api/finance/payroll"),
  });
}

export function usePayrollDetail(runId: string) {
  return useQuery({
    queryKey: ["payroll-detail", runId],
    queryFn: () => apiFetch<PayrollDetail>(`/api/finance/payroll/${runId}`),
    enabled: !!runId,
  });
}

export function useGeneratePayroll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { month: number; year: number }) =>
      apiFetch<{ run_id: string; payslips_generated: number }>("/api/finance/payroll", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["payroll-runs"] }),
  });
}

export function useApprovePayroll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, action }: { id: string; action: "approve" | "paid" }) =>
      apiFetch(`/api/finance/payroll/${id}`, {
        method: "PUT",
        body: JSON.stringify({ action }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payroll-runs"] });
      qc.invalidateQueries({ queryKey: ["payroll-detail"] });
    },
  });
}

// ─── Reconciliation Hooks ─────────────────────────────────────────────

export function useReconciliation(date: string) {
  return useQuery({
    queryKey: ["reconciliation", date],
    queryFn: () => apiFetch<ReconciliationData>(buildUrl("/api/finance/reconciliation", { date })),
    enabled: !!date,
  });
}

export function useReconcileTransaction() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { transaction_id: string; gateway_reference?: string; notes?: string }) =>
      apiFetch("/api/finance/reconciliation", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reconciliation"] }),
  });
}

// ─── Payment Plans Hooks ──────────────────────────────────────────────

export function usePaymentPlans(status?: string) {
  return useQuery({
    queryKey: ["payment-plans", status],
    queryFn: () => apiFetch<{ plans: PaymentPlan[] }>(buildUrl("/api/finance/payment-plans", { status })),
  });
}

export function useCreatePaymentPlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { fee_account_id: string; installments: number; start_date: string; notes?: string }) =>
      apiFetch("/api/finance/payment-plans", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payment-plans"] });
      qc.invalidateQueries({ queryKey: ["outstanding-fees"] });
    },
  });
}
