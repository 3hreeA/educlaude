import { useQuery } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface AttendanceRecord {
  id: string;
  date: string;
  status: "present" | "absent" | "late" | "excused";
  notes: string | null;
  term_id: string;
}

export interface AttendanceSummary {
  total: number;
  present: number;
  late: number;
  absent: number;
  excused: number;
  percentage: number | null;
  current_streak: number;
  max_consecutive_absent: number;
}

export interface AttendanceData {
  records: AttendanceRecord[];
  summary: AttendanceSummary;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useStudentAttendance(studentId: string, termId?: string | null) {
  return useQuery({
    queryKey: ["attendance", studentId, termId],
    queryFn: () =>
      apiFetch<AttendanceData>(
        buildUrl(`/api/attendance/student/${studentId}`, {
          term_id: termId,
        })
      ),
    enabled: !!studentId,
  });
}
