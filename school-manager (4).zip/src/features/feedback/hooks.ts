import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface FeedbackEntry {
  id: string;
  type: string;
  category: string;
  description: string;
  date: string;
  teacher_name: string;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useStudentFeedback(studentId: string) {
  return useQuery({
    queryKey: ["feedback", studentId],
    queryFn: () =>
      apiFetch<FeedbackEntry[]>(`/api/feedback/student/${studentId}`),
    enabled: !!studentId,
  });
}
