import { useQuery } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface ChildSummary {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: string;
  date_of_birth: string;
  photo_url: string | null;
  class_name: string;
  class_level: string;
  attendance_percentage: number | null;
  fee_balance: number;
  fee_status: string | null;
}

export interface StudentDetail {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: string;
  date_of_birth: string;
  photo_url: string | null;
  blood_group: string | null;
  genotype: string | null;
  medical_notes: string | null;
  address: string | null;
  is_active: boolean;
  admission_date: string;
  classes: {
    id: string;
    name: string;
    level: string;
    arm: string | null;
  } | null;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useMyChildren() {
  return useQuery({
    queryKey: ["my-children"],
    queryFn: () => apiFetch<ChildSummary[]>("/api/students/my-children"),
  });
}

export function useStudent(studentId: string) {
  return useQuery({
    queryKey: ["student", studentId],
    queryFn: () => apiFetch<StudentDetail>(`/api/students/${studentId}`),
    enabled: !!studentId,
  });
}
