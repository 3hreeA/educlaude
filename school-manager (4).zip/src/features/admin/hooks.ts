import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface AdminStats {
  total_students: number;
  total_teachers: number;
  total_classes: number;
  attendance_today: number | null;
  pending_incidents: number;
  active_announcements: number;
}

export interface AdminStudent {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: string;
  date_of_birth: string;
  photo_url: string | null;
  is_active: boolean;
  admission_date: string;
  classes: { id: string; name: string; level: string; arm: string | null } | null;
}

export interface AdminStudentList {
  students: AdminStudent[];
  pagination: { page: number; limit: number; total: number; total_pages: number };
}

export interface AdminClass {
  id: string;
  name: string;
  level: string;
  arm: string | null;
  capacity: number;
  student_count: number;
}

export interface RegisterStudentInput {
  first_name: string;
  last_name: string;
  middle_name?: string;
  gender: string;
  date_of_birth: string;
  class_id: string;
  blood_group?: string;
  genotype?: string;
  medical_notes?: string;
  address?: string;
  parent_name?: string;
  parent_email?: string;
  parent_phone?: string;
  parent_relationship?: string;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useAdminStats() {
  return useQuery({
    queryKey: ["admin-stats"],
    queryFn: () => apiFetch<AdminStats>("/api/admin/stats"),
    refetchInterval: 60_000, // refresh every minute
  });
}

export function useAdminStudents(params: {
  search?: string;
  class_id?: string;
  status?: string;
  page?: number;
  limit?: number;
}) {
  return useQuery({
    queryKey: ["admin-students", params],
    queryFn: () =>
      apiFetch<AdminStudentList>(
        buildUrl("/api/admin/students", {
          search: params.search || undefined,
          class_id: params.class_id || undefined,
          status: params.status || "active",
          page: params.page || 1,
          limit: params.limit || 20,
        })
      ),
    placeholderData: (prev) => prev,
  });
}

export function useAdminClasses() {
  return useQuery({
    queryKey: ["admin-classes"],
    queryFn: () => apiFetch<AdminClass[]>("/api/admin/classes"),
  });
}

export function useRegisterStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: RegisterStudentInput) =>
      apiFetch("/api/admin/students", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-students"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
      qc.invalidateQueries({ queryKey: ["admin-classes"] });
    },
  });
}

export function useCreateClass() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { name: string; level: string; arm?: string; capacity?: number }) =>
      apiFetch("/api/admin/classes", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-classes"] });
    },
  });
}

// ─── Student Detail ────────────────────────────────────────────────────

export interface StudentDetail {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: string;
  date_of_birth: string;
  address: string | null;
  blood_group: string | null;
  genotype: string | null;
  medical_notes: string | null;
  photo_url: string | null;
  is_active: boolean;
  admission_date: string;
  classes: { id: string; name: string; level: string; arm: string | null } | null;
  parents?: {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
    phone: string;
    whatsapp_number: string | null;
    relationship: string;
  }[];
  fee_summary?: { total_due: number; total_paid: number; total_balance: number };
}

export function useStudentDetail(studentId: string) {
  return useQuery({
    queryKey: ["student-detail", studentId],
    queryFn: () => apiFetch<StudentDetail>(`/api/students/${studentId}`),
    enabled: !!studentId,
  });
}

export function useUpdateStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: { id: string; [key: string]: unknown }) =>
      apiFetch(`/api/students/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }),
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["student-detail", vars.id] });
      qc.invalidateQueries({ queryKey: ["admin-students"] });
    },
  });
}

// ─── Teacher Management ───────────────────────────────────────────────

export interface AdminTeacher {
  id: string;
  user_id: string;
  staff_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  avatar_url: string | null;
  is_active: boolean;
  qualification: string | null;
  specialization: string | null;
  date_joined: string;
  is_class_teacher: boolean;
  classes_count: number;
  attendance_rate: number | null;
  attendance_days: { total: number; present: number; late: number; absent: number };
  leave_summary: { pending: number; approved: number; total: number };
}

export interface TeacherDetail {
  id: string;
  staff_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  avatar_url: string | null;
  is_active: boolean;
  qualification: string | null;
  specialization: string | null;
  date_joined: string;
  assignments: {
    id: string;
    class: { id: string; name: string; level: string } | null;
    subject: { id: string; name: string; code: string } | null;
    is_class_teacher: boolean;
  }[];
  attendance: {
    stats: { total: number; present: number; late: number; absent: number; excused: number; half_day: number };
    rate: number | null;
    recent: { date: string; status: string; check_in: string | null; check_out: string | null; notes: string | null }[];
  };
  leaves: {
    id: string;
    leave_type: string;
    start_date: string;
    end_date: string;
    days_count: number;
    reason: string;
    status: string;
    created_at: string;
  }[];
}

export function useAdminTeachers(search?: string) {
  return useQuery({
    queryKey: ["admin-teachers", search],
    queryFn: () =>
      apiFetch<{ teachers: AdminTeacher[] }>(
        buildUrl("/api/admin/teachers", { search: search || undefined })
      ),
  });
}

export function useTeacherDetail(teacherId: string) {
  return useQuery({
    queryKey: ["teacher-detail", teacherId],
    queryFn: () => apiFetch<TeacherDetail>(`/api/admin/teachers/${teacherId}`),
    enabled: !!teacherId,
  });
}

// ─── Teacher Attendance (Admin marks) ─────────────────────────────────

export interface TeacherAttendanceEntry {
  teacher_id: string;
  staff_id: string;
  name: string;
  status: string | null;
  check_in: string | null;
  check_out: string | null;
  notes: string | null;
}

export function useTeacherAttendance(date: string) {
  return useQuery({
    queryKey: ["teacher-attendance", date],
    queryFn: () =>
      apiFetch<{ date: string; teachers: TeacherAttendanceEntry[] }>(
        buildUrl("/api/admin/teacher-attendance", { date })
      ),
    enabled: !!date,
  });
}

export function useMarkTeacherAttendance() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { date: string; entries: { teacher_id: string; status: string; notes?: string }[] }) =>
      apiFetch("/api/admin/teacher-attendance", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["teacher-attendance"] });
      qc.invalidateQueries({ queryKey: ["admin-teachers"] });
    },
  });
}

// ─── Leave Management ─────────────────────────────────────────────────

export interface LeaveItem {
  id: string;
  teacher_id: string;
  teacher_name: string;
  staff_id: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  days_count: number;
  reason: string;
  status: string;
  review_notes: string | null;
  reviewed_by_name: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export function useLeaveRequests(status?: string) {
  return useQuery({
    queryKey: ["leave-requests", status],
    queryFn: () =>
      apiFetch<{ leaves: LeaveItem[] }>(
        buildUrl("/api/leave", { status: status || undefined })
      ),
  });
}

export function useReviewLeave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, action, review_notes }: { id: string; action: "approved" | "rejected"; review_notes?: string }) =>
      apiFetch(`/api/leave/${id}`, {
        method: "PUT",
        body: JSON.stringify({ action, review_notes }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leave-requests"] });
      qc.invalidateQueries({ queryKey: ["admin-teachers"] });
    },
  });
}
