"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { UserProfile, UserRole } from "@/types/database";
import { ROLE_DASHBOARDS } from "@/types/api";

export function useAuth() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    async function getUser() {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          setLoading(false);
          return;
        }

        const { data: profile } = await supabase
          .from("users")
          .select("*")
          .eq("auth_id", session.user.id)
          .single();

        setUser(profile as UserProfile | null);
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    }

    getUser();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === "SIGNED_OUT") {
        setUser(null);
        router.push("/login");
      }
      if (event === "SIGNED_IN" && session) {
        const { data: profile } = await supabase
          .from("users")
          .select("*")
          .eq("auth_id", session.user.id)
          .single();
        setUser(profile as UserProfile | null);
      }
    });

    return () => subscription.unsubscribe();
  }, [supabase, router]);

  const login = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;

    const { data: profile } = await supabase
      .from("users")
      .select("*")
      .eq("auth_id", data.user.id)
      .single();

    if (!profile) throw new Error("User profile not found. Contact your school administrator.");

    setUser(profile as UserProfile);

    // Route to role-based dashboard
    const dashboard = ROLE_DASHBOARDS[profile.role as UserRole];
    router.push(dashboard);
    router.refresh();
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    router.push("/login");
    router.refresh();
  };

  return { user, loading, login, logout };
}
