import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface IncidentItem {
  id: string;
  severity: string;
  status: string;
  category: string;
  description: string;
  action_taken: string | null;
  parent_notified: boolean;
  follow_up_date: string | null;
  created_at: string;
  student_name: string;
  student_admission: string;
  student_id: string;
  class_name: string;
  reported_by_name: string;
}

export interface IncidentsResponse {
  incidents: IncidentItem[];
  pagination: { page: number; limit: number; total: number; total_pages: number };
}

export interface CreateIncidentInput {
  student_id: string;
  severity: string;
  category: string;
  description: string;
  action_taken?: string;
  follow_up_date?: string;
}

export interface UpdateIncidentInput {
  id: string;
  status?: string;
  action_taken?: string;
  follow_up_date?: string;
  follow_up_notes?: string;
  parent_notified?: boolean;
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useIncidents(params: {
  page?: number; status?: string; severity?: string; student_id?: string;
}) {
  return useQuery({
    queryKey: ["incidents", params],
    queryFn: () =>
      apiFetch<IncidentsResponse>(
        buildUrl("/api/admin/disciplinary", {
          page: params.page || 1,
          status: params.status || undefined,
          severity: params.severity || undefined,
          student_id: params.student_id || undefined,
        })
      ),
  });
}

export function useCreateIncident() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateIncidentInput) =>
      apiFetch("/api/admin/disciplinary", {
        method: "POST",
        body: JSON.stringify(input),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["incidents"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
    },
  });
}

export function useUpdateIncident() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: UpdateIncidentInput) =>
      apiFetch(`/api/admin/disciplinary/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["incidents"] });
    },
  });
}
