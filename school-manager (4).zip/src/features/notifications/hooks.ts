import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  type: string;
  data: Record<string, unknown> | null;
  read_at: string | null;
  sent_via: string[];
  created_at: string;
}

interface NotificationsResponse {
  notifications: NotificationItem[];
  unread_count: number;
  pagination: {
    page: number;
    limit: number;
    total: number;
    total_pages: number;
  };
}

// ─── Hooks ─────────────────────────────────────────────────────────────

/** Fetch paginated notifications (all or unread only) */
export function useNotifications(page = 1, limit = 20, unreadOnly = false) {
  return useQuery({
    queryKey: ["notifications", page, limit, unreadOnly],
    queryFn: () =>
      apiFetch<NotificationsResponse>(
        buildUrl("/api/notifications", {
          page: String(page),
          limit: String(limit),
          ...(unreadOnly ? { unread: "true" } : {}),
        })
      ),
  });
}

/** Lightweight hook — just the unread count for the badge.
 *  Polls every 60 seconds to keep the count fresh. */
export function useUnreadCount() {
  return useQuery({
    queryKey: ["notifications", "unread-count"],
    queryFn: () =>
      apiFetch<NotificationsResponse>(
        buildUrl("/api/notifications", { limit: "1", unread: "true" })
      ).then((r) => r.unread_count),
    refetchInterval: 60_000, // poll every minute
    staleTime: 30_000,
  });
}

/** Mark specific notifications (or all) as read */
export function useMarkNotificationsRead() {
  const qc = useQueryClient();

  return useMutation({
    mutationFn: (notificationIds?: string[]) =>
      apiFetch<{ success: boolean; unread_count: number }>("/api/notifications", {
        method: "PATCH",
        body: JSON.stringify({ notification_ids: notificationIds }),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
}
