import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

// ─── Types ─────────────────────────────────────────────────────────────

export interface FinanceStats {
  total_revenue: number;
  this_month_revenue: number;
  total_outstanding: number;
  overdue_count: number;
  total_accounts: number;
  paid_accounts: number;
  collection_rate: number;
}

export interface FeeType {
  id: string;
  name: string;
  description: string | null;
  is_recurring: boolean;
  created_at: string;
}

export interface FeeStructureItem {
  id: string;
  amount: number;
  fee_types: { id: string; name: string } | null;
}

export interface FeeStructure {
  id: string;
  name: string;
  total_amount: number;
  due_date: string;
  created_at: string;
  terms: { id: string; name: string } | null;
  academic_years: { id: string; name: string } | null;
  classes: { id: string; name: string; level: string } | null;
  fee_structure_items: FeeStructureItem[];
  assigned_students: number;
}

export interface OutstandingAccount {
  id: string;
  total_amount: number;
  amount_paid: number;
  balance: number;
  status: string;
  due_date: string;
  students: {
    id: string;
    admission_number: string;
    first_name: string;
    last_name: string;
    photo_url: string | null;
    classes: { id: string; name: string; level: string } | null;
  } | null;
  fee_structures: { id: string; name: string; terms: { name: string } | null } | null;
}

export interface OutstandingData {
  accounts: OutstandingAccount[];
  summary: {
    current: number;
    days_30: number;
    days_60: number;
    days_90_plus: number;
    total: number;
  };
  pagination: { page: number; limit: number; total: number; total_pages: number };
}

export interface PaymentRecord {
  id: string;
  amount: number;
  payment_method: string;
  payment_reference: string;
  gateway_reference: string | null;
  status: string;
  receipt_number: string | null;
  created_at: string;
  metadata: Record<string, unknown> | null;
  student_fee_accounts: {
    id: string;
    students: {
      id: string;
      first_name: string;
      last_name: string;
      admission_number: string;
      classes: { name: string } | null;
    } | null;
    fee_structures: { name: string } | null;
  } | null;
}

export interface PaymentsData {
  payments: PaymentRecord[];
  pagination: { page: number; limit: number; total: number; total_pages: number };
}

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useFinanceStats() {
  return useQuery({
    queryKey: ["finance-stats"],
    queryFn: () => apiFetch<FinanceStats>("/api/finance/stats"),
    refetchInterval: 60_000,
  });
}

export function useFeeTypes() {
  return useQuery({
    queryKey: ["fee-types"],
    queryFn: () => apiFetch<FeeType[]>("/api/finance/fee-types"),
  });
}

export function useCreateFeeType() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { name: string; description?: string; is_recurring?: boolean }) =>
      apiFetch("/api/finance/fee-types", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["fee-types"] }),
  });
}

export function useFeeStructures(params?: { term_id?: string; class_id?: string }) {
  return useQuery({
    queryKey: ["fee-structures", params],
    queryFn: () =>
      apiFetch<FeeStructure[]>(
        buildUrl("/api/finance/fee-structures", params)
      ),
  });
}

export function useCreateFeeStructure() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: {
      name: string;
      class_id?: string;
      term_id: string;
      due_date: string;
      items: { fee_type_id: string; amount: number }[];
    }) => apiFetch("/api/finance/fee-structures", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["fee-structures"] });
      qc.invalidateQueries({ queryKey: ["finance-stats"] });
    },
  });
}

export function useOutstandingFees(params?: { class_id?: string; aging?: string; page?: number }) {
  return useQuery({
    queryKey: ["outstanding-fees", params],
    queryFn: () =>
      apiFetch<OutstandingData>(buildUrl("/api/finance/outstanding", params)),
    placeholderData: (prev) => prev,
  });
}

export function useFinancePayments(params?: { status?: string; method?: string; page?: number }) {
  return useQuery({
    queryKey: ["finance-payments", params],
    queryFn: () =>
      apiFetch<PaymentsData>(buildUrl("/api/finance/payments", params)),
    placeholderData: (prev) => prev,
  });
}

export function useAssignFeeAccounts() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { fee_structure_id: string; class_id?: string }) =>
      apiFetch("/api/finance/fee-accounts/assign", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["outstanding-fees"] });
      qc.invalidateQueries({ queryKey: ["finance-stats"] });
      qc.invalidateQueries({ queryKey: ["fee-structures"] });
    },
  });
}

// Parent payment hooks
export function useInitializePayment() {
  return useMutation({
    mutationFn: (input: { fee_account_id: string; amount: number }) =>
      apiFetch<{ authorization_url: string; reference: string }>(
        "/api/payments/initialize",
        { method: "POST", body: JSON.stringify(input) }
      ),
  });
}

export function useVerifyPayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: { reference: string }) =>
      apiFetch<{ status: string; receipt_number: string | null; amount: number }>(
        "/api/payments/verify",
        { method: "POST", body: JSON.stringify(input) }
      ),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["fees"] });
      qc.invalidateQueries({ queryKey: ["my-children"] });
      qc.invalidateQueries({ queryKey: ["finance-stats"] });
    },
  });
}
