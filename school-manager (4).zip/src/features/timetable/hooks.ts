import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch, buildUrl } from "@/lib/utils/api-client";

export interface TimetableSlot {
  id: string;
  day_of_week: number;
  day_name: string;
  start_time: string;
  end_time: string;
  room: string | null;
  class_name: string;
  class_id: string;
  subject_name: string;
  subject_id: string | null;
  teacher_name: string;
  teacher_id: string | null;
}

export interface TimetableData {
  slots: TimetableSlot[];
  by_day: Record<number, TimetableSlot[]>;
}

export function useTimetable(params?: { class_id?: string; teacher_id?: string }) {
  return useQuery({
    queryKey: ["timetable", params],
    queryFn: () => apiFetch<TimetableData>(buildUrl("/api/admin/timetable", params)),
    enabled: !!(params?.class_id || params?.teacher_id),
  });
}

export function useCreateSlot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: {
      class_id: string;
      subject_id?: string;
      teacher_id?: string;
      day_of_week: number;
      start_time: string;
      end_time: string;
      room?: string;
      term_id?: string;
    }) => apiFetch("/api/admin/timetable", { method: "POST", body: JSON.stringify(input) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["timetable"] }),
  });
}

export function useDeleteSlot() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiFetch(`/api/admin/timetable?id=${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["timetable"] }),
  });
}
