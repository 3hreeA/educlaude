// Barrel export — ensures `import { cn } from "@/lib/utils"` works
export { cn } from "./utils/cn";
