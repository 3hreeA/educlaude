// ============================================================================
// School Manager — SMS Integration (Termii)
// https://developers.termii.com/
// ============================================================================

interface TermiiConfig {
  apiKey: string;
  senderId: string;
  baseUrl: string;
  enabled: boolean;
}

interface SmsMessage {
  to: string; // Nigerian phone: 08012345678 or 2348012345678
  text: string;
}

interface SmsBulkMessage {
  recipients: string[];
  text: string;
}

interface SmsResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

function getConfig(): TermiiConfig {
  return {
    apiKey: process.env.TERMII_API_KEY || "",
    senderId: process.env.TERMII_SENDER_ID || "SchoolMgr",
    baseUrl: process.env.TERMII_BASE_URL || "https://api.ng.termii.com/api",
    enabled: process.env.SMS_ENABLED === "true",
  };
}

/** Normalize Nigerian phone to international format without + */
function normalizePhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, "");
  if (cleaned.startsWith("234")) return cleaned;
  if (cleaned.startsWith("0")) return `234${cleaned.slice(1)}`;
  return cleaned;
}

/** Send a single SMS */
export async function sendSms(msg: SmsMessage): Promise<SmsResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log("[SMS] Disabled — skipping SMS to", msg.to);
    return { success: true, messageId: `sms-disabled-${Date.now()}` };
  }

  try {
    const res = await fetch(`${config.baseUrl}/sms/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: normalizePhone(msg.to),
        from: config.senderId,
        sms: msg.text,
        type: "plain",
        channel: "generic",
        api_key: config.apiKey,
      }),
    });

    const data = await res.json();
    if (data.code !== "ok" && res.status !== 200) {
      return {
        success: false,
        error: data.message || `Termii error: ${res.status}`,
      };
    }

    return {
      success: true,
      messageId: data.message_id || data.message_id_str || "sent",
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

/** Send bulk SMS to multiple recipients (same message) */
export async function sendBulkSms(msg: SmsBulkMessage): Promise<SmsResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log(
      "[SMS] Disabled — skipping bulk SMS to",
      msg.recipients.length,
      "recipients"
    );
    return { success: true, messageId: `sms-bulk-disabled-${Date.now()}` };
  }

  // Termii supports bulk via the same endpoint with comma-separated numbers
  // For large batches, chunk into groups of 100
  const normalized = msg.recipients.map(normalizePhone);
  const chunks: string[][] = [];
  for (let i = 0; i < normalized.length; i += 100) {
    chunks.push(normalized.slice(i, i + 100));
  }

  const errors: string[] = [];
  for (const chunk of chunks) {
    try {
      const res = await fetch(`${config.baseUrl}/sms/send/bulk`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: chunk,
          from: config.senderId,
          sms: msg.text,
          type: "plain",
          channel: "generic",
          api_key: config.apiKey,
        }),
      });

      const data = await res.json();
      if (data.code !== "ok" && res.status !== 200) {
        errors.push(data.message || `Chunk failed: ${res.status}`);
      }
    } catch (err) {
      errors.push(err instanceof Error ? err.message : "Unknown error");
    }
  }

  return {
    success: errors.length === 0,
    messageId: `bulk-${Date.now()}`,
    error: errors.length > 0 ? errors.join("; ") : undefined,
  };
}

/** Truncate text to SMS-safe length (160 chars for single SMS, 306 for 2-part) */
export function truncateForSms(text: string, maxParts = 2): string {
  const limit = maxParts === 1 ? 160 : 306;
  if (text.length <= limit) return text;
  return text.slice(0, limit - 3) + "...";
}

/** Build announcement SMS text */
export function buildAnnouncementSms(
  title: string,
  content: string,
  schoolName: string
): string {
  const header = `${schoolName}: ${title}`;
  const remaining = 300 - header.length - 3; // leave room for newlines
  const body =
    content.length > remaining
      ? content.slice(0, remaining - 3) + "..."
      : content;
  return `${header}\n\n${body}`;
}

/** Build fee reminder SMS */
export function buildFeeReminderSms(
  studentName: string,
  amount: string,
  dueDate: string
): string {
  return truncateForSms(
    `Fee Reminder: ${studentName}'s balance of ${amount} is due ${dueDate}. Please pay promptly. Thank you.`
  );
}
