// ============================================================================
// School Manager — WhatsApp Business API Integration
// Uses the Cloud API (via Meta or providers like 360dialog / Twilio)
// ============================================================================

interface WhatsAppConfig {
  apiUrl: string;
  accessToken: string;
  phoneNumberId: string;
  enabled: boolean;
}

interface WhatsAppTemplateMessage {
  to: string; // Phone number in international format: 2348012345678
  templateName: string;
  languageCode?: string;
  components?: Array<{
    type: "body" | "header";
    parameters: Array<{ type: "text"; text: string }>;
  }>;
}

interface WhatsAppTextMessage {
  to: string;
  text: string;
}

interface WhatsAppResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

function getConfig(): WhatsAppConfig {
  return {
    apiUrl:
      process.env.WHATSAPP_API_URL ||
      "https://graph.facebook.com/v18.0",
    accessToken: process.env.WHATSAPP_ACCESS_TOKEN || "",
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || "",
    enabled: process.env.WHATSAPP_ENABLED === "true",
  };
}

/** Normalize Nigerian phone numbers to international format */
function normalizePhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, "");
  if (cleaned.startsWith("234")) return cleaned;
  if (cleaned.startsWith("0")) return `234${cleaned.slice(1)}`;
  return cleaned;
}

/** Send a template message (pre-approved by WhatsApp) */
export async function sendWhatsAppTemplate(
  msg: WhatsAppTemplateMessage
): Promise<WhatsAppResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log("[WhatsApp] Disabled — skipping template to", msg.to);
    return { success: true, messageId: `wa-disabled-${Date.now()}` };
  }

  try {
    const url = `${config.apiUrl}/${config.phoneNumberId}/messages`;
    const body: Record<string, unknown> = {
      messaging_product: "whatsapp",
      to: normalizePhone(msg.to),
      type: "template",
      template: {
        name: msg.templateName,
        language: { code: msg.languageCode || "en" },
        ...(msg.components && { components: msg.components }),
      },
    };

    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    const data = await res.json();
    if (!res.ok) {
      return {
        success: false,
        error: data.error?.message || `HTTP ${res.status}`,
      };
    }

    return {
      success: true,
      messageId: data.messages?.[0]?.id || "unknown",
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

/** Send a plain text message (for non-template use cases) */
export async function sendWhatsAppText(
  msg: WhatsAppTextMessage
): Promise<WhatsAppResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log("[WhatsApp] Disabled — skipping text to", msg.to);
    return { success: true, messageId: `wa-disabled-${Date.now()}` };
  }

  try {
    const url = `${config.apiUrl}/${config.phoneNumberId}/messages`;
    const body = {
      messaging_product: "whatsapp",
      to: normalizePhone(msg.to),
      type: "text",
      text: { body: msg.text },
    };

    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    const data = await res.json();
    if (!res.ok) {
      return {
        success: false,
        error: data.error?.message || `HTTP ${res.status}`,
      };
    }

    return {
      success: true,
      messageId: data.messages?.[0]?.id || "unknown",
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

// ─── Pre-defined templates ────────────────────────────────────────────

export function buildAnnouncementMessage(
  title: string,
  content: string,
  schoolName: string
): WhatsAppTemplateMessage & { text: string } {
  // Truncate for WhatsApp (1024 char limit for template body params)
  const truncated =
    content.length > 500 ? content.slice(0, 497) + "..." : content;
  return {
    to: "", // caller fills this
    templateName: "school_announcement",
    components: [
      {
        type: "body",
        parameters: [
          { type: "text", text: schoolName },
          { type: "text", text: title },
          { type: "text", text: truncated },
        ],
      },
    ],
    text: `📢 *${title}*\n\n${truncated}\n\n— ${schoolName}`,
  };
}

export function buildFeeReminderMessage(
  parentName: string,
  studentName: string,
  amount: string,
  dueDate: string
): WhatsAppTemplateMessage & { text: string } {
  return {
    to: "",
    templateName: "fee_reminder",
    components: [
      {
        type: "body",
        parameters: [
          { type: "text", text: parentName },
          { type: "text", text: studentName },
          { type: "text", text: amount },
          { type: "text", text: dueDate },
        ],
      },
    ],
    text: `Dear ${parentName},\n\nThis is a reminder that ${studentName}'s school fee balance of ${amount} is due on ${dueDate}. Please make payment promptly.\n\nThank you.`,
  };
}
