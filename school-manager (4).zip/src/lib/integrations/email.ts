// ============================================================================
// School Manager — Email Integration (SendGrid / SMTP fallback)
// ============================================================================

interface EmailConfig {
  provider: "sendgrid" | "smtp";
  sendgridApiKey: string;
  fromEmail: string;
  fromName: string;
  enabled: boolean;
}

interface EmailMessage {
  to: string;
  subject: string;
  html: string;
  text?: string; // plain-text fallback
}

interface EmailBulkMessage {
  recipients: string[];
  subject: string;
  html: string;
  text?: string;
}

interface EmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

function getConfig(): EmailConfig {
  return {
    provider: (process.env.EMAIL_PROVIDER as "sendgrid" | "smtp") || "sendgrid",
    sendgridApiKey: process.env.SENDGRID_API_KEY || "",
    fromEmail: process.env.EMAIL_FROM || "noreply@schoolmanager.ng",
    fromName: process.env.EMAIL_FROM_NAME || "School Manager",
    enabled: process.env.EMAIL_ENABLED === "true",
  };
}

/** Send a single email via SendGrid */
export async function sendEmail(msg: EmailMessage): Promise<EmailResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log("[Email] Disabled — skipping email to", msg.to);
    return { success: true, messageId: `email-disabled-${Date.now()}` };
  }

  try {
    const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.sendgridApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: msg.to }] }],
        from: { email: config.fromEmail, name: config.fromName },
        subject: msg.subject,
        content: [
          ...(msg.text ? [{ type: "text/plain", value: msg.text }] : []),
          { type: "text/html", value: msg.html },
        ],
      }),
    });

    if (res.status === 202 || res.status === 200) {
      return {
        success: true,
        messageId: res.headers.get("x-message-id") || `email-${Date.now()}`,
      };
    }

    const data = await res.json().catch(() => ({}));
    return {
      success: false,
      error: (data as Record<string, unknown>)?.errors
        ? JSON.stringify((data as Record<string, unknown>).errors)
        : `HTTP ${res.status}`,
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

/** Send bulk email (SendGrid supports up to 1000 personalizations per request) */
export async function sendBulkEmail(
  msg: EmailBulkMessage
): Promise<EmailResult> {
  const config = getConfig();
  if (!config.enabled) {
    console.log(
      "[Email] Disabled — skipping bulk email to",
      msg.recipients.length,
      "recipients"
    );
    return { success: true, messageId: `email-bulk-disabled-${Date.now()}` };
  }

  // Chunk into groups of 1000 (SendGrid limit)
  const chunks: string[][] = [];
  for (let i = 0; i < msg.recipients.length; i += 1000) {
    chunks.push(msg.recipients.slice(i, i + 1000));
  }

  const errors: string[] = [];
  for (const chunk of chunks) {
    try {
      const personalizations = chunk.map((email) => ({ to: [{ email }] }));
      const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${config.sendgridApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          personalizations,
          from: { email: config.fromEmail, name: config.fromName },
          subject: msg.subject,
          content: [
            ...(msg.text ? [{ type: "text/plain", value: msg.text }] : []),
            { type: "text/html", value: msg.html },
          ],
        }),
      });

      if (res.status !== 202 && res.status !== 200) {
        errors.push(`Chunk of ${chunk.length} failed: HTTP ${res.status}`);
      }
    } catch (err) {
      errors.push(err instanceof Error ? err.message : "Unknown error");
    }
  }

  return {
    success: errors.length === 0,
    messageId: `email-bulk-${Date.now()}`,
    error: errors.length > 0 ? errors.join("; ") : undefined,
  };
}

// ─── HTML templates ───────────────────────────────────────────────────

export function buildAnnouncementEmail(
  title: string,
  content: string,
  schoolName: string,
  priority: string
): { subject: string; html: string; text: string } {
  const priorityBadge =
    priority === "urgent"
      ? '<span style="background:#ef4444;color:white;padding:2px 8px;border-radius:4px;font-size:12px;">URGENT</span>'
      : priority === "high"
        ? '<span style="background:#f59e0b;color:white;padding:2px 8px;border-radius:4px;font-size:12px;">Important</span>'
        : "";

  return {
    subject: `${priority === "urgent" ? "🚨 " : ""}${schoolName}: ${title}`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
        <div style="background:#1e40af;color:white;padding:20px;text-align:center;">
          <h2 style="margin:0;">${schoolName}</h2>
        </div>
        <div style="padding:24px;background:white;">
          ${priorityBadge ? `<p>${priorityBadge}</p>` : ""}
          <h3 style="color:#1e3a5f;margin-top:0;">${title}</h3>
          <div style="color:#374151;line-height:1.6;">
            ${content.replace(/\n/g, "<br>")}
          </div>
        </div>
        <div style="padding:16px;background:#f3f4f6;text-align:center;font-size:12px;color:#6b7280;">
          <p>This message was sent by ${schoolName} via School Manager.</p>
          <p>If you wish to stop receiving emails, please update your notification preferences in the app.</p>
        </div>
      </div>
    `,
    text: `${schoolName}: ${title}\n\n${content}`,
  };
}
