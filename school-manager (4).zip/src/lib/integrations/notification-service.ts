// ============================================================================
// School Manager — Notification Service (Multi-Channel Orchestrator)
// Coordinates delivery across in-app, WhatsApp, SMS, and email
// ============================================================================

import { createServerSupabaseClient } from "@/lib/supabase/server";
import { sendWhatsAppText } from "./whatsapp";
import { sendSms, buildAnnouncementSms } from "./sms";
import { sendEmail, buildAnnouncementEmail } from "./email";

type Channel = "in_app" | "whatsapp" | "sms" | "email";

interface DeliveryRecipient {
  user_id: string;
  email: string;
  phone: string | null;
  whatsapp_number: string | null;
  first_name: string;
  last_name: string;
}

interface AnnouncementDeliveryRequest {
  announcementId: string;
  title: string;
  content: string;
  priority: string;
  schoolName: string;
  channels: Channel[];
  targetRoles: string[];
  targetClasses?: string[] | null;
  schoolId: string;
}

interface DeliveryResult {
  total: number;
  sent: Record<Channel, number>;
  failed: Record<Channel, number>;
  errors: string[];
}

/**
 * Deliver an announcement to all targeted recipients via specified channels.
 * Creates in-app notifications and dispatches external messages.
 */
export async function deliverAnnouncement(
  req: AnnouncementDeliveryRequest
): Promise<DeliveryResult> {
  const supabase = createServerSupabaseClient();

  const result: DeliveryResult = {
    total: 0,
    sent: { in_app: 0, whatsapp: 0, sms: 0, email: 0 },
    failed: { in_app: 0, whatsapp: 0, sms: 0, email: 0 },
    errors: [],
  };

  // 1. Find target recipients based on roles (and optionally classes)
  let recipientQuery = supabase
    .from("users")
    .select("id, email, phone, first_name, last_name, role")
    .eq("school_id", req.schoolId)
    .eq("is_active", true)
    .in("role", req.targetRoles);

  const { data: users, error: userError } = await recipientQuery;
  if (userError || !users) {
    result.errors.push(`Failed to fetch recipients: ${userError?.message}`);
    return result;
  }

  // If targeting specific classes, further filter parents of students in those classes
  let recipients: DeliveryRecipient[] = users.map((u) => ({
    user_id: u.id,
    email: u.email,
    phone: u.phone,
    whatsapp_number: u.phone, // Same as phone for now
    first_name: u.first_name,
    last_name: u.last_name,
  }));

  result.total = recipients.length;
  if (recipients.length === 0) {
    result.errors.push("No recipients found for target audience");
    return result;
  }

  // 2. Deliver via each channel
  for (const channel of req.channels) {
    switch (channel) {
      case "in_app":
        await deliverInApp(supabase, req, recipients, result);
        break;
      case "whatsapp":
        await deliverWhatsApp(req, recipients, result);
        break;
      case "sms":
        await deliverSmsChannel(req, recipients, result);
        break;
      case "email":
        await deliverEmailChannel(req, recipients, result);
        break;
    }
  }

  // 3. Record delivery results in announcement_deliveries
  const deliveryRecords = [];
  for (const recipient of recipients) {
    for (const channel of req.channels) {
      deliveryRecords.push({
        announcement_id: req.announcementId,
        recipient_id: recipient.user_id,
        channel,
        status: "sent", // simplified — production would track per-recipient
        sent_at: new Date().toISOString(),
      });
    }
  }

  if (deliveryRecords.length > 0) {
    // Insert in batches of 500
    for (let i = 0; i < deliveryRecords.length; i += 500) {
      const batch = deliveryRecords.slice(i, i + 500);
      const { error: insertError } = await supabase
        .from("announcement_deliveries")
        .insert(batch);
      if (insertError) {
        result.errors.push(`Delivery tracking error: ${insertError.message}`);
      }
    }
  }

  return result;
}

// ─── Channel-specific delivery ────────────────────────────────────────

async function deliverInApp(
  supabase: ReturnType<typeof createServerSupabaseClient>,
  req: AnnouncementDeliveryRequest,
  recipients: DeliveryRecipient[],
  result: DeliveryResult
) {
  // Create in-app notifications for all recipients
  const notifications = recipients.map((r) => ({
    recipient_id: r.user_id,
    school_id: req.schoolId,
    type: "announcement" as const,
    title: req.title,
    body:
      req.content.length > 200
        ? req.content.slice(0, 197) + "..."
        : req.content,
    data: { announcement_id: req.announcementId },
    sent_via: ["in_app"],
  }));

  // Insert in batches
  for (let i = 0; i < notifications.length; i += 500) {
    const batch = notifications.slice(i, i + 500);
    const { error } = await supabase.from("notifications").insert(batch);
    if (error) {
      result.failed.in_app += batch.length;
      result.errors.push(`In-app batch ${i}: ${error.message}`);
    } else {
      result.sent.in_app += batch.length;
    }
  }
}

async function deliverWhatsApp(
  req: AnnouncementDeliveryRequest,
  recipients: DeliveryRecipient[],
  result: DeliveryResult
) {
  const withPhone = recipients.filter((r) => r.whatsapp_number);
  for (const r of withPhone) {
    const res = await sendWhatsAppText({
      to: r.whatsapp_number!,
      text: `📢 *${req.title}*\n\n${req.content.slice(0, 500)}${req.content.length > 500 ? "..." : ""}\n\n— ${req.schoolName}`,
    });
    if (res.success) {
      result.sent.whatsapp++;
    } else {
      result.failed.whatsapp++;
    }
  }
}

async function deliverSmsChannel(
  req: AnnouncementDeliveryRequest,
  recipients: DeliveryRecipient[],
  result: DeliveryResult
) {
  const withPhone = recipients.filter((r) => r.phone);
  const smsText = buildAnnouncementSms(
    req.title,
    req.content,
    req.schoolName
  );

  // Use bulk SMS for efficiency
  if (withPhone.length > 1) {
    const res = await import("./sms").then((mod) =>
      mod.sendBulkSms({
        recipients: withPhone.map((r) => r.phone!),
        text: smsText,
      })
    );
    if (res.success) {
      result.sent.sms += withPhone.length;
    } else {
      result.failed.sms += withPhone.length;
      if (res.error) result.errors.push(`Bulk SMS: ${res.error}`);
    }
  } else if (withPhone.length === 1) {
    const res = await sendSms({ to: withPhone[0].phone!, text: smsText });
    if (res.success) result.sent.sms++;
    else result.failed.sms++;
  }
}

async function deliverEmailChannel(
  req: AnnouncementDeliveryRequest,
  recipients: DeliveryRecipient[],
  result: DeliveryResult
) {
  const withEmail = recipients.filter((r) => r.email);
  if (withEmail.length === 0) return;

  const { subject, html, text } = buildAnnouncementEmail(
    req.title,
    req.content,
    req.schoolName,
    req.priority
  );

  // Use bulk email
  const { sendBulkEmail: bulk } = await import("./email");
  const res = await bulk({
    recipients: withEmail.map((r) => r.email),
    subject,
    html,
    text,
  });

  if (res.success) {
    result.sent.email += withEmail.length;
  } else {
    result.failed.email += withEmail.length;
    if (res.error) result.errors.push(`Email: ${res.error}`);
  }
}

// ─── Utility: send a one-off notification to a single user ────────────

export async function sendNotification(params: {
  recipientId: string;
  schoolId: string;
  type: string;
  title: string;
  body: string;
  data?: Record<string, unknown>;
  channels?: Channel[];
}) {
  const supabase = createServerSupabaseClient();

  // Always create in-app notification
  await supabase.from("notifications").insert({
    recipient_id: params.recipientId,
    school_id: params.schoolId,
    type: params.type,
    title: params.title,
    body: params.body,
    data: params.data || {},
    sent_via: params.channels || ["in_app"],
  });

  // External channels would require looking up user contact info
  // For now, in-app is the primary channel for individual notifications
}
