/**
 * Paystack Integration
 * Nigerian-first payment gateway — cards, bank transfers, USSD
 */

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY || "";
const PAYSTACK_PUBLIC = process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY || "";
const PAYSTACK_BASE = "https://api.paystack.co";

export interface PaystackInitResponse {
  status: boolean;
  message: string;
  data: {
    authorization_url: string;
    access_code: string;
    reference: string;
  };
}

export interface PaystackVerifyResponse {
  status: boolean;
  message: string;
  data: {
    id: number;
    status: "success" | "failed" | "abandoned";
    reference: string;
    amount: number; // in kobo
    currency: string;
    channel: string;
    gateway_response: string;
    paid_at: string | null;
    customer: { email: string };
    authorization: {
      card_type: string;
      last4: string;
      bank: string;
    };
    metadata: Record<string, unknown>;
  };
}

/** Initialize a Paystack transaction (server-side) */
export async function initializePayment(params: {
  email: string;
  amount: number; // in Naira — will be converted to kobo
  reference: string;
  callback_url: string;
  metadata?: Record<string, unknown>;
}): Promise<PaystackInitResponse> {
  const res = await fetch(`${PAYSTACK_BASE}/transaction/initialize`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: params.email,
      amount: Math.round(params.amount * 100), // Naira → kobo
      reference: params.reference,
      callback_url: params.callback_url,
      metadata: params.metadata || {},
      currency: "NGN",
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Paystack init failed: ${res.status} ${text}`);
  }

  return res.json();
}

/** Verify a Paystack transaction (server-side) */
export async function verifyPayment(reference: string): Promise<PaystackVerifyResponse> {
  const res = await fetch(`${PAYSTACK_BASE}/transaction/verify/${encodeURIComponent(reference)}`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET}`,
      "Content-Type": "application/json",
    },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Paystack verify failed: ${res.status} ${text}`);
  }

  return res.json();
}

/** Generate a unique payment reference */
export function generatePaymentReference(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `SM-${timestamp}-${random}`.toUpperCase();
}

/** Get the public key for client-side Paystack popup */
export function getPaystackPublicKey(): string {
  return PAYSTACK_PUBLIC;
}
