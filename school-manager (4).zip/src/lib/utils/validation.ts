import { z } from "zod";

/** Nigerian phone number validation */
export const nigerianPhoneSchema = z
  .string()
  .regex(
    /^(\+234|0)[789]\d{9}$/,
    "Enter a valid Nigerian phone number (e.g., 08012345678)"
  );

/** Nigerian admission number: typically YYYY/XXXX */
export const admissionNumberSchema = z
  .string()
  .min(4, "Admission number is required")
  .max(20, "Admission number too long");

/** Password strength validator */
export const strongPasswordSchema = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .regex(/[A-Z]/, "Must contain at least one uppercase letter")
  .regex(/[a-z]/, "Must contain at least one lowercase letter")
  .regex(/[0-9]/, "Must contain at least one number");

/** Pagination params */
export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().min(5).max(100).default(20),
});

export type PaginationParams = z.infer<typeof paginationSchema>;
