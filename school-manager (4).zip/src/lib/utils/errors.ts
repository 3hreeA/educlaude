// ============================================================================
// School Manager — Error Handling
// ============================================================================

export class AppError extends Error {
  public readonly code: string;
  public readonly status: number;
  public readonly details?: Record<string, string[]>;

  constructor(
    message: string,
    code: string = 'INTERNAL_ERROR',
    status: number = 500,
    details?: Record<string, string[]>
  ) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export const Errors = {
  unauthorized: () =>
    new AppError('You must be logged in', 'UNAUTHORIZED', 401),
  forbidden: () =>
    new AppError('Permission denied', 'FORBIDDEN', 403),
  notFound: (entity: string) =>
    new AppError(`${entity} not found`, 'NOT_FOUND', 404),
  validation: (details: Record<string, string[]>) =>
    new AppError('Validation failed', 'VALIDATION_ERROR', 422, details),
  conflict: (message: string) =>
    new AppError(message, 'CONFLICT', 409),
  rateLimited: () =>
    new AppError('Too many requests', 'RATE_LIMITED', 429),
  badRequest: (message: string) =>
    new AppError(message, 'BAD_REQUEST', 400),
  internal: (message = 'An unexpected error occurred') =>
    new AppError(message, 'INTERNAL_ERROR', 500),
} as const;

export function errorResponse(error: unknown) {
  if (error instanceof AppError) {
    return Response.json(
      { error: { code: error.code, message: error.message, details: error.details } },
      { status: error.status }
    );
  }
  console.error('Unhandled error:', error);
  return Response.json(
    { error: { code: 'INTERNAL_ERROR', message: 'An unexpected error occurred' } },
    { status: 500 }
  );
}

// ─── Convenience helpers for API routes ────────────────────────────────
export function apiSuccess<T>(data: T, status = 200) {
  return Response.json({ data, error: null }, { status });
}

export function apiError(message: string, code: string, status: number) {
  return Response.json(
    { data: null, error: { code, message, status } },
    { status }
  );
}

export const ErrorCodes = {
  UNAUTHORIZED: "UNAUTHORIZED",
  FORBIDDEN: "FORBIDDEN",
  NOT_FOUND: "NOT_FOUND",
  VALIDATION_ERROR: "VALIDATION_ERROR",
  CONFLICT: "CONFLICT",
  RATE_LIMITED: "RATE_LIMITED",
  BAD_REQUEST: "BAD_REQUEST",
  INTERNAL_ERROR: "INTERNAL_ERROR",
} as const;

type ApiHandler = (request: Request) => Promise<Response>;

export function withErrorHandling(handler: ApiHandler): ApiHandler {
  return async (request: Request) => {
    try {
      return await handler(request);
    } catch (error) {
      return errorResponse(error);
    }
  };
}
