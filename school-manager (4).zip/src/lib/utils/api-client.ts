/**
 * Type-safe API fetcher with error handling.
 * Used by TanStack Query hooks for all client-side data fetching.
 */

export class FetchError extends Error {
  public status: number;
  public code: string;

  constructor(message: string, status: number, code: string) {
    super(message);
    this.name = "FetchError";
    this.status = status;
    this.code = code;
  }
}

export async function apiFetch<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...options?.headers },
    ...options,
  });

  const json = await res.json();

  if (!res.ok || json.error) {
    throw new FetchError(
      json.error?.message || "An unexpected error occurred",
      res.status,
      json.error?.code || "UNKNOWN"
    );
  }

  return json.data as T;
}

/** Build URL with query params, skipping null/undefined values */
export function buildUrl(
  path: string,
  params?: Record<string, string | number | boolean | null | undefined>
): string {
  if (!params) return path;
  const searchParams = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== null && value !== undefined) {
      searchParams.set(key, String(value));
    }
  }
  const qs = searchParams.toString();
  return qs ? `${path}?${qs}` : path;
}
