/**
 * Nigerian payroll calculations
 * Implements PAYE tax brackets, pension (PFA Act 2014), and NHF deductions
 */

// ─── PAYE Tax Brackets (Nigeria Finance Act) ──────────────────────────
// Applied to taxable income (annual) after reliefs
const PAYE_BRACKETS = [
  { limit: 300_000, rate: 0.07 },
  { limit: 300_000, rate: 0.11 },
  { limit: 500_000, rate: 0.15 },
  { limit: 500_000, rate: 0.19 },
  { limit: 1_600_000, rate: 0.21 },
  { limit: Infinity, rate: 0.24 },
];

// Consolidated Relief Allowance: higher of ₦200,000 or 1% of gross + 20% of gross
function computeConsolidatedRelief(annualGross: number): number {
  const fixed = Math.max(200_000, annualGross * 0.01);
  return fixed + annualGross * 0.20;
}

/** Calculate annual PAYE tax on gross income */
export function calculatePayeAnnual(annualGross: number, annualPension: number): number {
  if (annualGross <= 0) return 0;

  const relief = computeConsolidatedRelief(annualGross);
  const taxableIncome = Math.max(0, annualGross - relief - annualPension);

  let tax = 0;
  let remaining = taxableIncome;

  for (const bracket of PAYE_BRACKETS) {
    if (remaining <= 0) break;
    const taxable = Math.min(remaining, bracket.limit);
    tax += taxable * bracket.rate;
    remaining -= taxable;
  }

  // Minimum tax: 1% of gross income (if computed tax < 1%)
  const minimumTax = annualGross * 0.01;
  return Math.max(tax, minimumTax);
}

/** Calculate monthly PAYE */
export function calculatePayeMonthly(monthlyGross: number, monthlyPension: number): number {
  return Math.round((calculatePayeAnnual(monthlyGross * 12, monthlyPension * 12) / 12) * 100) / 100;
}

// ─── Pension (PFA Act 2014) ───────────────────────────────────────────
// Employee contributes 8%, Employer contributes 10% of basic + housing + transport
export const PENSION_EMPLOYEE_RATE = 0.08;
export const PENSION_EMPLOYER_RATE = 0.10;

/** Calculate employee pension contribution (monthly) */
export function calculatePension(basicSalary: number): number {
  return Math.round(basicSalary * PENSION_EMPLOYEE_RATE * 100) / 100;
}

// ─── National Housing Fund (NHF) ─────────────────────────────────────
// 2.5% of basic salary
export const NHF_RATE = 0.025;

export function calculateNhf(basicSalary: number): number {
  return Math.round(basicSalary * NHF_RATE * 100) / 100;
}

// ─── Full payslip computation ─────────────────────────────────────────
export interface SalaryInput {
  basic_salary: number;
  housing_allowance: number;
  transport_allowance: number;
  meal_allowance: number;
  other_deductions?: number;
}

export interface PayslipComputation {
  gross_salary: number;
  tax_paye: number;
  pension: number;
  nhf: number;
  other_deductions: number;
  total_deductions: number;
  net_salary: number;
}

export function computePayslip(input: SalaryInput): PayslipComputation {
  const gross = input.basic_salary + input.housing_allowance +
    input.transport_allowance + input.meal_allowance;

  const pension = calculatePension(input.basic_salary);
  const nhf = calculateNhf(input.basic_salary);
  const paye = calculatePayeMonthly(gross, pension);
  const otherDed = input.other_deductions || 0;
  const totalDed = paye + pension + nhf + otherDed;

  return {
    gross_salary: gross,
    tax_paye: paye,
    pension,
    nhf,
    other_deductions: otherDed,
    total_deductions: totalDed,
    net_salary: Math.round((gross - totalDed) * 100) / 100,
  };
}

// ─── NIBSS Format ─────────────────────────────────────────────────────
export interface NibssEntry {
  account_number: string;
  bank_code: string;
  amount: number;
  narration: string;
  beneficiary_name: string;
}

/** Generate NIBSS CSV for bank transfer file */
export function generateNibssCsv(entries: NibssEntry[]): string {
  const header = "Account Number,Bank Code,Amount,Narration,Beneficiary Name";
  const rows = entries.map(
    (e) => `${e.account_number},${e.bank_code},${e.amount.toFixed(2)},${e.narration},${e.beneficiary_name}`
  );
  return [header, ...rows].join("\n");
}

// Nigerian bank codes
export const NIGERIAN_BANKS: Record<string, string> = {
  "GTBank": "058",
  "Guaranty Trust Bank": "058",
  "Zenith Bank": "057",
  "First Bank": "011",
  "First Bank of Nigeria": "011",
  "Access Bank": "044",
  "UBA": "033",
  "United Bank for Africa": "033",
  "Fidelity Bank": "070",
  "Union Bank": "032",
  "Sterling Bank": "232",
  "Stanbic IBTC": "221",
  "Wema Bank": "035",
  "Polaris Bank": "076",
  "Keystone Bank": "082",
  "FCMB": "214",
  "Ecobank": "050",
  "Heritage Bank": "030",
  "Jaiz Bank": "301",
  "Providus Bank": "101",
};

export function getBankCode(bankName: string): string {
  return NIGERIAN_BANKS[bankName] || "000";
}
