"use client";

import { useOnline } from "@/lib/hooks/use-pwa";
import { WifiOff } from "lucide-react";

export function NetworkStatus() {
  const online = useOnline();

  if (online) return null;

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 animate-fade-in" role="alert">
      <div className="flex items-center gap-2 rounded-full bg-destructive px-4 py-2 text-sm text-destructive-foreground shadow-lg">
        <WifiOff className="h-4 w-4" />
        <span>You&apos;re offline. Some features may be unavailable.</span>
      </div>
    </div>
  );
}
