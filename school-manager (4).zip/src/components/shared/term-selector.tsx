"use client";

import { useTerms } from "@/features/terms/hooks";
import { cn } from "@/lib/utils/cn";

interface TermSelectorProps {
  value: string | null;
  onChange: (termId: string | null) => void;
  className?: string;
}

export function TermSelector({ value, onChange, className }: TermSelectorProps) {
  const { data, isLoading } = useTerms();

  if (isLoading) {
    return (
      <div className={cn("h-9 w-40 animate-pulse rounded-md bg-muted", className)} />
    );
  }

  const terms = data?.terms || [];
  const currentTermId = data?.current_term?.id;

  return (
    <select
      value={value || currentTermId || ""}
      onChange={(e) => onChange(e.target.value || null)}
      className={cn(
        "h-9 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring",
        className
      )}
      aria-label="Select term"
    >
      {terms.map((term) => (
        <option key={term.id} value={term.id}>
          {term.name}
          {term.is_current ? " (Current)" : ""}
        </option>
      ))}
    </select>
  );
}
