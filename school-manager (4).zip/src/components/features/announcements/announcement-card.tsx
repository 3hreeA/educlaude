"use client";

import { useState } from "react";
import { Megaphone, ChevronDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils/cn";
import { formatDateTime } from "@/lib/utils/format";
import type { AnnouncementItem } from "@/features/announcements/hooks";

const PRIORITY_VARIANT: Record<string, "default" | "success" | "warning" | "destructive" | "info"> = {
  low: "default",
  normal: "info",
  high: "warning",
  urgent: "destructive",
};

interface AnnouncementCardProps {
  announcement: AnnouncementItem;
  defaultExpanded?: boolean;
}

export function AnnouncementCard({
  announcement,
  defaultExpanded = false,
}: AnnouncementCardProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  // Truncate content for collapsed view
  const isLong = announcement.content.length > 200;
  const displayContent = expanded
    ? announcement.content
    : announcement.content.slice(0, 200) + (isLong ? "..." : "");

  return (
    <Card
      className={cn(
        "transition-shadow",
        announcement.priority === "urgent" && "border-red-200 bg-red-50/50",
        announcement.priority === "high" && "border-amber-200 bg-amber-50/30"
      )}
    >
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Megaphone
              className="h-4 w-4 text-muted-foreground shrink-0"
              aria-hidden="true"
            />
            <CardTitle className="text-base truncate">
              {announcement.title}
            </CardTitle>
          </div>
          <Badge
            variant={PRIORITY_VARIANT[announcement.priority] || "default"}
            className="text-[10px] capitalize shrink-0"
          >
            {announcement.priority}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground">
          {announcement.published_by}
          {announcement.published_at &&
            ` · ${formatDateTime(announcement.published_at)}`}
        </p>
      </CardHeader>
      <CardContent>
        <p className="text-sm whitespace-pre-wrap leading-relaxed">
          {displayContent}
        </p>
        {isLong && (
          <button
            onClick={() => setExpanded(!expanded)}
            className="mt-2 text-xs font-medium text-primary hover:underline inline-flex items-center gap-1"
            aria-expanded={expanded}
          >
            {expanded ? "Show less" : "Read more"}
            <ChevronDown
              className={cn(
                "h-3 w-3 transition-transform",
                expanded && "rotate-180"
              )}
            />
          </button>
        )}
      </CardContent>
    </Card>
  );
}
