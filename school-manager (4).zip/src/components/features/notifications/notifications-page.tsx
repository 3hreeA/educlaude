"use client";

import { useState } from "react";
import {
  Bell, CheckCheck, ChevronLeft, ChevronRight,
  Megaphone, CreditCard, ClipboardCheck, GraduationCap,
  MessageSquare, AlertTriangle, Inbox,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { ListSkeleton } from "@/components/shared/skeletons";
import { cn } from "@/lib/utils/cn";
import { formatRelativeTime, formatDateTime } from "@/lib/utils/format";
import {
  useNotifications,
  useMarkNotificationsRead,
} from "@/features/notifications/hooks";
import type { NotificationItem } from "@/features/notifications/hooks";

const TYPE_META: Record<string, { icon: typeof Bell; label: string; color: string }> = {
  announcement: { icon: Megaphone, label: "Announcement", color: "text-blue-600 bg-blue-50" },
  fee_reminder: { icon: CreditCard, label: "Fee Reminder", color: "text-amber-600 bg-amber-50" },
  attendance_alert: { icon: ClipboardCheck, label: "Attendance", color: "text-red-600 bg-red-50" },
  grade_posted: { icon: GraduationCap, label: "Grades", color: "text-emerald-600 bg-emerald-50" },
  feedback: { icon: MessageSquare, label: "Feedback", color: "text-purple-600 bg-purple-50" },
  disciplinary: { icon: AlertTriangle, label: "Disciplinary", color: "text-red-600 bg-red-50" },
};

function getTypeMeta(type: string) {
  return TYPE_META[type] || { icon: Bell, label: "Notification", color: "text-gray-600 bg-gray-50" };
}

interface NotificationsPageContentProps {
  title?: string;
  description?: string;
}

export function NotificationsPageContent({
  title = "Notifications",
  description = "Stay updated with alerts and announcements",
}: NotificationsPageContentProps) {
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const { data, isLoading } = useNotifications(page, 20, filter === "unread");
  const markRead = useMarkNotificationsRead();

  const notifications = data?.notifications || [];
  const pagination = data?.pagination;
  const unreadCount = data?.unread_count || 0;

  function handleMarkAllRead() {
    markRead.mutate(undefined);
  }

  function handleMarkOne(n: NotificationItem) {
    if (!n.read_at) {
      markRead.mutate([n.id]);
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title={title} description={description} />

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex rounded-lg border overflow-hidden">
          <button
            onClick={() => { setFilter("all"); setPage(1); }}
            className={cn(
              "px-4 py-2 text-sm font-medium transition-colors",
              filter === "all" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
            )}
          >
            All
          </button>
          <button
            onClick={() => { setFilter("unread"); setPage(1); }}
            className={cn(
              "px-4 py-2 text-sm font-medium transition-colors border-l",
              filter === "unread" ? "bg-primary text-primary-foreground" : "bg-card hover:bg-muted"
            )}
          >
            Unread {unreadCount > 0 && `(${unreadCount})`}
          </button>
        </div>

        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleMarkAllRead}
            disabled={markRead.isPending}
          >
            <CheckCheck className="h-4 w-4 mr-2" />
            Mark all as read
          </Button>
        )}
      </div>

      {/* Loading */}
      {isLoading && <ListSkeleton rows={6} />}

      {/* Empty */}
      {!isLoading && notifications.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center py-12">
            <Inbox className="h-12 w-12 text-muted-foreground/40 mb-3" />
            <p className="text-sm font-medium text-muted-foreground">
              {filter === "unread" ? "No unread notifications" : "No notifications yet"}
            </p>
            <p className="text-xs text-muted-foreground/70 mt-1">
              {filter === "unread"
                ? "You're all caught up!"
                : "You'll see alerts and announcements here"}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Notification List */}
      {!isLoading && notifications.length > 0 && (
        <Card>
          <CardContent className="p-0 divide-y">
            {notifications.map((n) => {
              const meta = getTypeMeta(n.type);
              const Icon = meta.icon;
              return (
                <button
                  key={n.id}
                  onClick={() => handleMarkOne(n)}
                  className={cn(
                    "w-full flex items-start gap-4 p-4 text-left transition-colors hover:bg-muted/50",
                    !n.read_at && "bg-primary/[0.03]"
                  )}
                >
                  {/* Icon */}
                  <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-full", meta.color)}>
                    <Icon className="h-5 w-5" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={cn("text-sm leading-tight", !n.read_at && "font-semibold")}>
                        {n.title}
                      </p>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge variant="secondary" className="text-[10px] font-normal">
                          {meta.label}
                        </Badge>
                        {!n.read_at && (
                          <span className="h-2 w-2 rounded-full bg-primary" />
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {n.body}
                    </p>
                    <p className="text-xs text-muted-foreground/70 mt-1.5">
                      {formatRelativeTime(n.created_at)}
                      <span className="mx-1.5">·</span>
                      {formatDateTime(n.created_at)}
                    </p>
                  </div>
                </button>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Pagination */}
      {pagination && pagination.total_pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {pagination.page} of {pagination.total_pages} ({pagination.total} total)
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage((p) => p - 1)}
            >
              <ChevronLeft className="h-4 w-4 mr-1" /> Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= pagination.total_pages}
              onClick={() => setPage((p) => p + 1)}
            >
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
