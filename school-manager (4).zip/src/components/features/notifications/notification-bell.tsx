"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bell, Check, CheckCheck, Megaphone, CreditCard,
  ClipboardCheck, GraduationCap, MessageSquare, AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils/cn";
import { formatRelativeTime } from "@/lib/utils/format";
import { useNotifications, useMarkNotificationsRead, useUnreadCount } from "@/features/notifications/hooks";
import type { NotificationItem } from "@/features/notifications/hooks";

const TYPE_ICONS: Record<string, typeof Bell> = {
  announcement: Megaphone,
  fee_reminder: CreditCard,
  attendance_alert: ClipboardCheck,
  grade_posted: GraduationCap,
  feedback: MessageSquare,
  disciplinary: AlertTriangle,
};

function NotificationIcon({ type }: { type: string }) {
  const Icon = TYPE_ICONS[type] || Bell;
  return <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />;
}

export function NotificationBell({ userRole }: { userRole: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const { data: unreadCount = 0 } = useUnreadCount();
  const { data, isLoading } = useNotifications(1, 8);
  const markRead = useMarkNotificationsRead();

  const notifications = data?.notifications || [];

  function handleNotificationClick(n: NotificationItem) {
    // Mark as read
    if (!n.read_at) {
      markRead.mutate([n.id]);
    }

    // Navigate based on type + data
    const d = n.data as Record<string, string> | null;
    if (n.type === "announcement" && d?.announcement_id) {
      router.push(`/${userRole}/announcements`);
    } else if (n.type === "grade_posted") {
      router.push(`/${userRole === "parent" ? "parent/children" : "teacher/classes"}`);
    } else if (n.type === "fee_reminder") {
      router.push("/parent/fees");
    }

    setOpen(false);
  }

  function handleMarkAllRead() {
    markRead.mutate(undefined); // marks all
  }

  function handleViewAll() {
    setOpen(false);
    router.push(`/${userRole}/notifications`);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label={`Notifications${unreadCount > 0 ? ` — ${unreadCount} unread` : ""}`}
          className="relative"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span
              className="absolute -top-0.5 -right-0.5 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground"
              aria-hidden="true"
            >
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>

      <PopoverContent align="end" className="w-80 p-0" sideOffset={8}>
        {/* Header */}
        <div className="flex items-center justify-between border-b px-4 py-3">
          <h3 className="text-sm font-semibold">Notifications</h3>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-auto py-1 px-2 text-xs"
              onClick={handleMarkAllRead}
              disabled={markRead.isPending}
            >
              <CheckCheck className="h-3 w-3 mr-1" />
              Mark all read
            </Button>
          )}
        </div>

        {/* List */}
        <div className="max-h-[360px] overflow-y-auto">
          {isLoading && (
            <div className="p-4 text-center text-sm text-muted-foreground">
              Loading…
            </div>
          )}

          {!isLoading && notifications.length === 0 && (
            <div className="p-8 text-center">
              <Bell className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
              <p className="text-sm text-muted-foreground">No notifications yet</p>
            </div>
          )}

          {notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={cn(
                "w-full flex items-start gap-3 px-4 py-3 text-left border-b last:border-0 transition-colors hover:bg-muted/50",
                !n.read_at && "bg-primary/5"
              )}
            >
              <div className="mt-0.5">
                <NotificationIcon type={n.type} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={cn("text-sm leading-tight", !n.read_at && "font-medium")}>
                  {n.title}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                  {n.body}
                </p>
                <p className="text-[10px] text-muted-foreground/70 mt-1">
                  {formatRelativeTime(n.created_at)}
                </p>
              </div>
              {!n.read_at && (
                <span className="mt-2 h-2 w-2 rounded-full bg-primary shrink-0" />
              )}
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="border-t px-4 py-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full text-xs"
            onClick={handleViewAll}
          >
            View all notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
