"use client";

import { ThumbsUp, AlertCircle, MessageCircle, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils/cn";
import { formatDateTime } from "@/lib/utils/format";
import type { FeedbackEntry } from "@/features/feedback/hooks";

const CATEGORY_CONFIG: Record<
  string,
  { icon: typeof ThumbsUp; color: string; label: string; variant: "success" | "warning" | "destructive" | "default" | "info" }
> = {
  positive: {
    icon: ThumbsUp,
    color: "text-emerald-600 bg-emerald-50 border-emerald-200",
    label: "Positive",
    variant: "success",
  },
  neutral: {
    icon: Info,
    color: "text-blue-600 bg-blue-50 border-blue-200",
    label: "Observation",
    variant: "info",
  },
  concern: {
    icon: AlertCircle,
    color: "text-amber-600 bg-amber-50 border-amber-200",
    label: "Concern",
    variant: "warning",
  },
  serious: {
    icon: AlertCircle,
    color: "text-red-600 bg-red-50 border-red-200",
    label: "Serious",
    variant: "destructive",
  },
};

interface FeedbackTimelineProps {
  entries: FeedbackEntry[];
}

export function FeedbackTimeline({ entries }: FeedbackTimelineProps) {
  if (entries.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-4">
        No feedback entries yet.
      </p>
    );
  }

  return (
    <div className="relative space-y-0">
      {/* Timeline line */}
      <div className="absolute left-5 top-0 bottom-0 w-px bg-border" aria-hidden="true" />

      {entries.map((entry, index) => {
        const config = CATEGORY_CONFIG[entry.category] || CATEGORY_CONFIG.neutral;
        const Icon = config.icon;

        return (
          <div key={entry.id} className="relative flex gap-4 pb-6 last:pb-0">
            {/* Timeline dot */}
            <div
              className={cn(
                "relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2",
                config.color
              )}
            >
              <Icon className="h-4 w-4" aria-hidden="true" />
            </div>

            {/* Content */}
            <div className="flex-1 pt-1">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={config.variant} className="text-[10px]">
                  {config.label}
                </Badge>
                <span className="text-xs text-muted-foreground capitalize">
                  {entry.type}
                </span>
              </div>

              <p className="mt-1.5 text-sm leading-relaxed">
                {entry.description}
              </p>

              <p className="mt-1 text-xs text-muted-foreground">
                {entry.teacher_name} · {formatDateTime(entry.date)}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
