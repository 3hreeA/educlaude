"use client";

import { useState } from "react";
import { Send, MessageSquarePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { ClassStudent, FeedbackInput } from "@/features/teachers/hooks";

const FEEDBACK_TYPES = [
  { value: "behavioral" as const, label: "Behavioral", emoji: "🎭" },
  { value: "academic" as const, label: "Academic", emoji: "📚" },
  { value: "social" as const, label: "Social", emoji: "🤝" },
  { value: "attendance" as const, label: "Attendance", emoji: "📋" },
];

const CATEGORIES = [
  { value: "positive" as const, label: "Positive", color: "bg-green-50 border-green-300 text-green-800" },
  { value: "neutral" as const, label: "Neutral", color: "bg-gray-50 border-gray-300 text-gray-800" },
  { value: "concern" as const, label: "Concern", color: "bg-amber-50 border-amber-300 text-amber-800" },
  { value: "serious" as const, label: "Serious", color: "bg-red-50 border-red-300 text-red-800" },
];

const QUICK_COMMENTS: Record<string, string[]> = {
  "behavioral-positive": [
    "Shows excellent leadership in group activities",
    "Very respectful and well-mannered",
    "Helpful to classmates and teachers",
    "Shows great discipline and self-control",
  ],
  "behavioral-concern": [
    "Frequently talks during lessons",
    "Needs to improve behaviour during assembly",
    "Has difficulty following class rules",
  ],
  "academic-positive": [
    "Outstanding performance in recent assessment",
    "Shows consistent improvement",
    "Always completes assignments on time",
    "Actively participates in class discussions",
  ],
  "academic-concern": [
    "Not completing homework regularly",
    "Needs extra support in this subject",
    "Performance has declined recently",
  ],
};

interface FeedbackFormProps {
  students: ClassStudent[];
  onSubmit: (feedback: FeedbackInput) => void;
  isSubmitting?: boolean;
}

export function FeedbackForm({ students, onSubmit, isSubmitting = false }: FeedbackFormProps) {
  const [selectedStudent, setSelectedStudent] = useState<string>("");
  const [feedbackType, setFeedbackType] = useState<FeedbackInput["feedback_type"]>("academic");
  const [category, setCategory] = useState<FeedbackInput["category"]>("positive");
  const [description, setDescription] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredStudents = students.filter(
    (s) =>
      s.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.admission_number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedStudentObj = students.find((s) => s.id === selectedStudent);
  const quickComments = QUICK_COMMENTS[`${feedbackType}-${category}`] || [];

  const handleSubmit = () => {
    if (!selectedStudent || !description.trim()) return;
    onSubmit({
      student_id: selectedStudent,
      feedback_type: feedbackType,
      category,
      description: description.trim(),
    });
    // Reset form
    setDescription("");
  };

  const isValid = selectedStudent && description.trim().length >= 10;

  return (
    <div className="space-y-6">
      {/* Step 1: Select Student */}
      <div>
        <label className="text-sm font-medium mb-2 block">Select Student</label>
        {selectedStudentObj ? (
          <div className="flex items-center justify-between rounded-lg border bg-primary/5 px-3 py-2.5">
            <div>
              <p className="text-sm font-medium">
                {selectedStudentObj.last_name}, {selectedStudentObj.first_name}
              </p>
              <p className="text-xs text-muted-foreground">{selectedStudentObj.admission_number}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setSelectedStudent("")}>
              Change
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Search by name or admission number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-sm px-3 py-2 rounded-lg border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <div className="max-h-48 overflow-y-auto rounded-lg border divide-y">
              {filteredStudents.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedStudent(s.id);
                    setSearchTerm("");
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-muted/50 transition-colors"
                >
                  <p className="text-sm font-medium">
                    {s.last_name}, {s.first_name}
                  </p>
                  <p className="text-xs text-muted-foreground">{s.admission_number}</p>
                </button>
              ))}
              {filteredStudents.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">No students found</p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Step 2: Feedback Type */}
      <div>
        <label className="text-sm font-medium mb-2 block">Feedback Type</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {FEEDBACK_TYPES.map((t) => (
            <button
              key={t.value}
              onClick={() => setFeedbackType(t.value)}
              className={cn(
                "flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-colors",
                feedbackType === t.value
                  ? "border-primary bg-primary/5 text-primary font-medium"
                  : "border-input hover:bg-muted/50"
              )}
            >
              <span>{t.emoji}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Step 3: Category (sentiment) */}
      <div>
        <label className="text-sm font-medium mb-2 block">Category</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value)}
              className={cn(
                "px-3 py-2 rounded-lg border text-sm transition-colors",
                category === c.value
                  ? c.color + " font-medium"
                  : "border-input hover:bg-muted/50"
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Quick Comment Suggestions */}
      {quickComments.length > 0 && (
        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">Quick suggestions (tap to use)</label>
          <div className="flex flex-wrap gap-1.5">
            {quickComments.map((comment, i) => (
              <button
                key={i}
                onClick={() => setDescription(comment)}
                className="text-xs px-2.5 py-1 rounded-full border bg-muted/30 hover:bg-muted/60 transition-colors text-left"
              >
                {comment}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Step 4: Description */}
      <div>
        <label className="text-sm font-medium mb-2 block">
          Description <span className="text-muted-foreground font-normal">(min 10 characters)</span>
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Describe the feedback in detail..."
          rows={4}
          className="w-full text-sm px-3 py-2 rounded-lg border bg-background focus:outline-none focus:ring-1 focus:ring-primary resize-none"
        />
        <p className="text-xs text-muted-foreground mt-1">
          {description.length} characters {description.length < 10 && description.length > 0 && "· Need at least 10"}
        </p>
      </div>

      {/* Submit */}
      <Button
        onClick={handleSubmit}
        disabled={!isValid || isSubmitting}
        className="w-full gap-2"
        size="lg"
      >
        <Send className="h-4 w-4" />
        {isSubmitting ? "Submitting..." : "Submit Feedback"}
      </Button>
    </div>
  );
}
