"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Save, BarChart3, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { StudentGradeEntry, GradeEntryInput } from "@/features/teachers/hooks";

interface GradeEntryGridProps {
  students: StudentGradeEntry[];
  maxScore: number;
  assessmentName: string;
  onSubmit: (grades: GradeEntryInput[]) => void;
  isSubmitting?: boolean;
}

export function GradeEntryGrid({
  students,
  maxScore,
  assessmentName,
  onSubmit,
  isSubmitting = false,
}: GradeEntryGridProps) {
  const [scores, setScores] = useState<Map<string, number | null>>(new Map());
  const [remarks, setRemarks] = useState<Map<string, string>>(new Map());
  const [errors, setErrors] = useState<Map<string, string>>(new Map());
  const inputRefs = useRef<Map<string, HTMLInputElement>>(new Map());

  // Initialize from existing grades
  useEffect(() => {
    const initial = new Map<string, number | null>();
    const initialRemarks = new Map<string, string>();
    for (const s of students) {
      initial.set(s.student_id, s.score);
      if (s.remarks) initialRemarks.set(s.student_id, s.remarks);
    }
    setScores(initial);
    setRemarks(initialRemarks);
  }, [students]);

  const updateScore = useCallback(
    (studentId: string, value: string) => {
      const newErrors = new Map(errors);
      newErrors.delete(studentId);

      if (value === "") {
        setScores((prev) => {
          const next = new Map(prev);
          next.set(studentId, null);
          return next;
        });
        setErrors(newErrors);
        return;
      }

      const num = parseFloat(value);
      if (isNaN(num)) {
        newErrors.set(studentId, "Must be a number");
      } else if (num < 0) {
        newErrors.set(studentId, "Cannot be negative");
      } else if (num > maxScore) {
        newErrors.set(studentId, `Max score is ${maxScore}`);
      }

      setScores((prev) => {
        const next = new Map(prev);
        next.set(studentId, isNaN(num) ? null : num);
        return next;
      });
      setErrors(newErrors);
    },
    [maxScore, errors]
  );

  const updateRemark = useCallback((studentId: string, value: string) => {
    setRemarks((prev) => {
      const next = new Map(prev);
      if (value.trim()) {
        next.set(studentId, value);
      } else {
        next.delete(studentId);
      }
      return next;
    });
  }, []);

  // Navigate between rows with Enter/Arrow keys
  const handleKeyDown = (e: React.KeyboardEvent, studentId: string, idx: number) => {
    if (e.key === "Enter" || e.key === "ArrowDown") {
      e.preventDefault();
      const nextStudent = students[idx + 1];
      if (nextStudent) {
        inputRefs.current.get(nextStudent.student_id)?.focus();
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const prevStudent = students[idx - 1];
      if (prevStudent) {
        inputRefs.current.get(prevStudent.student_id)?.focus();
      }
    }
  };

  const handleSubmit = () => {
    // Validate: at least one score entered
    const validGrades: GradeEntryInput[] = [];
    for (const s of students) {
      const score = scores.get(s.student_id);
      if (score !== null && score !== undefined) {
        validGrades.push({
          student_id: s.student_id,
          score,
          remarks: remarks.get(s.student_id),
        });
      }
    }

    if (validGrades.length === 0) {
      return;
    }

    onSubmit(validGrades);
  };

  // Stats
  const enteredScores = Array.from(scores.values()).filter((s) => s !== null && s !== undefined) as number[];
  const avgScore = enteredScores.length > 0
    ? (enteredScores.reduce((a, b) => a + b, 0) / enteredScores.length).toFixed(1)
    : "—";
  const highestScore = enteredScores.length > 0 ? Math.max(...enteredScores) : null;
  const lowestScore = enteredScores.length > 0 ? Math.min(...enteredScores) : null;
  const completionPct = Math.round((enteredScores.length / students.length) * 100);
  const hasErrors = errors.size > 0;

  return (
    <div className="space-y-4">
      {/* Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="rounded-lg border bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Entered</p>
          <p className="text-lg font-bold">{enteredScores.length}/{students.length}</p>
        </div>
        <div className="rounded-lg border bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Completion</p>
          <p className="text-lg font-bold">{completionPct}%</p>
        </div>
        <div className="rounded-lg border bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Average</p>
          <p className="text-lg font-bold">{avgScore}</p>
        </div>
        <div className="rounded-lg border bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Highest</p>
          <p className="text-lg font-bold text-green-700">{highestScore ?? "—"}</p>
        </div>
        <div className="rounded-lg border bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground">Lowest</p>
          <p className="text-lg font-bold text-red-700">{lowestScore ?? "—"}</p>
        </div>
      </div>

      {/* Grade Entry Table */}
      <div className="rounded-lg border overflow-hidden">
        {/* Header */}
        <div className="grid grid-cols-[1fr_80px_1fr] sm:grid-cols-[40px_1fr_100px_1fr] gap-0 bg-muted/50 px-3 py-2 text-xs font-medium text-muted-foreground border-b">
          <span className="hidden sm:block">#</span>
          <span>Student</span>
          <span className="text-center">Score (/{maxScore})</span>
          <span className="hidden sm:block">Remarks</span>
        </div>

        {/* Rows */}
        <div className="divide-y">
          {students.map((student, idx) => {
            const score = scores.get(student.student_id);
            const error = errors.get(student.student_id);
            const percentage = score !== null && score !== undefined
              ? Math.round((score / maxScore) * 100)
              : null;

            return (
              <div
                key={student.student_id}
                className={cn(
                  "grid grid-cols-[1fr_80px_1fr] sm:grid-cols-[40px_1fr_100px_1fr] gap-0 px-3 py-2 items-center",
                  error && "bg-red-50/50"
                )}
              >
                {/* Row Number */}
                <span className="hidden sm:block text-xs text-muted-foreground">{idx + 1}</span>

                {/* Student Name */}
                <div className="min-w-0 pr-2">
                  <p className="text-sm font-medium truncate">
                    {student.last_name}, {student.first_name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{student.admission_number}</p>
                </div>

                {/* Score Input */}
                <div className="relative">
                  <input
                    ref={(el) => {
                      if (el) inputRefs.current.set(student.student_id, el);
                    }}
                    type="number"
                    min={0}
                    max={maxScore}
                    step="0.5"
                    placeholder="—"
                    value={score !== null && score !== undefined ? score : ""}
                    onChange={(e) => updateScore(student.student_id, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(e, student.student_id, idx)}
                    className={cn(
                      "w-full text-center text-sm font-mono px-2 py-1.5 rounded border bg-background focus:outline-none focus:ring-1",
                      error
                        ? "border-red-400 focus:ring-red-400"
                        : "border-input focus:ring-primary"
                    )}
                  />
                  {percentage !== null && (
                    <span
                      className={cn(
                        "absolute -top-1.5 right-0 text-[9px] font-medium px-1 rounded",
                        percentage >= 70 ? "text-green-700" : percentage >= 50 ? "text-amber-700" : "text-red-700"
                      )}
                    >
                      {percentage}%
                    </span>
                  )}
                  {error && (
                    <p className="text-[10px] text-red-600 mt-0.5 sm:hidden">{error}</p>
                  )}
                </div>

                {/* Remarks */}
                <div className="hidden sm:block pl-2">
                  <input
                    type="text"
                    placeholder="Optional remarks"
                    value={remarks.get(student.student_id) || ""}
                    onChange={(e) => updateRemark(student.student_id, e.target.value)}
                    className="w-full text-xs px-2 py-1.5 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                  {error && <p className="text-[10px] text-red-600 mt-0.5">{error}</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Submit */}
      <div className="sticky bottom-0 bg-background/95 backdrop-blur pt-3 pb-2 border-t flex items-center justify-between gap-3">
        <div className="text-sm text-muted-foreground">
          <BarChart3 className="h-4 w-4 inline mr-1" />
          {enteredScores.length} of {students.length} graded
        </div>
        <Button
          onClick={handleSubmit}
          disabled={enteredScores.length === 0 || hasErrors || isSubmitting}
          className="gap-2"
          size="lg"
        >
          <Save className="h-4 w-4" />
          {isSubmitting ? "Saving..." : "Save Grades"}
        </Button>
      </div>

      {hasErrors && (
        <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">
          <AlertTriangle className="h-4 w-4" />
          Fix errors above before saving
        </div>
      )}
    </div>
  );
}
