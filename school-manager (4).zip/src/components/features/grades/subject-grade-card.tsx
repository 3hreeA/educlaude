"use client";

import { useState } from "react";
import { ChevronDown, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils/cn";
import { getGradeLetter, getGradeRemark, formatDate } from "@/lib/utils/format";
import type { SubjectGrades } from "@/features/grades/hooks";

const GRADE_COLORS: Record<string, string> = {
  A: "bg-emerald-100 text-emerald-700 border-emerald-200",
  B: "bg-blue-100 text-blue-700 border-blue-200",
  C: "bg-amber-100 text-amber-700 border-amber-200",
  D: "bg-orange-100 text-orange-700 border-orange-200",
  E: "bg-red-100 text-red-700 border-red-200",
  F: "bg-red-200 text-red-800 border-red-300",
};

interface SubjectGradeCardProps {
  subject: SubjectGrades;
}

export function SubjectGradeCard({ subject }: SubjectGradeCardProps) {
  const [expanded, setExpanded] = useState(false);

  const grade = subject.average !== null ? getGradeLetter(subject.average) : null;
  const remark = subject.average !== null ? getGradeRemark(subject.average) : null;

  // Compare to class average
  const diff =
    subject.average !== null && subject.class_average !== null
      ? Math.round((subject.average - subject.class_average) * 10) / 10
      : null;

  return (
    <Card>
      <CardHeader
        className="pb-2 cursor-pointer select-none"
        onClick={() => setExpanded(!expanded)}
        role="button"
        aria-expanded={expanded}
        aria-label={`${subject.name} grades, click to ${expanded ? "collapse" : "expand"}`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CardTitle className="text-base">{subject.name}</CardTitle>
            <span className="text-xs text-muted-foreground uppercase">
              {subject.code}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {grade && (
              <Badge
                className={cn("text-sm font-bold border", GRADE_COLORS[grade])}
                variant="outline"
              >
                {grade}
              </Badge>
            )}
            <ChevronDown
              className={cn(
                "h-4 w-4 text-muted-foreground transition-transform",
                expanded && "rotate-180"
              )}
            />
          </div>
        </div>

        {/* Summary row */}
        <div className="flex items-center gap-4 mt-1">
          {subject.average !== null && (
            <span className="text-sm font-medium">{subject.average}%</span>
          )}
          {remark && (
            <span className="text-xs text-muted-foreground">{remark}</span>
          )}
          {diff !== null && (
            <span
              className={cn(
                "flex items-center gap-0.5 text-xs font-medium",
                diff > 0 && "text-emerald-600",
                diff < 0 && "text-red-600",
                diff === 0 && "text-muted-foreground"
              )}
            >
              {diff > 0 ? (
                <TrendingUp className="h-3 w-3" />
              ) : diff < 0 ? (
                <TrendingDown className="h-3 w-3" />
              ) : (
                <Minus className="h-3 w-3" />
              )}
              {diff > 0 ? "+" : ""}
              {diff}% vs class avg
            </span>
          )}
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="pt-0">
          <div className="space-y-3 border-t pt-3">
            {subject.assessments.map((assessment) => (
              <div key={assessment.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{assessment.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(assessment.date)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {assessment.student_score !== null ? (
                      <span className="font-semibold">
                        {assessment.student_score}/{assessment.max_score}
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-xs">
                        Not graded
                      </span>
                    )}
                  </div>
                </div>

                {assessment.percentage !== null && (
                  <div className="flex items-center gap-3">
                    <Progress
                      value={assessment.percentage}
                      className="h-1.5 flex-1"
                    />
                    <span className="text-xs font-medium w-10 text-right">
                      {assessment.percentage}%
                    </span>
                  </div>
                )}

                {assessment.class_average !== null &&
                  assessment.percentage !== null && (
                    <p className="text-xs text-muted-foreground">
                      Class average: {assessment.class_average}%
                    </p>
                  )}
              </div>
            ))}

            {subject.assessments.length === 0 && (
              <p className="text-sm text-muted-foreground py-2">
                No assessments recorded yet.
              </p>
            )}
          </div>
        </CardContent>
      )}
    </Card>
  );
}
