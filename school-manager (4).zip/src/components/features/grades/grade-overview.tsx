"use client";

import { BookOpen, Award, BarChart3 } from "lucide-react";
import { StatCard } from "@/components/shared/stat-card";
import { getGradeLetter, getGradeRemark } from "@/lib/utils/format";
import type { GradesData } from "@/features/grades/hooks";

interface GradeOverviewProps {
  data: GradesData;
}

export function GradeOverview({ data }: GradeOverviewProps) {
  const totalSubjects = data.subjects.length;
  const gradedSubjects = data.subjects.filter((s) => s.average !== null).length;
  const overallGrade =
    data.overall_average !== null
      ? getGradeLetter(data.overall_average)
      : null;
  const remark =
    data.overall_average !== null
      ? getGradeRemark(data.overall_average)
      : null;

  // Best and worst subjects
  const sorted = [...data.subjects]
    .filter((s) => s.average !== null)
    .sort((a, b) => (b.average || 0) - (a.average || 0));
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Overall Average"
        value={
          data.overall_average !== null ? `${data.overall_average}%` : "—"
        }
        icon={BookOpen}
        description={
          overallGrade ? `Grade ${overallGrade} — ${remark}` : "No grades yet"
        }
        iconColor={
          data.overall_average !== null
            ? data.overall_average >= 60
              ? "text-emerald-600"
              : data.overall_average >= 45
                ? "text-amber-600"
                : "text-red-600"
            : undefined
        }
      />
      <StatCard
        title="Subjects Graded"
        value={`${gradedSubjects}/${totalSubjects}`}
        icon={BarChart3}
        description="Subjects with grades"
        iconColor="text-blue-600"
      />
      {best && (
        <StatCard
          title="Best Subject"
          value={best.name}
          icon={Award}
          description={`${best.average}% — ${getGradeLetter(best.average!)}`}
          iconColor="text-emerald-600"
        />
      )}
      {worst && worst.id !== best?.id && (
        <StatCard
          title="Needs Attention"
          value={worst.name}
          icon={BookOpen}
          description={`${worst.average}% — ${getGradeLetter(worst.average!)}`}
          iconColor="text-amber-600"
        />
      )}
    </div>
  );
}
