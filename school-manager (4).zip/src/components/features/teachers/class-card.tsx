"use client";

import Link from "next/link";
import { Users, BookOpen, CheckCircle2, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { TeacherClass } from "@/features/teachers/hooks";

interface ClassCardProps {
  cls: TeacherClass;
}

export function ClassCard({ cls }: ClassCardProps) {
  return (
    <Link
      href={`/teacher/classes/${cls.id}`}
      className="block rounded-lg border bg-card p-4 hover:border-primary/40 hover:shadow-sm transition-all"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-semibold text-base">{cls.name}</h3>
          <p className="text-xs text-muted-foreground">{cls.level}</p>
        </div>
        {cls.is_class_teacher && (
          <Badge variant="default" className="text-[10px] px-2 py-0.5">
            Class Teacher
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm mb-3">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <Users className="h-3.5 w-3.5" />
          <span>{cls.student_count} students</span>
        </div>
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <BookOpen className="h-3.5 w-3.5" />
          <span>{cls.subjects.length} subjects</span>
        </div>
      </div>

      {cls.subjects.length > 0 && (
        <div className="flex flex-wrap gap-1 mb-3">
          {cls.subjects.map((s) => (
            <Badge key={s.id} variant="secondary" className="text-[10px] font-normal">
              {s.name}
            </Badge>
          ))}
        </div>
      )}

      <div className="flex items-center gap-1.5 text-xs">
        {cls.attendance_marked_today ? (
          <>
            <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />
            <span className="text-green-700">Attendance marked today</span>
          </>
        ) : (
          <>
            <AlertCircle className="h-3.5 w-3.5 text-amber-500" />
            <span className="text-amber-600">Attendance pending</span>
          </>
        )}
      </div>
    </Link>
  );
}
