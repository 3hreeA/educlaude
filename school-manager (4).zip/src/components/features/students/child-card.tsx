"use client";

import Link from "next/link";
import { User, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatNaira, getInitials } from "@/lib/utils/format";
import type { ChildSummary } from "@/features/students/hooks";

const FEE_STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  paid: "success",
  current: "default",
  partial: "warning",
  overdue: "destructive",
};

interface ChildCardProps {
  child: ChildSummary;
}

export function ChildCard({ child }: ChildCardProps) {
  const initials = getInitials(child.first_name, child.last_name);
  const attendancePct = child.attendance_percentage;
  const feeStatus = child.fee_status || "current";

  return (
    <Link href={`/parent/children/${child.id}`}>
      <Card className="hover:shadow-md transition-shadow cursor-pointer group">
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-start gap-4">
            {/* Avatar */}
            <Avatar className="h-12 w-12 shrink-0">
              <AvatarImage src={child.photo_url || undefined} alt={child.first_name} />
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {initials}
              </AvatarFallback>
            </Avatar>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-base truncate">
                  {child.first_name} {child.last_name}
                </h3>
                <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
              </div>

              <p className="text-sm text-muted-foreground mt-0.5">
                {child.class_name} · {child.admission_number}
              </p>

              {/* Attendance bar */}
              <div className="mt-3 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Attendance</span>
                  <span className="font-medium">
                    {attendancePct !== null ? `${attendancePct}%` : "—"}
                  </span>
                </div>
                <Progress
                  value={attendancePct ?? 0}
                  className="h-2"
                  aria-label={`Attendance: ${attendancePct ?? 0}%`}
                />
              </div>

              {/* Fee status */}
              <div className="flex items-center justify-between mt-3">
                <Badge variant={FEE_STATUS_VARIANT[feeStatus] || "default"} className="text-xs capitalize">
                  {feeStatus === "paid" ? "Fees Paid" : feeStatus}
                </Badge>
                {child.fee_balance > 0 && (
                  <span className="text-xs font-medium text-amber-600">
                    {formatNaira(child.fee_balance)} due
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
