"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CreditCard, AlertTriangle, CheckCircle2, Clock, Loader2, ExternalLink } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { StatCard } from "@/components/shared/stat-card";
import { formatNaira, formatDate, formatDateTime } from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";
import { useInitializePayment } from "@/features/finance/hooks";
import type { FeeAccount, PaymentRecord, FeeSummary } from "@/features/fees/hooks";

// ─── Fee Summary Stats ────────────────────────────────────────────────

interface FeeSummaryCardsProps {
  summary: FeeSummary;
}

export function FeeSummaryCards({ summary }: FeeSummaryCardsProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Fees"
        value={formatNaira(summary.total_due)}
        icon={CreditCard}
        description="This academic session"
      />
      <StatCard
        title="Amount Paid"
        value={formatNaira(summary.total_paid)}
        icon={CheckCircle2}
        description={`${summary.total_due > 0 ? Math.round((summary.total_paid / summary.total_due) * 100) : 0}% paid`}
        iconColor="text-emerald-600"
      />
      <StatCard
        title="Outstanding"
        value={formatNaira(summary.total_balance)}
        icon={Clock}
        description={
          summary.total_balance > 0 ? "Payment required" : "All cleared"
        }
        iconColor={summary.total_balance > 0 ? "text-amber-600" : "text-emerald-600"}
      />
      <StatCard
        title="Overdue"
        value={summary.overdue_count}
        icon={AlertTriangle}
        description={
          summary.overdue_count > 0
            ? `${summary.overdue_count} fee${summary.overdue_count > 1 ? "s" : ""} overdue`
            : "No overdue fees"
        }
        iconColor={summary.overdue_count > 0 ? "text-red-600" : "text-emerald-600"}
      />
    </div>
  );
}

// ─── Fee Account List ──────────────────────────────────────────────────

const STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  paid: "success",
  current: "default",
  partial: "warning",
  overdue: "destructive",
};

interface FeeAccountListProps {
  accounts: FeeAccount[];
  showPay?: boolean;
}

export function FeeAccountList({ accounts, showPay = true }: FeeAccountListProps) {
  const [payAccount, setPayAccount] = useState<FeeAccount | null>(null);

  if (accounts.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-4">
        No fee accounts found.
      </p>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {accounts.map((account) => {
          const structure = account.fee_structures;
          const termName = (structure as any)?.terms?.name;
          const yearName = (structure as any)?.academic_years?.name;
          const paidPercent =
            account.total_amount > 0
              ? Math.round((account.amount_paid / account.total_amount) * 100)
              : 0;

          return (
            <Card key={account.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">
                      {structure?.name || "Fee"}
                    </h4>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {termName && yearName
                        ? `${termName} · ${yearName}`
                        : "Current session"}
                      {account.due_date &&
                        ` · Due: ${formatDate(account.due_date)}`}
                    </p>
                  </div>
                  <Badge
                    variant={STATUS_VARIANT[account.status] || "default"}
                    className="text-xs capitalize shrink-0"
                  >
                    {account.status}
                  </Badge>
                </div>

                <div className="mt-3 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {formatNaira(account.amount_paid)} of{" "}
                      {formatNaira(account.total_amount)}
                    </span>
                    <span className="font-medium">{paidPercent}%</span>
                  </div>
                  <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all",
                        paidPercent >= 100
                          ? "bg-emerald-500"
                          : paidPercent >= 50
                            ? "bg-amber-500"
                            : "bg-red-500"
                      )}
                      style={{ width: `${Math.min(paidPercent, 100)}%` }}
                    />
                  </div>
                  {account.balance > 0 && (
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-medium text-amber-600">
                        Balance: {formatNaira(account.balance)}
                      </p>
                      {showPay && (
                        <Button size="sm" variant="default" className="h-7 text-xs" onClick={() => setPayAccount(account)}>
                          <CreditCard className="h-3 w-3 mr-1" /> Pay Now
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {payAccount && (
        <PaymentDialog
          account={payAccount}
          open={!!payAccount}
          onClose={() => setPayAccount(null)}
        />
      )}
    </>
  );
}

// ─── Payment Dialog ────────────────────────────────────────────────────

function PaymentDialog({
  account,
  open,
  onClose,
}: {
  account: FeeAccount;
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const initPayment = useInitializePayment();
  const [amount, setAmount] = useState(String(account.balance));
  const [error, setError] = useState("");

  const handlePay = async () => {
    setError("");
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      setError("Enter a valid amount");
      return;
    }
    if (numAmount > account.balance) {
      setError(`Amount cannot exceed outstanding balance of ${formatNaira(account.balance)}`);
      return;
    }

    try {
      const result = await initPayment.mutateAsync({
        fee_account_id: account.id,
        amount: numAmount,
      });
      // Redirect to Paystack
      if (result.authorization_url) {
        window.location.href = result.authorization_url;
      } else {
        setError("Failed to get payment URL. Please try again.");
      }
    } catch (err: unknown) {
      setError((err as Error).message || "Payment initialization failed");
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-base">Pay School Fee</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="rounded-lg bg-muted p-3 text-sm space-y-1">
            <p className="font-medium">{account.fee_structures?.name || "Fee"}</p>
            <p className="text-xs text-muted-foreground">
              Outstanding: <span className="font-medium text-amber-600">{formatNaira(account.balance)}</span>
            </p>
          </div>

          <div className="space-y-2">
            <Label>Payment Amount (₦)</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              min={100}
              max={account.balance}
            />
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="text-xs h-7"
                onClick={() => setAmount(String(account.balance))}
              >
                Pay Full Balance
              </Button>
              {account.balance > 50000 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="text-xs h-7"
                  onClick={() => setAmount(String(Math.ceil(account.balance / 2)))}
                >
                  Pay Half
                </Button>
              )}
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            You&apos;ll be redirected to Paystack to complete the payment securely via card, bank transfer, or USSD.
          </p>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handlePay} disabled={initPayment.isPending}>
            {initPayment.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <ExternalLink className="h-4 w-4 mr-2" />
            )}
            Proceed to Pay {amount ? formatNaira(parseFloat(amount) || 0) : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Payment History ───────────────────────────────────────────────────

const PAYMENT_STATUS_VARIANT: Record<string, "default" | "success" | "destructive" | "warning"> = {
  success: "success",
  pending: "warning",
  failed: "destructive",
  refunded: "default",
};

const METHOD_LABELS: Record<string, string> = {
  card: "Card",
  bank_transfer: "Bank Transfer",
  ussd: "USSD",
  cash: "Cash",
};

interface PaymentHistoryProps {
  payments: PaymentRecord[];
}

export function PaymentHistory({ payments }: PaymentHistoryProps) {
  if (payments.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-4">
        No payment records found.
      </p>
    );
  }

  return (
    <div className="space-y-2">
      {payments.map((payment) => (
        <div
          key={payment.id}
          className="flex items-center justify-between gap-3 py-3 px-1 border-b last:border-0"
        >
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">
                {formatNaira(payment.amount)}
              </span>
              <Badge
                variant={PAYMENT_STATUS_VARIANT[payment.status] || "default"}
                className="text-[10px] capitalize"
              >
                {payment.status}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              {METHOD_LABELS[payment.payment_method] || payment.payment_method}
              {payment.receipt_number && ` · #${payment.receipt_number}`}
            </p>
          </div>
          <span className="text-xs text-muted-foreground shrink-0">
            {formatDateTime(payment.created_at)}
          </span>
        </div>
      ))}
    </div>
  );
}
