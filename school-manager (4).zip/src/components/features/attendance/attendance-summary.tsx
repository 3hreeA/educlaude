"use client";

import { CalendarCheck, CalendarX, Clock, ShieldCheck } from "lucide-react";
import { StatCard } from "@/components/shared/stat-card";
import type { AttendanceSummary as AttSummary } from "@/features/attendance/hooks";

interface AttendanceSummaryProps {
  summary: AttSummary;
}

export function AttendanceSummary({ summary }: AttendanceSummaryProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Attendance Rate"
        value={summary.percentage !== null ? `${summary.percentage}%` : "—"}
        icon={CalendarCheck}
        description={`${summary.present + summary.late} of ${summary.total} days`}
        iconColor={
          summary.percentage !== null
            ? summary.percentage >= 80
              ? "text-emerald-600"
              : summary.percentage >= 60
                ? "text-amber-600"
                : "text-red-600"
            : undefined
        }
      />
      <StatCard
        title="Days Present"
        value={summary.present}
        icon={CalendarCheck}
        description={`${summary.late} late arrivals`}
        iconColor="text-emerald-600"
      />
      <StatCard
        title="Days Absent"
        value={summary.absent}
        icon={CalendarX}
        description={
          summary.max_consecutive_absent > 0
            ? `Max ${summary.max_consecutive_absent} consecutive`
            : "No consecutive absences"
        }
        iconColor="text-red-600"
      />
      <StatCard
        title="Excused Days"
        value={summary.excused}
        icon={ShieldCheck}
        description="Approved absences"
        iconColor="text-blue-600"
      />
    </div>
  );
}
