"use client";

import { useMemo, useState } from "react";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  getDay,
  isSameMonth,
  subMonths,
  addMonths,
  isWeekend,
  parseISO,
} from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils/cn";
import type { AttendanceRecord } from "@/features/attendance/hooks";

const STATUS_COLORS: Record<string, string> = {
  present: "bg-emerald-500 text-white",
  late: "bg-amber-400 text-amber-900",
  absent: "bg-red-500 text-white",
  excused: "bg-blue-400 text-white",
};

const STATUS_LABELS: Record<string, string> = {
  present: "Present",
  late: "Late",
  absent: "Absent",
  excused: "Excused",
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface AttendanceCalendarProps {
  records: AttendanceRecord[];
}

export function AttendanceCalendar({ records }: AttendanceCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Build a map of date → status
  const recordMap = useMemo(() => {
    const map: Record<string, AttendanceRecord> = {};
    for (const r of records) {
      map[r.date] = r;
    }
    return map;
  }, [records]);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDay = getDay(monthStart); // 0=Sun

  return (
    <div>
      {/* Month navigation */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
          aria-label="Previous month"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <h3 className="font-semibold text-sm">
          {format(currentMonth, "MMMM yyyy")}
        </h3>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
          aria-label="Next month"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Weekday headers */}
      <div className="grid grid-cols-7 gap-1 mb-1">
        {WEEKDAYS.map((day) => (
          <div
            key={day}
            className="text-center text-xs font-medium text-muted-foreground py-1"
          >
            {day}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {/* Empty cells for start of month */}
        {Array.from({ length: startDay }).map((_, i) => (
          <div key={`empty-${i}`} className="aspect-square" />
        ))}

        {days.map((day) => {
          const dateStr = format(day, "yyyy-MM-dd");
          const record = recordMap[dateStr];
          const weekend = isWeekend(day);
          const today =
            format(new Date(), "yyyy-MM-dd") === dateStr;

          return (
            <div
              key={dateStr}
              className={cn(
                "aspect-square flex items-center justify-center rounded-md text-xs font-medium transition-colors",
                record ? STATUS_COLORS[record.status] : "",
                !record && weekend && "text-muted-foreground/40",
                !record && !weekend && "text-muted-foreground",
                today && !record && "ring-2 ring-primary ring-offset-1",
                "relative group"
              )}
              title={
                record
                  ? `${format(day, "dd/MM")} — ${STATUS_LABELS[record.status]}${record.notes ? `: ${record.notes}` : ""}`
                  : format(day, "dd/MM")
              }
            >
              {format(day, "d")}
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 mt-4 pt-3 border-t">
        {Object.entries(STATUS_LABELS).map(([key, label]) => (
          <div key={key} className="flex items-center gap-1.5">
            <div
              className={cn("h-3 w-3 rounded-sm", STATUS_COLORS[key])}
              aria-hidden="true"
            />
            <span className="text-xs text-muted-foreground">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
