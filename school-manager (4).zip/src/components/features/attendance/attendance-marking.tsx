"use client";

import { useState, useEffect, useCallback } from "react";
import { CheckCircle2, XCircle, Clock, ShieldCheck, Users, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { ClassStudent, AttendanceEntry, ExistingAttendance } from "@/features/teachers/hooks";

type Status = "present" | "absent" | "late" | "excused";

const STATUS_CONFIG: Record<Status, { label: string; color: string; bg: string; icon: any }> = {
  present: { label: "Present", color: "text-green-700", bg: "bg-green-50 border-green-200", icon: CheckCircle2 },
  absent:  { label: "Absent",  color: "text-red-700",   bg: "bg-red-50 border-red-200",     icon: XCircle },
  late:    { label: "Late",    color: "text-amber-700",  bg: "bg-amber-50 border-amber-200", icon: Clock },
  excused: { label: "Excused", color: "text-blue-700",   bg: "bg-blue-50 border-blue-200",   icon: ShieldCheck },
};

const STATUS_CYCLE: Status[] = ["present", "absent", "late", "excused"];

interface AttendanceMarkingProps {
  students: ClassStudent[];
  existingRecords?: ExistingAttendance[];
  onSubmit: (entries: AttendanceEntry[]) => void;
  isSubmitting?: boolean;
}

export function AttendanceMarking({
  students,
  existingRecords,
  onSubmit,
  isSubmitting = false,
}: AttendanceMarkingProps) {
  const [statuses, setStatuses] = useState<Map<string, Status>>(new Map());
  const [notes, setNotes] = useState<Map<string, string>>(new Map());
  const [activeNote, setActiveNote] = useState<string | null>(null);

  // Initialize from existing records or default to "present"
  useEffect(() => {
    const initial = new Map<string, Status>();
    const initialNotes = new Map<string, string>();

    if (existingRecords && existingRecords.length > 0) {
      for (const r of existingRecords) {
        initial.set(r.student_id, r.status);
        if (r.notes) initialNotes.set(r.student_id, r.notes);
      }
      // Fill any missing students as unmarked (no default)
      for (const s of students) {
        if (!initial.has(s.id)) initial.set(s.id, "present");
      }
    }
    // If no existing records, leave all unmarked until "Mark All Present" is clicked

    setStatuses(initial);
    setNotes(initialNotes);
  }, [students, existingRecords]);

  const markAllPresent = useCallback(() => {
    const newStatuses = new Map<string, Status>();
    for (const s of students) {
      newStatuses.set(s.id, "present");
    }
    setStatuses(newStatuses);
  }, [students]);

  const toggleStatus = useCallback((studentId: string) => {
    setStatuses((prev) => {
      const next = new Map(prev);
      const current = next.get(studentId) || "present";
      const idx = STATUS_CYCLE.indexOf(current);
      next.set(studentId, STATUS_CYCLE[(idx + 1) % STATUS_CYCLE.length]);
      return next;
    });
  }, []);

  const setStudentStatus = useCallback((studentId: string, status: Status) => {
    setStatuses((prev) => {
      const next = new Map(prev);
      next.set(studentId, status);
      return next;
    });
  }, []);

  const updateNote = useCallback((studentId: string, note: string) => {
    setNotes((prev) => {
      const next = new Map(prev);
      if (note.trim()) {
        next.set(studentId, note);
      } else {
        next.delete(studentId);
      }
      return next;
    });
  }, []);

  const handleSubmit = () => {
    const entries: AttendanceEntry[] = students.map((s) => ({
      student_id: s.id,
      status: statuses.get(s.id) || "present",
      notes: notes.get(s.id),
    }));
    onSubmit(entries);
  };

  const allMarked = statuses.size === students.length;
  const summary = {
    present: Array.from(statuses.values()).filter((s) => s === "present").length,
    absent: Array.from(statuses.values()).filter((s) => s === "absent").length,
    late: Array.from(statuses.values()).filter((s) => s === "late").length,
    excused: Array.from(statuses.values()).filter((s) => s === "excused").length,
  };

  return (
    <div className="space-y-4">
      {/* Quick Actions & Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <Button
          onClick={markAllPresent}
          variant="outline"
          className="gap-2"
          disabled={isSubmitting}
        >
          <Users className="h-4 w-4" />
          Mark All Present
        </Button>

        <div className="flex gap-3 text-sm">
          <span className="text-green-700 font-medium">{summary.present} Present</span>
          <span className="text-red-700 font-medium">{summary.absent} Absent</span>
          <span className="text-amber-700 font-medium">{summary.late} Late</span>
          <span className="text-blue-700 font-medium">{summary.excused} Excused</span>
        </div>
      </div>

      {/* Student Grid */}
      <div className="space-y-1.5">
        {students.map((student) => {
          const status = statuses.get(student.id);
          const config = status ? STATUS_CONFIG[status] : null;
          const hasNote = notes.has(student.id);
          const isNoteOpen = activeNote === student.id;

          return (
            <div key={student.id} className="space-y-0">
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors cursor-pointer select-none",
                  config ? config.bg : "bg-muted/30 border-border"
                )}
                onClick={() => toggleStatus(student.id)}
              >
                {/* Status Icon */}
                <div className="flex-shrink-0">
                  {config ? (
                    <config.icon className={cn("h-5 w-5", config.color)} />
                  ) : (
                    <div className="h-5 w-5 rounded-full border-2 border-muted-foreground/30" />
                  )}
                </div>

                {/* Student Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {student.last_name}, {student.first_name}
                  </p>
                  <p className="text-[11px] text-muted-foreground">{student.admission_number}</p>
                </div>

                {/* Status Badge */}
                {config && (
                  <Badge variant="outline" className={cn("text-[10px]", config.color, "border-current")}>
                    {config.label}
                  </Badge>
                )}

                {/* Note indicator & toggle */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveNote(isNoteOpen ? null : student.id);
                  }}
                  className={cn(
                    "flex-shrink-0 text-xs px-2 py-1 rounded",
                    hasNote ? "text-primary underline" : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {hasNote ? "Edit note" : "+ Note"}
                </button>

                {/* Quick status buttons (mobile tap targets) */}
                <div className="hidden sm:flex gap-1">
                  {STATUS_CYCLE.map((s) => {
                    const sc = STATUS_CONFIG[s];
                    return (
                      <button
                        key={s}
                        onClick={(e) => {
                          e.stopPropagation();
                          setStudentStatus(student.id, s);
                        }}
                        className={cn(
                          "w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold border transition-colors",
                          status === s
                            ? `${sc.bg} ${sc.color} border-current`
                            : "bg-muted/50 text-muted-foreground border-transparent hover:border-muted-foreground/30"
                        )}
                        title={sc.label}
                      >
                        {s[0].toUpperCase()}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Expandable Note Input */}
              {isNoteOpen && (
                <div className="ml-8 mr-2 mt-1 mb-2">
                  <input
                    type="text"
                    placeholder="Add a note (e.g., 'Medical excuse', 'Arrived at 9:15')"
                    value={notes.get(student.id) || ""}
                    onChange={(e) => updateNote(student.id, e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    className="w-full text-sm px-3 py-1.5 rounded border bg-background focus:outline-none focus:ring-1 focus:ring-primary"
                    autoFocus
                  />
                </div>
              )}

              {/* Medical alert */}
              {student.medical_notes && (
                <p className="ml-11 text-[10px] text-amber-600 mt-0.5">
                  ⚕️ {student.medical_notes}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Submit */}
      <div className="sticky bottom-0 bg-background/95 backdrop-blur pt-3 pb-2 border-t">
        <Button
          onClick={handleSubmit}
          disabled={!allMarked || isSubmitting}
          className="w-full gap-2"
          size="lg"
        >
          <Check className="h-4 w-4" />
          {isSubmitting ? "Saving..." : `Submit Attendance (${students.length} students)`}
        </Button>
        {!allMarked && (
          <p className="text-xs text-muted-foreground text-center mt-1.5">
            Tap "Mark All Present" first, then adjust exceptions
          </p>
        )}
      </div>
    </div>
  );
}
