"use client";

import { useRouter } from "next/navigation";
import { LogOut, Menu, User, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { NotificationBell } from "@/components/features/notifications/notification-bell";
import { useUIStore } from "@/stores/ui-store";
import { useOnline } from "@/lib/hooks";
import { getInitials } from "@/lib/utils/format";
import { createClient } from "@/lib/supabase/client";

interface HeaderProps {
  user: {
    first_name: string;
    last_name: string;
    email: string;
    role: string;
    avatar_url: string | null;
  };
}

export function Header({ user }: HeaderProps) {
  const router = useRouter();
  const { toggleSidebar } = useUIStore();
  const isOnline = useOnline();

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  };

  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-4 border-b bg-card px-4 lg:px-6">
      {/* Mobile menu toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        onClick={toggleSidebar}
        aria-label="Toggle navigation menu"
      >
        <Menu className="h-5 w-5" />
      </Button>

      <div className="flex-1" />

      {/* Online status indicator */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground" role="status">
        {isOnline ? (
          <><Wifi className="h-3.5 w-3.5 text-emerald-500" aria-hidden="true" /><span className="hidden sm:inline">Online</span></>
        ) : (
          <><WifiOff className="h-3.5 w-3.5 text-amber-500" aria-hidden="true" /><span className="hidden sm:inline">Offline</span></>
        )}
      </div>

      {/* Notifications */}
      <NotificationBell userRole={user.role} />

      {/* User menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-9 w-9 rounded-full" aria-label="User menu">
            <Avatar className="h-9 w-9">
              <AvatarImage src={user.avatar_url || undefined} alt={`${user.first_name} ${user.last_name}`} />
              <AvatarFallback className="text-xs font-semibold bg-primary/10 text-primary">
                {getInitials(user.first_name, user.last_name)}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium">{user.first_name} {user.last_name}</p>
              <p className="text-xs text-muted-foreground">{user.email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <User className="mr-2 h-4 w-4" /> Profile
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
            <LogOut className="mr-2 h-4 w-4" /> Log out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
