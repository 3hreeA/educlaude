"use client";

import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { MobileNav } from "./mobile-nav";
import type { NavItem } from "@/types/api";
import type { UserRole } from "@/types/database";

interface DashboardShellProps {
  children: React.ReactNode;
  user: {
    first_name: string;
    last_name: string;
    email: string;
    role: string;
    avatar_url: string | null;
  };
  navItems: NavItem[];
  role: UserRole;
  schoolName: string;
}

export function DashboardShell({ children, user, navItems, role, schoolName }: DashboardShellProps) {
  return (
    <TooltipProvider>
      <div className="flex h-screen overflow-hidden bg-background">
        <Sidebar navItems={navItems} role={role} schoolName={schoolName} />
        <MobileNav navItems={navItems} role={role} schoolName={schoolName} />
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header user={user} />
          <main className="flex-1 overflow-y-auto p-4 lg:p-6" id="main-content" role="main">
            {children}
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}
