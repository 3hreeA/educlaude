"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Users, CreditCard, Megaphone, BookOpen,
  ClipboardCheck, MessageSquare, GraduationCap, Shield,
  BarChart3, Settings, Banknote, ChevronLeft, ChevronRight,
  Calendar, CalendarCheck, Mail, Bell, Clock,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { useUIStore } from "@/stores/ui-store";
import type { NavItem } from "@/types/api";
import type { UserRole } from "@/types/database";

const ICON_MAP: Record<string, LucideIcon> = {
  LayoutDashboard, Users, CreditCard, Megaphone, BookOpen,
  ClipboardCheck, MessageSquare, GraduationCap, Shield,
  BarChart3, Settings, Banknote, Calendar, CalendarCheck,
  Mail, Bell, Clock,
};

interface SidebarProps {
  navItems: NavItem[];
  role: UserRole;
  schoolName: string;
}

export function Sidebar({ navItems, role, schoolName }: SidebarProps) {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebarCollapse } = useUIStore();

  return (
    <aside
      className={cn(
        "hidden lg:flex flex-col border-r bg-card transition-all duration-300",
        sidebarCollapsed ? "w-[68px]" : "w-[260px]"
      )}
      role="navigation"
      aria-label="Main navigation"
    >
      <div className="flex h-16 items-center gap-3 border-b px-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm">
          {schoolName.charAt(0)}
        </div>
        {!sidebarCollapsed && (
          <div className="flex flex-col overflow-hidden">
            <span className="truncate text-sm font-semibold">{schoolName}</span>
            <span className="truncate text-xs text-muted-foreground capitalize">{role} Portal</span>
          </div>
        )}
      </div>

      <nav className="flex-1 space-y-1 p-2 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = ICON_MAP[item.icon] || LayoutDashboard;
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");

          const linkEl = (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                sidebarCollapsed && "justify-center px-2"
              )}
              aria-current={isActive ? "page" : undefined}
            >
              <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
              {!sidebarCollapsed && <span className="truncate">{item.title}</span>}
              {!sidebarCollapsed && item.badge != null && item.badge > 0 && (
                <span className="ml-auto flex h-5 min-w-[20px] items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
                  {item.badge > 99 ? "99+" : item.badge}
                </span>
              )}
            </Link>
          );

          if (sidebarCollapsed) {
            return (
              <Tooltip key={item.href} delayDuration={0}>
                <TooltipTrigger asChild>{linkEl}</TooltipTrigger>
                <TooltipContent side="right" className="font-medium">{item.title}</TooltipContent>
              </Tooltip>
            );
          }
          return linkEl;
        })}
      </nav>

      <Separator />
      <div className="p-2">
        <Button
          variant="ghost"
          size={sidebarCollapsed ? "icon-sm" : "sm"}
          onClick={toggleSidebarCollapse}
          className={cn("w-full", sidebarCollapsed && "mx-auto")}
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {sidebarCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <><ChevronLeft className="h-4 w-4 mr-2" /><span>Collapse</span></>
          )}
        </Button>
      </div>
    </aside>
  );
}
