"use client";

import { useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { X, LayoutDashboard, Users, CreditCard, Megaphone, BookOpen,
  ClipboardCheck, MessageSquare, GraduationCap, Shield, BarChart3,
  Settings, Banknote, Calendar, CalendarCheck, Mail, Bell, Clock,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "@/components/ui/button";
import { useUIStore } from "@/stores/ui-store";
import type { NavItem } from "@/types/api";
import type { UserRole } from "@/types/database";

const ICON_MAP: Record<string, LucideIcon> = {
  LayoutDashboard, Users, CreditCard, Megaphone, BookOpen,
  ClipboardCheck, MessageSquare, GraduationCap, Shield,
  BarChart3, Settings, Banknote, Calendar, CalendarCheck,
  Mail, Bell, Clock,
};

interface MobileNavProps {
  navItems: NavItem[];
  role: UserRole;
  schoolName: string;
}

export function MobileNav({ navItems, role, schoolName }: MobileNavProps) {
  const pathname = usePathname();
  const { sidebarOpen, setSidebarOpen } = useUIStore();

  // Close on route change
  useEffect(() => {
    setSidebarOpen(false);
  }, [pathname, setSidebarOpen]);

  // Prevent body scroll when open
  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [sidebarOpen]);

  if (!sidebarOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 animate-fade-in"
        onClick={() => setSidebarOpen(false)}
        aria-hidden="true"
      />

      {/* Panel */}
      <div className="fixed inset-y-0 left-0 w-[280px] bg-card shadow-xl animate-slide-in">
        <div className="flex h-16 items-center justify-between border-b px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm">
              {schoolName.charAt(0)}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold">{schoolName}</span>
              <span className="text-xs text-muted-foreground capitalize">{role} Portal</span>
            </div>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={() => setSidebarOpen(false)} aria-label="Close menu">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <nav className="space-y-1 p-3" aria-label="Mobile navigation">
          {navItems.map((item) => {
            const Icon = ICON_MAP[item.icon] || LayoutDashboard;
            const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-3 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
                aria-current={isActive ? "page" : undefined}
              >
                <Icon className="h-5 w-5" aria-hidden="true" />
                <span>{item.title}</span>
                {item.badge != null && item.badge > 0 && (
                  <span className="ml-auto flex h-5 min-w-[20px] items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
                    {item.badge > 99 ? "99+" : item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
