"use client";

import * as React from "react";
import { cn } from "@/lib/utils/cn";

// ─── Lightweight Popover built with native HTML popover or absolute positioning ─────
// Simulates shadcn Popover API without @radix-ui/react-popover

interface PopoverContextType {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const PopoverContext = React.createContext<PopoverContextType>({
  open: false,
  setOpen: () => {},
});

// ─── Root ──────────────────────────────────────────────────────────────

interface PopoverProps {
  children: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

function Popover({ children, open: controlledOpen, onOpenChange }: PopoverProps) {
  const [internalOpen, setInternalOpen] = React.useState(false);
  const open = controlledOpen ?? internalOpen;

  const setOpen = React.useCallback(
    (val: boolean) => {
      setInternalOpen(val);
      onOpenChange?.(val);
    },
    [onOpenChange]
  );

  return (
    <PopoverContext.Provider value={{ open, setOpen }}>
      <div className="relative inline-block">{children}</div>
    </PopoverContext.Provider>
  );
}

// ─── Trigger ───────────────────────────────────────────────────────────

interface PopoverTriggerProps {
  children: React.ReactElement;
  asChild?: boolean;
}

const PopoverTrigger = React.forwardRef<HTMLButtonElement, PopoverTriggerProps>(
  function PopoverTrigger({ children, asChild }, ref) {
    const { open, setOpen } = React.useContext(PopoverContext);

    if (asChild && React.isValidElement(children)) {
      return React.cloneElement(children as React.ReactElement<Record<string, unknown>>, {
        ref,
        onClick: (e: React.MouseEvent) => {
          (children.props as Record<string, unknown>)?.onClick?.(e);
          setOpen(!open);
        },
        "aria-expanded": open,
      } as Record<string, unknown>);
    }

    return (
      <button ref={ref} onClick={() => setOpen(!open)} aria-expanded={open}>
        {children}
      </button>
    );
  }
);
PopoverTrigger.displayName = "PopoverTrigger";

// ─── Content ───────────────────────────────────────────────────────────

interface PopoverContentProps extends React.HTMLAttributes<HTMLDivElement> {
  align?: "start" | "center" | "end";
  sideOffset?: number;
}

const PopoverContent = React.forwardRef<HTMLDivElement, PopoverContentProps>(
  function PopoverContent({ className, align = "center", sideOffset = 4, children, ...props }, ref) {
    const { open, setOpen } = React.useContext(PopoverContext);
    const contentRef = React.useRef<HTMLDivElement>(null);

    // Close on outside click
    React.useEffect(() => {
      if (!open) return;
      function handleClick(e: MouseEvent) {
        const el = contentRef.current;
        if (el && !el.parentElement?.contains(e.target as Node)) {
          setOpen(false);
        }
      }
      // Delay to avoid closing from the trigger click
      const timer = setTimeout(() => document.addEventListener("mousedown", handleClick), 0);
      return () => {
        clearTimeout(timer);
        document.removeEventListener("mousedown", handleClick);
      };
    }, [open, setOpen]);

    // Close on Escape
    React.useEffect(() => {
      if (!open) return;
      function handleKey(e: KeyboardEvent) {
        if (e.key === "Escape") setOpen(false);
      }
      document.addEventListener("keydown", handleKey);
      return () => document.removeEventListener("keydown", handleKey);
    }, [open, setOpen]);

    if (!open) return null;

    const alignClasses =
      align === "end" ? "right-0" : align === "start" ? "left-0" : "left-1/2 -translate-x-1/2";

    return (
      <div
        ref={(node) => {
          (contentRef as React.MutableRefObject<HTMLDivElement | null>).current = node;
          if (typeof ref === "function") ref(node);
          else if (ref) ref.current = node;
        }}
        className={cn(
          "absolute z-50 rounded-md border bg-popover text-popover-foreground shadow-md",
          "animate-in fade-in-0 zoom-in-95",
          alignClasses,
          className
        )}
        style={{ top: `calc(100% + ${sideOffset}px)` }}
        {...props}
      >
        {children}
      </div>
    );
  }
);
PopoverContent.displayName = "PopoverContent";

export { Popover, PopoverTrigger, PopoverContent };
