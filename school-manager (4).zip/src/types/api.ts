import { z } from "zod";
import { UserRole } from "./database";

// ─── Auth Schemas ──────────────────────────────────────────────────────
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;

export const resetPasswordSchema = z
  .object({
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Must contain at least one uppercase letter")
      .regex(/[0-9]/, "Must contain at least one number"),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;

// ─── Navigation Types ──────────────────────────────────────────────────
export interface NavItem {
  title: string;
  href: string;
  icon: string;
  badge?: number;
  children?: NavItem[];
}

export const ROLE_DASHBOARDS: Record<UserRole, string> = {
  [UserRole.PARENT]: "/parent",
  [UserRole.TEACHER]: "/teacher",
  [UserRole.ADMIN]: "/admin",
  [UserRole.FINANCE]: "/finance",
};

export const ROLE_NAV_ITEMS: Record<UserRole, NavItem[]> = {
  [UserRole.PARENT]: [
    { title: "Dashboard", href: "/parent", icon: "LayoutDashboard" },
    { title: "My Children", href: "/parent/children", icon: "Users" },
    { title: "Fees & Payments", href: "/parent/fees", icon: "CreditCard" },
    { title: "Messages", href: "/parent/messages", icon: "MessageSquare" },
    { title: "Announcements", href: "/parent/announcements", icon: "Megaphone" },
  ],
  [UserRole.TEACHER]: [
    { title: "Dashboard", href: "/teacher", icon: "LayoutDashboard" },
    { title: "My Classes", href: "/teacher/classes", icon: "BookOpen" },
    { title: "Attendance", href: "/teacher/attendance", icon: "ClipboardCheck" },
    { title: "Feedback", href: "/teacher/feedback", icon: "MessageSquare" },
    { title: "Messages", href: "/teacher/messages", icon: "Mail" },
    { title: "Leave", href: "/teacher/leave", icon: "Calendar" },
    { title: "Announcements", href: "/teacher/announcements", icon: "Megaphone" },
  ],
  [UserRole.ADMIN]: [
    { title: "Dashboard", href: "/admin", icon: "LayoutDashboard" },
    { title: "Students", href: "/admin/students", icon: "GraduationCap" },
    { title: "Classes", href: "/admin/classes", icon: "BookOpen" },
    { title: "Teachers", href: "/admin/teachers", icon: "Users" },
    { title: "Timetable", href: "/admin/timetable", icon: "Clock" },
    { title: "Staff Attendance", href: "/admin/teacher-attendance", icon: "CalendarCheck" },
    { title: "Leave Requests", href: "/admin/leave", icon: "Calendar" },
    { title: "Discipline", href: "/admin/disciplinary", icon: "Shield" },
    { title: "Announcements", href: "/admin/announcements", icon: "Megaphone" },
    { title: "Reports", href: "/admin/reports", icon: "BarChart3" },
  ],
  [UserRole.FINANCE]: [
    { title: "Dashboard", href: "/finance", icon: "LayoutDashboard" },
    { title: "Fee Setup", href: "/finance/fees", icon: "Settings" },
    { title: "Outstanding", href: "/finance/fees/outstanding", icon: "Banknote" },
    { title: "Payment Plans", href: "/finance/payment-plans", icon: "Calendar" },
    { title: "Payments", href: "/finance/payments", icon: "CreditCard" },
    { title: "Reconciliation", href: "/finance/reconciliation", icon: "ClipboardCheck" },
    { title: "Reminders", href: "/finance/reminders", icon: "Bell" },
    { title: "Payroll", href: "/finance/payroll", icon: "Banknote" },
    { title: "Reports", href: "/finance/reports", icon: "BarChart3" },
  ],
};
