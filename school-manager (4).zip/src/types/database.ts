// ─── Enums ─────────────────────────────────────────────────────────────
export enum UserRole {
  PARENT = "parent",
  TEACHER = "teacher",
  ADMIN = "admin",
  FINANCE = "finance",
}

export enum AttendanceStatus {
  PRESENT = "present",
  ABSENT = "absent",
  LATE = "late",
  EXCUSED = "excused",
}

export enum PaymentMethod {
  CARD = "card",
  BANK_TRANSFER = "bank_transfer",
  USSD = "ussd",
  CASH = "cash",
}

export enum PaymentStatus {
  PENDING = "pending",
  SUCCESS = "success",
  FAILED = "failed",
  REFUNDED = "refunded",
}

export enum FeeAccountStatus {
  CURRENT = "current",
  OVERDUE = "overdue",
  PAID = "paid",
  PARTIAL = "partial",
}

export enum Gender {
  MALE = "male",
  FEMALE = "female",
}

export enum TermName {
  FIRST = "First Term",
  SECOND = "Second Term",
  THIRD = "Third Term",
}

export enum AnnouncementPriority {
  LOW = "low",
  NORMAL = "normal",
  HIGH = "high",
  URGENT = "urgent",
}

export enum IncidentSeverity {
  MINOR = "minor",
  MODERATE = "moderate",
  MAJOR = "major",
  SEVERE = "severe",
}

// ─── Base Entity ───────────────────────────────────────────────────────
export interface BaseEntity {
  id: string;
  created_at: string;
  updated_at: string;
}

// ─── Core Entities ─────────────────────────────────────────────────────
export interface School extends BaseEntity {
  name: string;
  address: string;
  phone: string;
  email: string;
  logo_url: string | null;
  motto: string | null;
  lga: string | null;
  state: string;
}

export interface User extends BaseEntity {
  auth_id: string;
  email: string;
  phone: string | null;
  first_name: string;
  last_name: string;
  role: UserRole;
  avatar_url: string | null;
  is_active: boolean;
  school_id: string;
  last_login_at: string | null;
}

export interface AcademicYear extends BaseEntity {
  school_id: string;
  name: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
}

export interface Term extends BaseEntity {
  academic_year_id: string;
  name: TermName;
  start_date: string;
  end_date: string;
  is_current: boolean;
}

export interface ClassGroup extends BaseEntity {
  school_id: string;
  name: string;
  level: string;
  arm: string | null;
  capacity: number;
  academic_year_id: string;
}

export interface Student extends BaseEntity {
  school_id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  middle_name: string | null;
  gender: Gender;
  date_of_birth: string;
  class_id: string;
  photo_url: string | null;
  blood_group: string | null;
  genotype: string | null;
  medical_notes: string | null;
  address: string | null;
  is_active: boolean;
  admission_date: string;
}

export interface Parent extends BaseEntity {
  user_id: string;
  occupation: string | null;
  employer: string | null;
  relationship: string;
  is_emergency_contact: boolean;
}

export interface Teacher extends BaseEntity {
  user_id: string;
  staff_id: string;
  qualification: string | null;
  specialization: string | null;
  date_joined: string;
  is_class_teacher: boolean;
}

export interface StudentParent extends BaseEntity {
  student_id: string;
  parent_id: string;
}

export interface TeacherAssignment extends BaseEntity {
  teacher_id: string;
  class_id: string;
  subject_id: string | null;
  is_class_teacher: boolean;
  academic_year_id: string;
}

// ─── Academic Entities ─────────────────────────────────────────────────
export interface Subject extends BaseEntity {
  school_id: string;
  name: string;
  code: string;
  is_compulsory: boolean;
}

export interface AttendanceRecord extends BaseEntity {
  student_id: string;
  class_id: string;
  date: string;
  status: AttendanceStatus;
  marked_by: string;
  term_id: string;
  notes: string | null;
}

export interface Assessment extends BaseEntity {
  class_id: string;
  subject_id: string;
  term_id: string;
  name: string;
  max_score: number;
  weight: number;
  date: string;
  created_by: string;
}

export interface Grade extends BaseEntity {
  student_id: string;
  assessment_id: string;
  score: number;
  remarks: string | null;
  entered_by: string;
}

// ─── Financial Entities ────────────────────────────────────────────────
export interface FeeType extends BaseEntity {
  school_id: string;
  name: string;
  description: string | null;
  is_recurring: boolean;
}

export interface FeeStructure extends BaseEntity {
  school_id: string;
  academic_year_id: string;
  term_id: string;
  class_id: string | null;
  name: string;
  total_amount: number;
  due_date: string;
}

export interface StudentFeeAccount extends BaseEntity {
  student_id: string;
  fee_structure_id: string;
  total_amount: number;
  amount_paid: number;
  balance: number;
  status: FeeAccountStatus;
  due_date: string;
}

export interface PaymentTransaction extends BaseEntity {
  fee_account_id: string;
  amount: number;
  payment_method: PaymentMethod;
  payment_reference: string;
  gateway_reference: string | null;
  status: PaymentStatus;
  paid_by: string;
  receipt_number: string | null;
}

// ─── Communication Entities ────────────────────────────────────────────
export interface Announcement extends BaseEntity {
  school_id: string;
  title: string;
  content: string;
  priority: AnnouncementPriority;
  target_roles: UserRole[];
  target_classes: string[] | null;
  published_by: string;
  published_at: string | null;
  expires_at: string | null;
}

export interface Notification extends BaseEntity {
  recipient_id: string;
  title: string;
  body: string;
  type: string;
  reference_id: string | null;
  reference_type: string | null;
  read_at: string | null;
  channel: "in_app" | "sms" | "whatsapp" | "email";
}

// ─── Disciplinary ──────────────────────────────────────────────────────
export interface DisciplinaryIncident extends BaseEntity {
  student_id: string;
  reported_by: string;
  date: string;
  description: string;
  severity: IncidentSeverity;
  action_taken: string | null;
  parent_notified: boolean;
  resolved: boolean;
}

// ─── Joined / View Types ───────────────────────────────────────────────
export interface StudentWithClass extends Student {
  class: Pick<ClassGroup, "id" | "name" | "level">;
}

export interface StudentSummary {
  id: string;
  admission_number: string;
  first_name: string;
  last_name: string;
  photo_url: string | null;
  class_name: string;
  attendance_percentage: number | null;
  current_average: number | null;
  fee_status: FeeAccountStatus | null;
}

export interface UserProfile extends User {
  parent?: Parent;
  teacher?: Teacher;
}

// ─── API Response Types ────────────────────────────────────────────────
export interface ApiResponse<T> {
  data: T;
  error: null;
}

export interface ApiError {
  data: null;
  error: {
    message: string;
    code: string;
    status: number;
  };
}

export type ApiResult<T> = ApiResponse<T> | ApiError;

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

// ─── Dashboard Stats ───────────────────────────────────────────────────
export interface ParentDashboardStats {
  children: StudentSummary[];
  unread_notifications: number;
  pending_fees: number;
  upcoming_events: number;
}

export interface TeacherDashboardStats {
  total_students: number;
  classes_today: number;
  pending_attendance: number;
  ungraded_assessments: number;
}

export interface AdminDashboardStats {
  total_students: number;
  total_teachers: number;
  total_classes: number;
  attendance_today_pct: number;
  pending_incidents: number;
  active_announcements: number;
}

export interface FinanceDashboardStats {
  total_revenue: number;
  outstanding_fees: number;
  collections_this_month: number;
  overdue_accounts: number;
  payroll_pending: boolean;
}
