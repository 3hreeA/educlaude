-- ============================================================================
-- Sprint 8: Notification Seed Data
-- Sample notifications for testing the notification bell and notifications page
-- ============================================================================

-- Insert sample notifications for parent users
INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at
)
SELECT
  u.id,
  u.school_id,
  'announcement',
  'PTA Meeting — February 2026',
  'The Parent-Teacher Association meeting for this term will hold on Saturday, 22nd February 2026 at 10:00 AM in the school hall.',
  '{"announcement_id": "pta-meeting"}'::jsonb,
  ARRAY['in_app'],
  NULL -- unread
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'fee_reminder',
  'School Fees Reminder',
  'This is a reminder that your child''s school fees for the Second Term are due. Please make payment at your earliest convenience to avoid disruption.',
  '{}'::jsonb,
  ARRAY['in_app', 'sms'],
  NULL, -- unread
  NOW() - INTERVAL '2 days'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'attendance_alert',
  'Absence Alert: Your Child Was Absent Today',
  'Your child was marked absent from school today. If this absence is excused, please contact the class teacher.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NOW() - INTERVAL '1 day', -- read
  NOW() - INTERVAL '3 days'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 3;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'grade_posted',
  'New Grades Posted: Mathematics',
  'New assessment grades have been posted for Mathematics. Log in to view your child''s performance.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NULL, -- unread
  NOW() - INTERVAL '5 hours'
FROM users u WHERE u.role = 'parent' AND u.is_active = true
LIMIT 5;

-- Insert sample notifications for teacher users
INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at
)
SELECT
  u.id,
  u.school_id,
  'announcement',
  'Staff Professional Development Day',
  'All teaching staff are required to attend the professional development workshop on Friday, 28th February 2026.',
  '{"announcement_id": "staff-pd"}'::jsonb,
  ARRAY['in_app'],
  NULL
FROM users u WHERE u.role = 'teacher' AND u.is_active = true
LIMIT 5;

INSERT INTO notifications (
  recipient_id, school_id, type, title, body, data, sent_via, read_at, created_at
)
SELECT
  u.id,
  u.school_id,
  'feedback',
  'Grade Submission Reminder',
  'Please submit all grades for Second Term assessments by Friday. Navigate to your class page to enter grades.',
  '{}'::jsonb,
  ARRAY['in_app'],
  NOW() - INTERVAL '12 hours', -- read
  NOW() - INTERVAL '2 days'
FROM users u WHERE u.role = 'teacher' AND u.is_active = true
LIMIT 3;
