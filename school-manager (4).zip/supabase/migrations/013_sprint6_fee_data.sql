-- ========================================================================
-- Sprint 6-7 Seed Data: Fee Types, Fee Structures, Student Fee Accounts
-- ========================================================================

-- Fee Types for the school
INSERT INTO fee_types (id, school_id, name, description, is_recurring) VALUES
  ('ft-tuition-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Tuition Fee', 'Core academic tuition fee', true),
  ('ft-develop-0001-0001-000000000002'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Development Levy', 'School development and infrastructure', true),
  ('ft-sports--0001-0001-000000000003'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Sports Fee', 'Sports and physical education activities', true),
  ('ft-techno--0001-0001-000000000004'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Technology Fee', 'ICT lab and computer resources', true),
  ('ft-examin--0001-0001-000000000005'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Examination Fee', 'Examination materials and administration', true),
  ('ft-unifrm--0001-0001-000000000006'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Uniform Fee', 'School uniforms and PE kits', false),
  ('ft-textbk--0001-0001-000000000007'::uuid,
   (SELECT id FROM schools LIMIT 1),
   'Textbook Fee', 'Required textbooks and workbooks', false);

-- Fee Structure for Primary 4B, Second Term 2025/2026
INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, class_id, name, total_amount, due_date) VALUES
  ('fs-p4b-t2-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   (SELECT id FROM academic_years WHERE is_current = true LIMIT 1),
   (SELECT id FROM terms WHERE is_current = true LIMIT 1),
   (SELECT id FROM classes WHERE name = 'Primary 4B' LIMIT 1),
   'Primary 4B - Second Term Fees',
   185000.00,
   '2026-01-20');

-- Fee Structure Items (breakdown of the ₦185,000)
INSERT INTO fee_structure_items (fee_structure_id, fee_type_id, amount) VALUES
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-tuition-0001-0001-000000000001'::uuid, 120000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-develop-0001-0001-000000000002'::uuid, 25000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-sports--0001-0001-000000000003'::uuid, 10000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-techno--0001-0001-000000000004'::uuid, 15000.00),
  ('fs-p4b-t2-0001-0001-000000000001'::uuid, 'ft-examin--0001-0001-000000000005'::uuid, 15000.00);

-- Fee Structure for Primary 1A, Second Term 2025/2026
INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, class_id, name, total_amount, due_date) VALUES
  ('fs-p1a-t2-0001-0001-000000000001'::uuid,
   (SELECT id FROM schools LIMIT 1),
   (SELECT id FROM academic_years WHERE is_current = true LIMIT 1),
   (SELECT id FROM terms WHERE is_current = true LIMIT 1),
   (SELECT id FROM classes WHERE name = 'Primary 1A' LIMIT 1),
   'Primary 1A - Second Term Fees',
   150000.00,
   '2026-01-20');

INSERT INTO fee_structure_items (fee_structure_id, fee_type_id, amount) VALUES
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-tuition-0001-0001-000000000001'::uuid, 100000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-develop-0001-0001-000000000002'::uuid, 20000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-sports--0001-0001-000000000003'::uuid, 10000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-techno--0001-0001-000000000004'::uuid, 10000.00),
  ('fs-p1a-t2-0001-0001-000000000001'::uuid, 'ft-examin--0001-0001-000000000005'::uuid, 10000.00);

-- Student Fee Accounts for ALL students in Primary 4B
-- Chidi Okafor (parent's child) — partially paid
INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, status, due_date)
SELECT
  'sfa-chidi-0001-0001-000000000001'::uuid,
  s.id,
  'fs-p4b-t2-0001-0001-000000000001'::uuid,
  185000.00,
  120000.00,
  'partial',
  '2026-01-20'
FROM students s WHERE s.admission_number = 'BFA/2024/001';

-- Remaining Primary 4B students — various payment states
INSERT INTO student_fee_accounts (student_id, fee_structure_id, total_amount, amount_paid, status, due_date)
SELECT
  s.id,
  'fs-p4b-t2-0001-0001-000000000001'::uuid,
  185000.00,
  CASE
    WHEN s.first_name IN ('Adaeze', 'Emeka', 'Fatima') THEN 185000.00  -- fully paid
    WHEN s.first_name IN ('Ikenna', 'Ngozi') THEN 100000.00            -- partial
    WHEN s.first_name IN ('Olumide', 'Sade') THEN 50000.00             -- partial
    ELSE 0.00                                                            -- unpaid
  END,
  CASE
    WHEN s.first_name IN ('Adaeze', 'Emeka', 'Fatima') THEN 'paid'::fee_account_status
    WHEN s.first_name IN ('Ikenna', 'Ngozi', 'Olumide', 'Sade') THEN 'partial'::fee_account_status
    WHEN s.first_name IN ('Tunde', 'Yetunde', 'Chisom', 'Damilola', 'Kelechi') THEN 'overdue'::fee_account_status
    ELSE 'current'::fee_account_status
  END,
  '2026-01-20'
FROM students s
JOIN classes c ON s.class_id = c.id
WHERE c.name = 'Primary 4B'
  AND s.admission_number != 'BFA/2024/001';

-- Sample payment transaction for Chidi's partial payment
INSERT INTO payment_transactions (
  fee_account_id, amount, payment_method, payment_reference,
  gateway_reference, status, paid_by, receipt_number, metadata
)
SELECT
  'sfa-chidi-0001-0001-000000000001'::uuid,
  120000.00,
  'card'::payment_method,
  'PAY-' || substr(md5(random()::text), 1, 12),
  'PSTK_' || substr(md5(random()::text), 1, 16),
  'success'::payment_status,
  u.id,
  'RCP-2026-00001',
  '{"channel": "paystack", "card_type": "visa", "last4": "4081"}'::jsonb
FROM users u WHERE u.email = 'parent@brightfuture.ng';

-- Sample payment for Adaeze (fully paid)
INSERT INTO payment_transactions (
  fee_account_id, amount, payment_method, payment_reference,
  gateway_reference, status, paid_by, receipt_number
)
SELECT
  sfa.id,
  185000.00,
  'bank_transfer'::payment_method,
  'PAY-' || substr(md5(random()::text), 1, 12),
  'PSTK_' || substr(md5(random()::text), 1, 16),
  'success'::payment_status,
  (SELECT id FROM users WHERE role = 'finance' LIMIT 1),
  'RCP-2026-00002'
FROM student_fee_accounts sfa
JOIN students s ON sfa.student_id = s.id
WHERE s.first_name = 'Adaeze' AND sfa.fee_structure_id = 'fs-p4b-t2-0001-0001-000000000001'::uuid
LIMIT 1;
