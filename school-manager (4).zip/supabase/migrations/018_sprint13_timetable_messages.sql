-- ============================================================================
-- Sprint 13–15: Timetable, Messaging, Fee Reminders
-- ============================================================================

-- ─── Timetable ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS timetable_slots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id UUID REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id UUID REFERENCES teachers(id) ON DELETE SET NULL,
  day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 1 AND 5), -- Mon=1..Fri=5
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  room VARCHAR(50),
  term_id UUID REFERENCES terms(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT no_overlap CHECK (end_time > start_time)
);

CREATE INDEX idx_timetable_class ON timetable_slots(class_id, day_of_week);
CREATE INDEX idx_timetable_teacher ON timetable_slots(teacher_id, day_of_week);

-- ─── Direct Messages (Parent ↔ Teacher) ──────────────────────────────
CREATE TABLE IF NOT EXISTS direct_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  thread_id UUID, -- group related messages
  subject VARCHAR(200),
  content TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dm_recipient ON direct_messages(recipient_id, read_at NULLS FIRST);
CREATE INDEX idx_dm_sender ON direct_messages(sender_id, created_at DESC);
CREATE INDEX idx_dm_thread ON direct_messages(thread_id, created_at);

-- ─── Fee Reminder Log ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fee_reminder_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_account_id UUID NOT NULL REFERENCES student_fee_accounts(id) ON DELETE CASCADE,
  channel TEXT NOT NULL, -- 'sms', 'whatsapp', 'email', 'push'
  message TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'sent', -- sent, delivered, failed
  sent_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_reminder_account ON fee_reminder_logs(fee_account_id, sent_at DESC);

-- ─── Seed: Timetable slots for a class ───────────────────────────────
DO $$
DECLARE
  v_school_id UUID;
  v_class_id UUID;
  v_term_id UUID;
  v_subjects UUID[];
  v_teachers UUID[];
  v_day INT;
  v_slot_idx INT;
  v_periods TIME[][] := ARRAY[
    ARRAY['08:00'::time, '08:45'::time],
    ARRAY['08:45'::time, '09:30'::time],
    ARRAY['09:45'::time, '10:30'::time],
    ARRAY['10:30'::time, '11:15'::time],
    ARRAY['11:30'::time, '12:15'::time],
    ARRAY['12:15'::time, '13:00'::time]
  ];
BEGIN
  SELECT id INTO v_school_id FROM schools LIMIT 1;
  SELECT id INTO v_class_id FROM classes WHERE school_id = v_school_id LIMIT 1;
  SELECT id INTO v_term_id FROM terms WHERE status = 'current' LIMIT 1;

  IF v_term_id IS NULL THEN
    SELECT id INTO v_term_id FROM terms ORDER BY start_date DESC LIMIT 1;
  END IF;

  SELECT ARRAY_AGG(id) INTO v_subjects FROM subjects WHERE school_id = v_school_id LIMIT 6;
  SELECT ARRAY_AGG(id) INTO v_teachers FROM teachers LIMIT 6;

  IF v_class_id IS NOT NULL AND v_subjects IS NOT NULL AND array_length(v_subjects, 1) > 0 THEN
    FOR v_day IN 1..5 LOOP
      FOR v_slot_idx IN 1..6 LOOP
        INSERT INTO timetable_slots (school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, term_id)
        VALUES (
          v_school_id, v_class_id,
          v_subjects[((v_day + v_slot_idx) % array_length(v_subjects, 1)) + 1],
          CASE WHEN v_teachers IS NOT NULL AND array_length(v_teachers, 1) > 0
            THEN v_teachers[((v_day + v_slot_idx) % array_length(v_teachers, 1)) + 1]
            ELSE NULL END,
          v_day,
          v_periods[v_slot_idx][1],
          v_periods[v_slot_idx][2],
          v_term_id
        )
        ON CONFLICT DO NOTHING;
      END LOOP;
    END LOOP;
  END IF;
END $$;
