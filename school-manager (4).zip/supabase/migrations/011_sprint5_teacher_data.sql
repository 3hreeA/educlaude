-- ============================================================================
-- Sprint 5 Seed Data: Teacher Assignments & Additional Students
-- Run AFTER 010_sprint3_seed_data.sql
-- ============================================================================

-- ─── Teacher Assignments (link teacher to classes + subjects) ──────────
DO $$
DECLARE
  teacher_id UUID;
  year_id UUID;
  math_id UUID;
  eng_id UUID;
  sci_id UUID;
  class_p4b UUID;
  class_p1a UUID;
BEGIN
  SELECT t.id INTO teacher_id FROM teachers t WHERE t.staff_id = 'TCH-001' LIMIT 1;
  SELECT ay.id INTO year_id FROM academic_years ay WHERE ay.is_current = true LIMIT 1;
  SELECT s.id INTO math_id FROM subjects s WHERE s.name = 'Mathematics' LIMIT 1;
  SELECT s.id INTO eng_id FROM subjects s WHERE s.name = 'English Language' LIMIT 1;
  SELECT s.id INTO sci_id FROM subjects s WHERE s.name = 'Basic Science' LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT c.id INTO class_p1a FROM classes c WHERE c.name = 'Primary 1A' LIMIT 1;

  IF teacher_id IS NULL OR year_id IS NULL THEN RETURN; END IF;

  -- Teacher is CLASS TEACHER of Primary 4B
  INSERT INTO teacher_assignments (teacher_id, class_id, subject_id, is_class_teacher, academic_year_id)
  VALUES
    (teacher_id, class_p4b, math_id, true,  year_id),
    (teacher_id, class_p4b, eng_id,  false, year_id),
    (teacher_id, class_p4b, sci_id,  false, year_id),
    (teacher_id, class_p1a, math_id, false, year_id)
  ON CONFLICT DO NOTHING;
END $$;

-- ─── Additional Students in Primary 4B (for realistic attendance/grades) ──
DO $$
DECLARE
  school_id UUID;
  class_p4b UUID;
  names TEXT[][] := ARRAY[
    ARRAY['Adaeze',  'Nwankwo',  'female'],
    ARRAY['Emeka',   'Chukwuma', 'male'],
    ARRAY['Fatima',  'Bello',    'female'],
    ARRAY['Ikenna',  'Obi',      'male'],
    ARRAY['Ngozi',   'Eze',      'female'],
    ARRAY['Olumide', 'Adebayo',  'male'],
    ARRAY['Sade',    'Ogundimu', 'female'],
    ARRAY['Tunde',   'Bakare',   'male'],
    ARRAY['Yetunde', 'Afolabi',  'female'],
    ARRAY['Chisom',  'Okeke',    'female'],
    ARRAY['Damilola','Olatunji', 'male'],
    ARRAY['Kelechi', 'Onu',      'male']
  ];
  i INT;
  dob DATE;
BEGIN
  SELECT s.id INTO school_id FROM schools s LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;

  IF school_id IS NULL OR class_p4b IS NULL THEN RETURN; END IF;

  FOR i IN 1..array_length(names, 1) LOOP
    dob := '2014-01-01'::DATE + (random() * 730)::INT; -- Random DOB 2014-2016
    INSERT INTO students (school_id, admission_number, first_name, last_name, gender, date_of_birth, class_id, is_active, admission_date)
    VALUES (
      school_id,
      'BFA-2025-' || LPAD((100 + i)::TEXT, 3, '0'),
      names[i][1],
      names[i][2],
      names[i][3]::gender_type,
      dob,
      class_p4b,
      true,
      '2023-09-01'
    )
    ON CONFLICT (admission_number) DO NOTHING;
  END LOOP;
END $$;

-- ─── Generate attendance for all Primary 4B students (today not yet marked) ──
-- This ensures the teacher has students to mark attendance for
DO $$
DECLARE
  term_id UUID;
  class_p4b UUID;
  teacher_user_id UUID;
  s RECORD;
  d DATE;
  day_count INT;
  status TEXT;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_p4b FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;

  IF term_id IS NULL OR class_p4b IS NULL THEN RETURN; END IF;

  -- For each student in class (except Chidi who already has attendance)
  FOR s IN
    SELECT st.id FROM students st
    WHERE st.class_id = class_p4b
      AND st.admission_number != 'BFA-2025-001'
      AND st.is_active = true
  LOOP
    d := CURRENT_DATE - INTERVAL '30 days';
    day_count := 0;
    WHILE d < CURRENT_DATE AND day_count < 22 LOOP
      IF EXTRACT(DOW FROM d) NOT IN (0, 6) THEN
        IF random() < 0.88 THEN status := 'present';
        ELSIF random() < 0.5 THEN status := 'late';
        ELSIF random() < 0.6 THEN status := 'excused';
        ELSE status := 'absent';
        END IF;

        INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
        VALUES (s.id, class_p4b, d, status, teacher_user_id, term_id)
        ON CONFLICT DO NOTHING;

        day_count := day_count + 1;
      END IF;
      d := d + 1;
    END LOOP;
  END LOOP;
END $$;
