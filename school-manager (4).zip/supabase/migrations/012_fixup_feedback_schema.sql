-- ============================================================================
-- Schema Fixup: Align student_feedback with application code
-- The original schema (002) used different column names than what the
-- application code and seed data expect. This migration reconciles them.
-- ============================================================================

-- Add missing columns that the app code expects
ALTER TABLE student_feedback
  ADD COLUMN IF NOT EXISTS feedback_type VARCHAR(50) DEFAULT 'academic',
  ADD COLUMN IF NOT EXISTS description TEXT;

-- Migrate existing data: copy content → description if content exists
UPDATE student_feedback SET description = content WHERE description IS NULL AND content IS NOT NULL;

-- Make term_id optional (feedback can be submitted without selecting a term)
ALTER TABLE student_feedback ALTER COLUMN term_id DROP NOT NULL;
