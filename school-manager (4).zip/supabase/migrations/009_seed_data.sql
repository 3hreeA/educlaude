-- Seed: Bright Future Academy test data
INSERT INTO schools (id, name, address, phone, email, motto, established_year, state, lga, level)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'Bright Future Academy',
  '15 Admiralty Way, Lekki Phase 1, Lagos',
  '+234 801 234 5678',
  'info@brightfutureacademy.ng',
  'Excellence in Education',
  2010, 'Lagos', 'Eti-Osa', 'primary_secondary'
);

INSERT INTO academic_years (id, school_id, name, start_date, end_date, is_current) VALUES
('00000000-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000001',
 '2025/2026', '2025-09-08', '2026-07-17', TRUE);

INSERT INTO terms (id, academic_year_id, name, start_date, end_date, is_current) VALUES
('00000000-0000-0000-0000-000000000011', '00000000-0000-0000-0000-000000000010', 'first',  '2025-09-08', '2025-12-12', FALSE),
('00000000-0000-0000-0000-000000000012', '00000000-0000-0000-0000-000000000010', 'second', '2026-01-12', '2026-04-03', TRUE),
('00000000-0000-0000-0000-000000000013', '00000000-0000-0000-0000-000000000010', 'third',  '2026-04-27', '2026-07-17', FALSE);

INSERT INTO classes (id, school_id, name, level, section, academic_year_id) VALUES
('00000000-0000-0000-0000-000000000020', '00000000-0000-0000-0000-000000000001', 'Primary 1A', 'Primary 1', 'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000021', '00000000-0000-0000-0000-000000000001', 'Primary 4B', 'Primary 4', 'B', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000022', '00000000-0000-0000-0000-000000000001', 'JSS 1A',     'JSS 1',     'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000023', '00000000-0000-0000-0000-000000000001', 'JSS 2A',     'JSS 2',     'A', '00000000-0000-0000-0000-000000000010'),
('00000000-0000-0000-0000-000000000024', '00000000-0000-0000-0000-000000000001', 'SSS 1A',     'SSS 1',     'A', '00000000-0000-0000-0000-000000000010');

INSERT INTO subjects (school_id, name, code, is_compulsory, level) VALUES
('00000000-0000-0000-0000-000000000001', 'Mathematics',     'MATH', TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'English Language', 'ENG',  TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Basic Science',   'BSC',  TRUE,  'primary'),
('00000000-0000-0000-0000-000000000001', 'Social Studies',  'SST',  TRUE,  'junior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Physics',         'PHY',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Chemistry',       'CHE',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Biology',         'BIO',  FALSE, 'senior_secondary'),
('00000000-0000-0000-0000-000000000001', 'Civic Education', 'CIV',  TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Computer Science','CS',   TRUE,  NULL),
('00000000-0000-0000-0000-000000000001', 'Yoruba',          'YOR',  TRUE,  NULL);

INSERT INTO fee_types (school_id, name, description, is_recurring, is_compulsory) VALUES
('00000000-0000-0000-0000-000000000001', 'Tuition Fee',       'Termly tuition',          TRUE,  TRUE),
('00000000-0000-0000-0000-000000000001', 'Development Levy',  'Annual development levy',  FALSE, TRUE),
('00000000-0000-0000-0000-000000000001', 'Books & Materials', 'Textbooks and materials',  TRUE,  TRUE),
('00000000-0000-0000-0000-000000000001', 'Uniform',           'School uniform',           FALSE, TRUE),
('00000000-0000-0000-0000-000000000001', 'Transport',         'School bus service',       TRUE,  FALSE),
('00000000-0000-0000-0000-000000000001', 'Feeding',           'School lunch program',     TRUE,  FALSE);

-- NOTE: Run 009b_seed_users.sql next to create the test user accounts.
