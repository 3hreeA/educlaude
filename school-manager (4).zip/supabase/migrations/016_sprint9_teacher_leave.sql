-- ============================================================================
-- Sprint 9–10: Teacher Attendance & Leave Management
-- ============================================================================

-- ─── Teacher Attendance (daily check-in / check-out) ──────────────────
CREATE TABLE IF NOT EXISTS teacher_attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  check_in TIMESTAMPTZ,
  check_out TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'present',  -- present, absent, late, excused, half_day
  notes TEXT,
  marked_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(teacher_id, date)
);

CREATE INDEX idx_teacher_att_date ON teacher_attendance(school_id, date);
CREATE INDEX idx_teacher_att_teacher ON teacher_attendance(teacher_id, date);

-- ─── Leave Requests ───────────────────────────────────────────────────
CREATE TYPE leave_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');

CREATE TABLE IF NOT EXISTS leave_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  leave_type TEXT NOT NULL DEFAULT 'personal',  -- sick, personal, annual, maternity, compassionate, study
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days_count INT NOT NULL DEFAULT 1,
  reason TEXT NOT NULL,
  status leave_status NOT NULL DEFAULT 'pending',
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_leave_teacher ON leave_requests(teacher_id);
CREATE INDEX idx_leave_status ON leave_requests(school_id, status);
CREATE INDEX idx_leave_dates ON leave_requests(start_date, end_date);

-- ─── Seed: Teacher attendance (last 10 school days) ───────────────────
INSERT INTO teacher_attendance (school_id, teacher_id, date, check_in, status, marked_by)
SELECT
  t2.school_id,
  t.id,
  d::date,
  (d + TIME '07:45:00')::timestamptz + (random() * INTERVAL '30 minutes'),
  CASE
    WHEN random() < 0.85 THEN 'present'
    WHEN random() < 0.92 THEN 'late'
    WHEN random() < 0.97 THEN 'absent'
    ELSE 'excused'
  END,
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1)
FROM teachers t
JOIN users t2 ON t.user_id = t2.id
CROSS JOIN generate_series(
  CURRENT_DATE - INTERVAL '13 days',
  CURRENT_DATE - INTERVAL '1 day',
  '1 day'
) d
WHERE EXTRACT(DOW FROM d) NOT IN (0, 6) -- skip weekends
ON CONFLICT (teacher_id, date) DO NOTHING;

-- ─── Seed: Sample leave requests ──────────────────────────────────────
INSERT INTO leave_requests (school_id, teacher_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by, reviewed_at)
SELECT
  u.school_id,
  t.id,
  'sick',
  CURRENT_DATE + INTERVAL '5 days',
  CURRENT_DATE + INTERVAL '6 days',
  2,
  'Feeling unwell, need to see the doctor and rest.',
  'pending',
  NULL,
  NULL
FROM teachers t
JOIN users u ON t.user_id = u.id
LIMIT 1;

INSERT INTO leave_requests (school_id, teacher_id, leave_type, start_date, end_date, days_count, reason, status, reviewed_by, reviewed_at)
SELECT
  u.school_id,
  t.id,
  'personal',
  CURRENT_DATE - INTERVAL '10 days',
  CURRENT_DATE - INTERVAL '9 days',
  2,
  'Family event — wedding ceremony.',
  'approved',
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1),
  NOW() - INTERVAL '15 days'
FROM teachers t
JOIN users u ON t.user_id = u.id
OFFSET 1 LIMIT 1;

-- ─── Seed: Sample disciplinary incidents ──────────────────────────────
INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'teacher' LIMIT 1),
  'minor',
  'resolved',
  'Late Coming',
  'Student arrived 30 minutes late to school without prior notice. This is the second occurrence this term.',
  'Verbal warning given. Parents contacted to discuss punctuality.',
  true
FROM students s WHERE s.is_active = true
LIMIT 1;

INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'teacher' LIMIT 1),
  'moderate',
  'investigating',
  'Disruptive Behaviour',
  'Student was repeatedly disruptive during English class, talking out of turn and distracting other students despite multiple warnings.',
  NULL,
  false
FROM students s WHERE s.is_active = true
OFFSET 2 LIMIT 1;

INSERT INTO disciplinary_incidents (
  school_id, student_id, reported_by, severity, status,
  category, description, action_taken, parent_notified, follow_up_date
)
SELECT
  s.school_id,
  s.id,
  (SELECT id FROM users WHERE role = 'admin' LIMIT 1),
  'major',
  'reported',
  'Bullying',
  'Student was reported by classmates for persistent intimidation and name-calling of a younger student during break time.',
  NULL,
  false,
  CURRENT_DATE + INTERVAL '3 days'
FROM students s WHERE s.is_active = true
OFFSET 4 LIMIT 1;
