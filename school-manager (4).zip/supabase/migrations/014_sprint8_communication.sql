-- ============================================================================
-- Sprint 8: Communication & Reports
-- Fixes schema, extends announcements, adds delivery tracking
-- ============================================================================

-- Fix: Rename target_audience → target_roles (user_role array) if needed
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_audience'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_roles'
  ) THEN
    ALTER TABLE announcements RENAME COLUMN target_audience TO target_roles;
    ALTER TABLE announcements ALTER COLUMN target_roles TYPE user_role[] USING target_roles::user_role[];
  END IF;
  
  -- Add target_roles if neither exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_roles'
  ) THEN
    ALTER TABLE announcements ADD COLUMN target_roles user_role[] DEFAULT ARRAY['parent','teacher']::user_role[];
  END IF;
END$$;

-- Fix: Add published_by column (separate from created_by) if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'published_by'
  ) THEN
    ALTER TABLE announcements ADD COLUMN published_by UUID REFERENCES users(id);
    -- Copy created_by to published_by
    UPDATE announcements SET published_by = created_by WHERE published_by IS NULL;
  END IF;
END$$;

-- Add delivery_channels column if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'delivery_channels'
  ) THEN
    ALTER TABLE announcements ADD COLUMN delivery_channels TEXT[] DEFAULT ARRAY['in_app'];
  END IF;
END$$;

-- Add target_classes column if not exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'target_classes'
  ) THEN
    ALTER TABLE announcements ADD COLUMN target_classes UUID[];
  END IF;
END$$;

-- Add scheduled_at column for future-dated announcements
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'announcements' AND column_name = 'scheduled_at'
  ) THEN
    ALTER TABLE announcements ADD COLUMN scheduled_at TIMESTAMPTZ;
  END IF;
END$$;

-- Announcement delivery tracking — one row per recipient per channel
CREATE TABLE IF NOT EXISTS announcement_deliveries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  announcement_id UUID NOT NULL REFERENCES announcements(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel TEXT NOT NULL DEFAULT 'in_app',         -- in_app, whatsapp, sms, email
  status TEXT NOT NULL DEFAULT 'pending',          -- pending, sent, delivered, failed
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_delivery_announcement ON announcement_deliveries(announcement_id);
CREATE INDEX IF NOT EXISTS idx_delivery_recipient ON announcement_deliveries(recipient_id);
CREATE INDEX IF NOT EXISTS idx_delivery_status ON announcement_deliveries(status);

-- ─── Seed: update existing announcements with delivery_channels ────────
UPDATE announcements
SET delivery_channels = ARRAY['in_app']
WHERE delivery_channels IS NULL;

-- ─── Additional sample announcements for testing ───────────────────────
INSERT INTO announcements (
  school_id, title, content, priority, target_roles, status,
  delivery_channels, published_by, published_at
)
VALUES
  (
    (SELECT id FROM schools LIMIT 1),
    'PTA Meeting — February 2026',
    'Dear Parents, the Parent-Teacher Association meeting for this term will hold on Saturday, 22nd February 2026 at 10:00 AM in the school hall. Agenda includes: academic progress review, upcoming events, and fee structure discussion for next session. Attendance is strongly encouraged. Light refreshments will be served.',
    'high',
    ARRAY['parent']::user_role[],
    'published',
    ARRAY['in_app', 'sms'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NOW() - INTERVAL '2 hours'
  ),
  (
    (SELECT id FROM schools LIMIT 1),
    'Staff Professional Development Day',
    'All teaching staff are required to attend the professional development workshop on Friday, 28th February 2026. Topic: "Effective Use of Technology in the Classroom". The session will run from 9:00 AM to 3:00 PM. Lunch will be provided. Students will have a free day.',
    'normal',
    ARRAY['teacher']::user_role[],
    'published',
    ARRAY['in_app'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NOW() - INTERVAL '6 hours'
  ),
  (
    (SELECT id FROM schools LIMIT 1),
    'Mid-Term Break Notice',
    'Please be informed that the mid-term break will be from Monday 3rd March to Friday 7th March 2026. Students resume on Monday 10th March. Please ensure your children revise their class notes during the break.',
    'normal',
    ARRAY['parent', 'teacher']::user_role[],
    'draft',
    ARRAY['in_app', 'whatsapp', 'sms'],
    (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
    NULL
  )
ON CONFLICT DO NOTHING;
