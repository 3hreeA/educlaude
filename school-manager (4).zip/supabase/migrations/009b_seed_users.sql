-- ============================================================================
-- Test User Accounts for School Manager
-- Creates Supabase Auth users + application users
-- Run this AFTER 009_seed_data.sql (school, classes, subjects must exist)
-- ============================================================================
-- 
-- TEST CREDENTIALS:
--   admin@brightfuture.ng    / TestPass123!  (Admin role)
--   teacher@brightfuture.ng  / TestPass123!  (Teacher role)
--   parent@brightfuture.ng   / TestPass123!  (Parent role)
--   finance@brightfuture.ng  / TestPass123!  (Finance role)
--
-- ============================================================================

-- Enable pgcrypto for password hashing (already enabled in Supabase)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─── Create Supabase Auth Users ──────────────────────────────────────
-- These go into auth.users (Supabase's built-in auth table)
-- Using deterministic UUIDs so we can reference them in the app users table

INSERT INTO auth.users (
  id, instance_id, email, encrypted_password,
  email_confirmed_at, created_at, updated_at,
  raw_app_meta_data, raw_user_meta_data,
  is_super_admin, role, aud, confirmation_token
)
VALUES
  -- Admin
  (
    'aaaa0000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000000',
    'admin@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Adewale","last_name":"Ogundimu"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Teacher
  (
    'aaaa0000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000000',
    'teacher@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Ngozi","last_name":"Eze"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Parent
  (
    'aaaa0000-0000-0000-0000-000000000003',
    '00000000-0000-0000-0000-000000000000',
    'parent@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Emeka","last_name":"Okafor"}',
    false, 'authenticated', 'authenticated', ''
  ),
  -- Finance
  (
    'aaaa0000-0000-0000-0000-000000000004',
    '00000000-0000-0000-0000-000000000000',
    'finance@brightfuture.ng',
    crypt('TestPass123!', gen_salt('bf')),
    NOW(), NOW(), NOW(),
    '{"provider":"email","providers":["email"]}',
    '{"first_name":"Funke","last_name":"Adeyemi"}',
    false, 'authenticated', 'authenticated', ''
  )
ON CONFLICT (id) DO NOTHING;

-- Also need identities for Supabase Auth to work properly
INSERT INTO auth.identities (
  id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at
)
VALUES
  (
    'aaaa0000-0000-0000-0000-000000000001',
    'aaaa0000-0000-0000-0000-000000000001',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000001', 'email', 'admin@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000001',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000002',
    'aaaa0000-0000-0000-0000-000000000002',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000002', 'email', 'teacher@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000002',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000003',
    'aaaa0000-0000-0000-0000-000000000003',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000003', 'email', 'parent@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000003',
    NOW(), NOW(), NOW()
  ),
  (
    'aaaa0000-0000-0000-0000-000000000004',
    'aaaa0000-0000-0000-0000-000000000004',
    jsonb_build_object('sub', 'aaaa0000-0000-0000-0000-000000000004', 'email', 'finance@brightfuture.ng'),
    'email', 'aaaa0000-0000-0000-0000-000000000004',
    NOW(), NOW(), NOW()
  )
ON CONFLICT DO NOTHING;

-- ─── Create Application Users ────────────────────────────────────────
-- These go into the public.users table (our app's user records)

INSERT INTO users (id, auth_id, email, phone, first_name, last_name, role, is_active, school_id)
VALUES
  (
    'dd000000-0000-0000-0000-000000000001',
    'aaaa0000-0000-0000-0000-000000000001',
    'admin@brightfuture.ng',
    '+234 802 111 1111',
    'Adewale', 'Ogundimu', 'admin', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000002',
    'aaaa0000-0000-0000-0000-000000000002',
    'teacher@brightfuture.ng',
    '+234 803 222 2222',
    'Ngozi', 'Eze', 'teacher', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000003',
    'aaaa0000-0000-0000-0000-000000000003',
    'parent@brightfuture.ng',
    '+234 804 333 3333',
    'Emeka', 'Okafor', 'parent', true,
    '00000000-0000-0000-0000-000000000001'
  ),
  (
    'dd000000-0000-0000-0000-000000000004',
    'aaaa0000-0000-0000-0000-000000000004',
    'finance@brightfuture.ng',
    '+234 805 444 4444',
    'Funke', 'Adeyemi', 'finance', true,
    '00000000-0000-0000-0000-000000000001'
  )
ON CONFLICT (email) DO UPDATE SET
  auth_id = EXCLUDED.auth_id,
  first_name = EXCLUDED.first_name,
  last_name = EXCLUDED.last_name;
