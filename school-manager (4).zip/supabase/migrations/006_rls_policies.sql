-- Enable RLS on all tables
DO $$ 
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- Helper functions
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS user_role AS $$
  SELECT role FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION get_user_school_id()
RETURNS UUID AS $$
  SELECT school_id FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION is_staff()
RETURNS BOOLEAN AS $$
  SELECT role IN ('admin', 'finance', 'super_admin') FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- School: members only
CREATE POLICY school_read ON schools FOR SELECT USING (id = get_user_school_id());

-- Users: same school
CREATE POLICY users_read ON users FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY users_update_self ON users FOR UPDATE USING (id = auth.uid());

-- Academic structure: same school read
CREATE POLICY ay_read ON academic_years FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY terms_read ON terms FOR SELECT USING (
  academic_year_id IN (SELECT id FROM academic_years WHERE school_id = get_user_school_id())
);
CREATE POLICY classes_read ON classes FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY classes_write ON classes FOR ALL USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY subjects_read ON subjects FOR SELECT USING (school_id = get_user_school_id());

-- Students: parents see own children, staff/teachers see all
CREATE POLICY students_read ON students FOR SELECT USING (
  school_id = get_user_school_id() AND (
    is_staff() OR get_user_role() = 'teacher' OR
    id IN (
      SELECT sp.student_id FROM student_parents sp
      JOIN parents p ON p.id = sp.parent_id WHERE p.user_id = auth.uid()
    )
  )
);
CREATE POLICY students_write ON students FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Parents / student_parents
CREATE POLICY parents_read ON parents FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY sp_read ON student_parents FOR SELECT USING (
  parent_id IN (SELECT id FROM parents WHERE school_id = get_user_school_id())
);

-- Teachers
CREATE POLICY teachers_read ON teachers FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY ta_read ON teacher_assignments FOR SELECT USING (
  teacher_id IN (SELECT id FROM teachers WHERE school_id = get_user_school_id())
);

-- Attendance: parents see own children, teachers/staff see all
CREATE POLICY attendance_read ON attendance_records FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id()) AND (
    is_staff() OR get_user_role() = 'teacher' OR
    student_id IN (
      SELECT sp.student_id FROM student_parents sp
      JOIN parents p ON p.id = sp.parent_id WHERE p.user_id = auth.uid()
    )
  )
);
CREATE POLICY attendance_write ON attendance_records FOR INSERT WITH CHECK (
  get_user_role() IN ('teacher', 'admin', 'super_admin')
);
CREATE POLICY attendance_edit ON attendance_records FOR UPDATE USING (
  get_user_role() IN ('teacher', 'admin', 'super_admin')
);

-- Grades
CREATE POLICY grades_read ON grades FOR SELECT USING (
  assessment_id IN (
    SELECT a.id FROM assessments a JOIN classes c ON c.id = a.class_id
    WHERE c.school_id = get_user_school_id()
  )
);
CREATE POLICY grades_write ON grades FOR ALL USING (get_user_role() IN ('teacher', 'admin', 'super_admin'));

-- Fees & Payments
CREATE POLICY fee_types_read ON fee_types FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY fee_structures_read ON fee_structures FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY fee_items_read ON fee_structure_items FOR SELECT USING (
  fee_structure_id IN (SELECT id FROM fee_structures WHERE school_id = get_user_school_id())
);
CREATE POLICY fee_accounts_read ON student_fee_accounts FOR SELECT USING (
  student_id IN (SELECT id FROM students WHERE school_id = get_user_school_id())
);
CREATE POLICY payments_read ON payment_transactions FOR SELECT USING (school_id = get_user_school_id());

-- Notifications: own only
CREATE POLICY notif_read ON notifications FOR SELECT USING (recipient_id = auth.uid());
CREATE POLICY notif_update ON notifications FOR UPDATE USING (recipient_id = auth.uid());

-- Announcements
CREATE POLICY ann_read ON announcements FOR SELECT USING (
  school_id = get_user_school_id() AND (status = 'published' OR is_staff())
);
CREATE POLICY ann_write ON announcements FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Assessments / Report Cards / Feedback
CREATE POLICY assessments_read ON assessments FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id())
);
CREATE POLICY rc_read ON report_cards FOR SELECT USING (
  class_id IN (SELECT id FROM classes WHERE school_id = get_user_school_id())
);
CREATE POLICY feedback_read ON student_feedback FOR SELECT USING (
  student_id IN (SELECT id FROM students WHERE school_id = get_user_school_id())
);

-- Disciplinary
CREATE POLICY disc_read ON disciplinary_incidents FOR SELECT USING (school_id = get_user_school_id());
CREATE POLICY disc_write ON disciplinary_incidents FOR ALL USING (school_id = get_user_school_id() AND is_staff());

-- Payroll (finance/admin only)
CREATE POLICY salary_read ON salary_structures FOR SELECT USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY payroll_read ON payroll_runs FOR SELECT USING (school_id = get_user_school_id() AND is_staff());
CREATE POLICY payslips_read ON payslips FOR SELECT USING (
  payroll_run_id IN (SELECT id FROM payroll_runs WHERE school_id = get_user_school_id())
);
