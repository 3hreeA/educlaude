-- ============================================================================
-- Sprint 3-4 Seed Data: Parent Feature Test Data
-- Run AFTER 009_seed_data.sql
-- ============================================================================

-- NOTE: This seed data references UUIDs from 009_seed_data.sql.
-- In a real deployment, the auth user IDs come from Supabase Auth.
-- Below we use deterministic UUIDs for testing.

-- ─── Parent and Student records ──────────────────────────────────────
-- (Assumes users were created in 009_seed_data.sql)

-- Create parent profile for parent user
INSERT INTO parents (id, user_id, occupation, employer, relationship, is_emergency_contact, school_id)
VALUES
  ('a0000000-0000-0000-0000-000000000001', 
   (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Software Engineer', 'Tech Solutions Ltd', 'Father', true,
   (SELECT id FROM schools LIMIT 1))
ON CONFLICT DO NOTHING;

-- Create 2 test students
INSERT INTO students (id, school_id, admission_number, first_name, last_name, gender, date_of_birth, class_id, is_active, admission_date)
VALUES
  ('b0000000-0000-0000-0000-000000000001',
   (SELECT id FROM schools LIMIT 1),
   'BFA-2025-001', 'Chidi', 'Okafor', 'male', '2015-03-15',
   (SELECT id FROM classes WHERE name = 'Primary 4B' LIMIT 1),
   true, '2023-09-01'),
  ('b0000000-0000-0000-0000-000000000002',
   (SELECT id FROM schools LIMIT 1),
   'BFA-2025-002', 'Amara', 'Okafor', 'female', '2017-07-22',
   (SELECT id FROM classes WHERE name = 'Primary 1A' LIMIT 1),
   true, '2024-09-01')
ON CONFLICT DO NOTHING;

-- Link parent to students
INSERT INTO student_parents (student_id, parent_id)
VALUES
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- ─── Teacher profile ─────────────────────────────────────────────────
INSERT INTO teachers (id, user_id, staff_id, qualification, specialization, date_joined, is_class_teacher, school_id)
VALUES
  ('c0000000-0000-0000-0000-000000000001',
   (SELECT id FROM users WHERE email = 'teacher@brightfuture.ng' LIMIT 1),
   'TCH-001', 'B.Ed Mathematics', 'Mathematics', '2020-01-15', true,
   (SELECT id FROM schools LIMIT 1))
ON CONFLICT DO NOTHING;

-- ─── Attendance Records (last 30 school days for Chidi) ──────────────
DO $$
DECLARE
  term_id UUID;
  class_id UUID;
  teacher_user_id UUID;
  d DATE;
  day_count INT := 0;
  status TEXT;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_id FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;

  IF term_id IS NULL OR class_id IS NULL THEN RETURN; END IF;

  d := CURRENT_DATE - INTERVAL '45 days';
  WHILE d <= CURRENT_DATE AND day_count < 35 LOOP
    -- Skip weekends
    IF EXTRACT(DOW FROM d) NOT IN (0, 6) THEN
      -- 85% present, 8% late, 5% absent, 2% excused
      IF random() < 0.85 THEN status := 'present';
      ELSIF random() < 0.6 THEN status := 'late';
      ELSIF random() < 0.7 THEN status := 'excused';
      ELSE status := 'absent';
      END IF;

      INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
      VALUES ('b0000000-0000-0000-0000-000000000001', class_id, d, status, teacher_user_id, term_id)
      ON CONFLICT DO NOTHING;

      -- Also for Amara (younger child)
      IF random() < 0.90 THEN status := 'present';
      ELSIF random() < 0.5 THEN status := 'late';
      ELSE status := 'absent';
      END IF;

      INSERT INTO attendance_records (student_id, class_id, date, status, marked_by, term_id)
      VALUES ('b0000000-0000-0000-0000-000000000002',
        (SELECT c2.id FROM classes c2 WHERE c2.name = 'Primary 1A' LIMIT 1),
        d, status, teacher_user_id, term_id)
      ON CONFLICT DO NOTHING;

      day_count := day_count + 1;
    END IF;
    d := d + 1;
  END LOOP;
END $$;

-- ─── Assessments and Grades for Chidi ────────────────────────────────
DO $$
DECLARE
  term_id UUID;
  class_id UUID;
  teacher_user_id UUID;
  math_id UUID;
  eng_id UUID;
  sci_id UUID;
  assess_id UUID;
BEGIN
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;
  SELECT c.id INTO class_id FROM classes c WHERE c.name = 'Primary 4B' LIMIT 1;
  SELECT u.id INTO teacher_user_id FROM users u WHERE u.email = 'teacher@brightfuture.ng' LIMIT 1;
  SELECT s.id INTO math_id FROM subjects s WHERE s.name = 'Mathematics' LIMIT 1;
  SELECT s.id INTO eng_id FROM subjects s WHERE s.name = 'English Language' LIMIT 1;
  SELECT s.id INTO sci_id FROM subjects s WHERE s.name = 'Basic Science' LIMIT 1;

  IF term_id IS NULL OR class_id IS NULL THEN RETURN; END IF;

  -- Mathematics assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000001', class_id, math_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 30, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000002', class_id, math_id, term_id, 'CA Test 2', 20, 10, CURRENT_DATE - 15, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000003', class_id, math_id, term_id, 'Mid-Term Exam', 60, 30, CURRENT_DATE - 7, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- English assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000004', class_id, eng_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 28, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000005', class_id, eng_id, term_id, 'Essay Writing', 20, 10, CURRENT_DATE - 14, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000006', class_id, eng_id, term_id, 'Mid-Term Exam', 60, 30, CURRENT_DATE - 7, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Science assessments
  INSERT INTO assessments (id, class_id, subject_id, term_id, name, max_score, weight, date, created_by)
  VALUES
    ('d0000000-0000-0000-0000-000000000007', class_id, sci_id, term_id, 'CA Test 1', 20, 10, CURRENT_DATE - 25, teacher_user_id),
    ('d0000000-0000-0000-0000-000000000008', class_id, sci_id, term_id, 'Lab Project', 20, 10, CURRENT_DATE - 12, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Grades for Chidi
  INSERT INTO grades (student_id, assessment_id, score, remarks, entered_by)
  VALUES
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 17, 'Excellent work', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000002', 15, 'Good improvement', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', 48, 'Strong performance', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004', 14, NULL, teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000005', 16, 'Creative writing', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000006', 42, NULL, teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000007', 18, 'Top of class', teacher_user_id),
    ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000008', 16, NULL, teacher_user_id)
  ON CONFLICT DO NOTHING;

  -- Some class-average grades (other students in same class)
  -- Simulated with 3 other "virtual" students to create class averages
  FOR i IN 1..3 LOOP
    INSERT INTO grades (student_id, assessment_id, score, entered_by)
    SELECT 
      gen_random_uuid(), -- virtual student (won't be linked to a real student)
      a.id,
      FLOOR(a.max_score * (0.45 + random() * 0.4)), -- 45-85% range
      teacher_user_id
    FROM assessments a
    WHERE a.class_id = class_id AND a.term_id = term_id
    ON CONFLICT DO NOTHING;
  END LOOP;
END $$;

-- ─── Fee Accounts ────────────────────────────────────────────────────
DO $$
DECLARE
  school_id UUID;
  year_id UUID;
  term_id UUID;
  fee_struct_id UUID;
BEGIN
  SELECT s.id INTO school_id FROM schools s LIMIT 1;
  SELECT ay.id INTO year_id FROM academic_years ay WHERE ay.is_current = true LIMIT 1;
  SELECT t.id INTO term_id FROM terms t WHERE t.is_current = true LIMIT 1;

  IF school_id IS NULL OR year_id IS NULL THEN RETURN; END IF;

  -- Create fee structure
  INSERT INTO fee_structures (id, school_id, academic_year_id, term_id, name, total_amount, due_date)
  VALUES
    ('e0000000-0000-0000-0000-000000000001', school_id, year_id, term_id,
     'First Term Fees 2025/2026', 185000, CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  fee_struct_id := 'e0000000-0000-0000-0000-000000000001';

  -- Fee account for Chidi (partially paid)
  INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, balance, status, due_date)
  VALUES
    ('f0000000-0000-0000-0000-000000000001',
     'b0000000-0000-0000-0000-000000000001',
     fee_struct_id, 185000, 120000, 65000, 'partial',
     CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  -- Fee account for Amara (fully paid)
  INSERT INTO student_fee_accounts (id, student_id, fee_structure_id, total_amount, amount_paid, balance, status, due_date)
  VALUES
    ('f0000000-0000-0000-0000-000000000002',
     'b0000000-0000-0000-0000-000000000002',
     fee_struct_id, 150000, 150000, 0, 'paid',
     CURRENT_DATE - 15)
  ON CONFLICT DO NOTHING;

  -- Payment transactions
  INSERT INTO payment_transactions (fee_account_id, amount, payment_method, payment_reference, status, receipt_number, paid_by)
  VALUES
    ('f0000000-0000-0000-0000-000000000001', 80000, 'bank_transfer', 'PAY-2025-001', 'success', 'RCT-001',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1)),
    ('f0000000-0000-0000-0000-000000000001', 40000, 'card', 'PAY-2025-002', 'success', 'RCT-002',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1)),
    ('f0000000-0000-0000-0000-000000000002', 150000, 'bank_transfer', 'PAY-2025-003', 'success', 'RCT-003',
     (SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1))
  ON CONFLICT DO NOTHING;
END $$;

-- ─── Student Feedback ────────────────────────────────────────────────
INSERT INTO student_feedback (student_id, teacher_id, feedback_type, category, description)
VALUES
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'positive',
   'Chidi showed excellent leadership during the group mathematics project. He helped his teammates understand fractions and was very patient with those who were struggling.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'academic', 'positive',
   'Outstanding performance in the mid-term mathematics exam. Chidi scored the highest in the class.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'concern',
   'Chidi was talking during assembly today. He has been warned to pay attention during school events.'),
  ('b0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001',
   'academic', 'neutral',
   'English essay showed good ideas but needs improvement in grammar and punctuation. Recommend extra practice with writing exercises at home.'),
  ('b0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000001',
   'behavioral', 'positive',
   'Amara is very well-behaved and always eager to participate in class activities. She is a joy to teach.')
ON CONFLICT DO NOTHING;

-- ─── Announcements ────────────────────────────────────────────────────
INSERT INTO announcements (school_id, title, content, priority, target_roles, status, published_by, published_at)
VALUES
  ((SELECT id FROM schools LIMIT 1),
   'Second Term Resumption Date',
   'Dear Parents, please be informed that the second term will commence on Monday, 13th January 2026. All students are expected to resume promptly by 8:00 AM. Please ensure all outstanding fees are settled before resumption. School uniforms must be clean and complete. Thank you for your cooperation.',
   'high',
   ARRAY['parent', 'teacher']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '3 days'),

  ((SELECT id FROM schools LIMIT 1),
   'Inter-House Sports Competition',
   'The annual inter-house sports competition will take place on Friday, 24th January 2026 at the school sports field. Events include: 100m dash, long jump, sack race, relay, and tug of war. Parents are welcome to attend and cheer on their children. Please ensure your child wears their house colour t-shirt. Refreshments will be available.',
   'normal',
   ARRAY['parent', 'teacher']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '1 day'),

  ((SELECT id FROM schools LIMIT 1),
   'PTA Meeting Notice',
   'A Parents-Teachers Association meeting is scheduled for Saturday, 18th January 2026 at 10:00 AM in the school hall. Key agenda items include: review of first term academic performance, second term plans and activities, school infrastructure improvements, and fee payment schedule discussion. Your attendance is highly encouraged.',
   'normal',
   ARRAY['parent']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '5 hours'),

  ((SELECT id FROM schools LIMIT 1),
   'Important: Updated School Drop-off Policy',
   'For the safety of all students, we are implementing a new drop-off and pick-up policy effective immediately. Parents must not drive beyond the school gate. A supervised drop-off zone has been designated at the front parking area. School buses will use the side entrance. Please cooperate with security personnel.',
   'urgent',
   ARRAY['parent']::user_role[],
   'published',
   (SELECT id FROM users WHERE email = 'admin@brightfuture.ng' LIMIT 1),
   NOW() - INTERVAL '12 hours')
ON CONFLICT DO NOTHING;

-- ─── Notifications ───────────────────────────────────────────────────
INSERT INTO notifications (recipient_id, title, body, type, channel)
VALUES
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'New Grade Posted', 'Mid-Term Mathematics exam grades have been posted for Chidi.', 'grade_posted', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Fee Payment Reminder', 'Outstanding balance of ₦65,000 for Chidi. Please settle before the deadline.', 'fee_reminder', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'New Announcement', 'Important: Updated School Drop-off Policy', 'announcement', 'in_app'),
  ((SELECT id FROM users WHERE email = 'parent@brightfuture.ng' LIMIT 1),
   'Teacher Feedback', 'New feedback from Mrs. Adeyemi for Chidi regarding classroom behaviour.', 'feedback', 'in_app')
ON CONFLICT DO NOTHING;
