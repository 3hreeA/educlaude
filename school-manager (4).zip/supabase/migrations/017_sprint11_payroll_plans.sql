-- ============================================================================
-- Sprint 11–12: Payroll Seed Data & Payment Plans
-- ============================================================================

-- Add unique constraint on salary_structures for upsert support
DO $$ BEGIN
  ALTER TABLE salary_structures ADD CONSTRAINT uq_salary_school_teacher UNIQUE (school_id, teacher_id);
EXCEPTION WHEN duplicate_table THEN NULL;
END $$;

-- ─── Payment Plans table ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payment_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  fee_account_id UUID NOT NULL REFERENCES student_fee_accounts(id) ON DELETE CASCADE,
  total_amount NUMERIC(12,2) NOT NULL,
  installments INT NOT NULL DEFAULT 3,
  amount_per_installment NUMERIC(12,2) NOT NULL,
  start_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',  -- active, completed, defaulted, cancelled
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_plan_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  plan_id UUID NOT NULL REFERENCES payment_plans(id) ON DELETE CASCADE,
  installment_number INT NOT NULL,
  due_date DATE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  paid BOOLEAN DEFAULT FALSE,
  paid_at TIMESTAMPTZ,
  transaction_id UUID REFERENCES payment_transactions(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_payment_plans_account ON payment_plans(fee_account_id);
CREATE INDEX idx_plan_items_plan ON payment_plan_items(plan_id);
CREATE INDEX idx_plan_items_due ON payment_plan_items(due_date, paid);

-- ─── Seed: Salary structures for all teachers ────────────────────────
INSERT INTO salary_structures (school_id, teacher_id, basic_salary, housing_allowance, transport_allowance, meal_allowance, effective_date)
SELECT
  u.school_id,
  t.id,
  CASE
    WHEN t.qualification ILIKE '%PhD%' OR t.qualification ILIKE '%Doctor%' THEN 250000
    WHEN t.qualification ILIKE '%M.Ed%' OR t.qualification ILIKE '%M.Sc%' OR t.qualification ILIKE '%Master%' THEN 200000
    ELSE 150000
  END AS basic_salary,
  CASE
    WHEN t.qualification ILIKE '%PhD%' OR t.qualification ILIKE '%Doctor%' THEN 50000
    WHEN t.qualification ILIKE '%M.Ed%' OR t.qualification ILIKE '%M.Sc%' OR t.qualification ILIKE '%Master%' THEN 40000
    ELSE 30000
  END AS housing_allowance,
  15000 AS transport_allowance,
  10000 AS meal_allowance,
  '2025-09-01'::date
FROM teachers t
JOIN users u ON t.user_id = u.id
WHERE u.is_active = true
ON CONFLICT DO NOTHING;

-- ─── Seed: A completed payroll run for last month ─────────────────────
INSERT INTO payroll_runs (school_id, month, year, status, processed_by, processed_at)
SELECT
  u.school_id,
  EXTRACT(MONTH FROM CURRENT_DATE - INTERVAL '1 month')::int,
  EXTRACT(YEAR FROM CURRENT_DATE - INTERVAL '1 month')::int,
  'approved',
  u.id,
  NOW() - INTERVAL '5 days'
FROM users u WHERE u.role = 'finance' LIMIT 1
ON CONFLICT (school_id, month, year) DO NOTHING;

-- ─── Seed: Payslips for last month's run ──────────────────────────────
INSERT INTO payslips (payroll_run_id, teacher_id, gross_salary, tax_paye, pension, nhf, other_deductions, net_salary, bank_name, account_number)
SELECT
  pr.id,
  ss.teacher_id,
  ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance AS gross,
  -- Approximate PAYE (simplified)
  GREATEST(0, ROUND(
    CASE
      WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 300000 THEN
        (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 * 0.07 / 12
      WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 600000 THEN
        (300000 * 0.07 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 300000) * 0.11) / 12
      ELSE
        (300000 * 0.07 + 300000 * 0.11 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 600000) * 0.15) / 12
    END, 2)) AS tax_paye,
  -- Pension: 8% employee contribution
  ROUND(ss.basic_salary * 0.08, 2) AS pension,
  -- NHF: 2.5% of basic
  ROUND(ss.basic_salary * 0.025, 2) AS nhf,
  0 AS other_deductions,
  -- Net (computed later)
  (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance)
    - GREATEST(0, ROUND(
        CASE
          WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 300000 THEN
            (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 * 0.07 / 12
          WHEN (ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 <= 600000 THEN
            (300000 * 0.07 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 300000) * 0.11) / 12
          ELSE
            (300000 * 0.07 + 300000 * 0.11 + ((ss.basic_salary + ss.housing_allowance + ss.transport_allowance + ss.meal_allowance) * 12 - 600000) * 0.15) / 12
        END, 2))
    - ROUND(ss.basic_salary * 0.08, 2)
    - ROUND(ss.basic_salary * 0.025, 2) AS net_salary,
  (ARRAY['GTBank', 'Zenith Bank', 'First Bank', 'Access Bank', 'UBA'])[FLOOR(random() * 5 + 1)] AS bank_name,
  LPAD(FLOOR(random() * 9000000000 + 1000000000)::text, 10, '0') AS account_number
FROM salary_structures ss
CROSS JOIN payroll_runs pr
WHERE pr.status = 'approved'
ON CONFLICT (payroll_run_id, teacher_id) DO NOTHING;

-- ─── Seed: A sample payment plan ─────────────────────────────────────
DO $$
DECLARE
  v_account_id UUID;
  v_plan_id UUID;
  v_user_id UUID;
  v_balance NUMERIC;
BEGIN
  SELECT id, balance INTO v_account_id, v_balance
  FROM student_fee_accounts
  WHERE status IN ('current', 'overdue', 'partial') AND balance > 0
  LIMIT 1;

  SELECT id INTO v_user_id FROM users WHERE role = 'finance' LIMIT 1;

  IF v_account_id IS NOT NULL AND v_balance > 0 THEN
    INSERT INTO payment_plans (fee_account_id, total_amount, installments, amount_per_installment, start_date, status, created_by)
    VALUES (v_account_id, v_balance, 3, ROUND(v_balance / 3, 2), CURRENT_DATE, 'active', v_user_id)
    RETURNING id INTO v_plan_id;

    INSERT INTO payment_plan_items (plan_id, installment_number, due_date, amount) VALUES
      (v_plan_id, 1, CURRENT_DATE + INTERVAL '7 days', ROUND(v_balance / 3, 2)),
      (v_plan_id, 2, CURRENT_DATE + INTERVAL '37 days', ROUND(v_balance / 3, 2)),
      (v_plan_id, 3, CURRENT_DATE + INTERVAL '67 days', v_balance - 2 * ROUND(v_balance / 3, 2));
  END IF;
END $$;
