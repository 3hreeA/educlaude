# Deployment & Troubleshooting Guide

## Deployment Options

### Option 1: Replit

1. Create new Repl → Import from GitHub
2. Set `.replit` run command: `npm run build && npm start`
3. Add all environment variables in Secrets tab
4. Click Run

### Option 2: Vercel (Recommended for Production)

1. Push code to GitHub
2. Import project in Vercel dashboard
3. Framework: Next.js (auto-detected)
4. Set environment variables
5. Deploy

**Vercel Settings:**
- Build Command: `npm run build`
- Output Directory: `.next`
- Node.js Version: 18.x or 20.x

### Option 3: Railway

1. Connect GitHub repo
2. Set environment variables
3. Railway auto-detects Next.js
4. Custom start: `npm start`

## Supabase Setup

1. Create project at supabase.com
2. Go to SQL Editor
3. Run each migration file in order (001 through 018)
4. Enable Row Level Security on all tables
5. Copy project URL and anon key to `.env.local`
6. Enable Email auth in Authentication → Providers

**Important:** Run migrations in numerical order. Each depends on the previous.

## Post-Deployment Checklist

- [ ] All environment variables set
- [ ] Database migrations run successfully
- [ ] Seed data loaded (009_seed_data.sql)
- [ ] Login works with test accounts
- [ ] Role-based routing redirects correctly
- [ ] Payment gateway in test mode
- [ ] WhatsApp/SMS in sandbox mode

## Troubleshooting

### "Unauthorized" on all API calls
- Check `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- Verify Supabase project is not paused
- Clear browser cookies and re-login

### "Failed to fetch" errors
- Check if Supabase free tier has hit rate limits
- Verify RLS policies allow the user's role to access the data
- Check browser console for CORS errors

### Login redirects back to login page
- Ensure the `users` table has a row matching the auth user's `auth_id`
- Check middleware.ts for role-routing logic
- Verify cookies are being set (check Application → Cookies in DevTools)

### Payroll calculations seem wrong
- PAYE uses consolidated relief allowance (higher of ₦200k or 1% of gross + 20% of gross)
- Pension is 8% of basic salary only (not gross)
- NHF is 2.5% of basic salary
- Verify salary_structures has correct basic vs allowance breakdown

### Payments not processing
- Ensure Paystack keys match environment (test vs live)
- Check webhook URL is accessible from Paystack servers
- Verify callback URL is correct

### Notifications not showing
- Check notifications table has rows for the user
- Verify polling interval (60s default) in notification hooks
- Check that `recipient_id` matches the user's `id` in users table

### Build fails
- Run `npm run type-check` to find TypeScript errors
- Check for missing environment variables (build-time vs runtime)
- Ensure all dependencies are in package.json

## Performance Tips

- Enable Supabase connection pooling for production
- Use Vercel Edge caching for static pages
- Keep images on Cloudinary with auto-format/quality
- Monitor Supabase dashboard for slow queries
- Consider upgrading Supabase plan if hitting free tier limits

## Security Notes

- All API routes check authentication and role authorization
- Financial transactions have immutable audit trails
- Passwords require 8+ chars with uppercase and numbers
- Session timeout: 30 minutes of inactivity (Supabase default)
- CSP headers configured in next.config.js
- HTTPS enforced via HSTS header
