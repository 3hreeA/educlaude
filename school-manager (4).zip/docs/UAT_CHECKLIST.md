# School Manager — UAT Test Checklist
## User Acceptance Testing for Pilot Rollout

**Pilot scope:** 2–3 classes, ~50–100 students, all 4 user roles

---

## Pre-UAT Setup

- [ ] Application deployed and accessible at production URL
- [ ] Supabase Auth users created for all testers
- [ ] `auth_id` linked in `users` table for each tester
- [ ] Seed data cleared / replaced with real school data (or use seed for testing)
- [ ] Paystack in test mode with test cards available
- [ ] All notification channels configured (even if disabled initially)
- [ ] Admin account created for school principal
- [ ] Finance account created for bursar

---

## Test Suite 1: Authentication & Access Control

### 1.1 Login / Logout
| # | Test | Role | Pass? |
|---|------|------|-------|
| 1 | Login with valid email/password | All | ☐ |
| 2 | Incorrect password shows error | All | ☐ |
| 3 | Forgot password sends reset email | All | ☐ |
| 4 | Password reset works with new password | All | ☐ |
| 5 | Logout clears session and redirects to login | All | ☐ |
| 6 | Accessing protected page redirects to login | - | ☐ |

### 1.2 Role-Based Routing
| # | Test | Expected |
|---|------|----------|
| 7 | Parent login → redirects to /parent | ☐ |
| 8 | Teacher login → redirects to /teacher | ☐ |
| 9 | Admin login → redirects to /admin | ☐ |
| 10 | Finance login → redirects to /finance | ☐ |
| 11 | Parent cannot access /admin pages (URL manipulation) | ☐ |
| 12 | Teacher cannot access /finance pages | ☐ |

---

## Test Suite 2: Parent Module

### 2.1 Dashboard
| # | Test | Pass? |
|---|------|-------|
| 13 | Dashboard loads with child summary cards | ☐ |
| 14 | Multiple children shown (if applicable) | ☐ |
| 15 | Attendance percentage displayed correctly | ☐ |
| 16 | Recent grades visible | ☐ |
| 17 | Fee balance shown | ☐ |

### 2.2 Attendance
| # | Test | Pass? |
|---|------|-------|
| 18 | Attendance calendar loads with colour coding | ☐ |
| 19 | Can toggle between months | ☐ |
| 20 | Present/Absent/Late/Excused shown correctly | ☐ |
| 21 | Attendance percentage matches records | ☐ |

### 2.3 Grades
| # | Test | Pass? |
|---|------|-------|
| 22 | Current term grades load for all subjects | ☐ |
| 23 | Assessment breakdown visible when expanded | ☐ |
| 24 | Class average comparison shown | ☐ |
| 25 | Teacher comments displayed | ☐ |

### 2.4 Fees & Payments
| # | Test | Pass? |
|---|------|-------|
| 26 | Fee balance displays with breakdown | ☐ |
| 27 | Payment history shows past transactions | ☐ |
| 28 | "Pay Now" opens Paystack checkout | ☐ |
| 29 | Partial payment accepted | ☐ |
| 30 | Full payment succeeds (test card) | ☐ |
| 31 | Balance updates after payment | ☐ |
| 32 | Digital receipt viewable/downloadable | ☐ |
| 33 | Payment failure handled gracefully | ☐ |

### 2.5 Messages
| # | Test | Pass? |
|---|------|-------|
| 34 | Conversation inbox loads | ☐ |
| 35 | Unread count badge shows correctly | ☐ |
| 36 | Can open and read thread | ☐ |
| 37 | Can reply to a teacher message | ☐ |
| 38 | New message appears in thread | ☐ |

### 2.6 Announcements
| # | Test | Pass? |
|---|------|-------|
| 39 | Announcement feed loads | ☐ |
| 40 | Can read full announcement | ☐ |
| 41 | Priority badge shown for urgent announcements | ☐ |

---

## Test Suite 3: Teacher Module

### 3.1 Attendance Marking
| # | Test | Pass? |
|---|------|-------|
| 42 | Class roster loads with student names | ☐ |
| 43 | "Mark All Present" works | ☐ |
| 44 | Can mark individual students as Absent/Late/Excused | ☐ |
| 45 | Submit saves attendance with confirmation | ☐ |
| 46 | Attendance appears in parent view within minutes | ☐ |
| 47 | Can edit today's attendance before end of day | ☐ |
| 48 | Attendance marking works on mobile browser | ☐ |

### 3.2 Grade Entry
| # | Test | Pass? |
|---|------|-------|
| 49 | Grade entry grid loads for selected class/subject | ☐ |
| 50 | Can enter numeric grades for all students | ☐ |
| 51 | Validation prevents grades > 100 or < 0 | ☐ |
| 52 | Can save as draft | ☐ |
| 53 | Can submit final grades | ☐ |
| 54 | Grades appear in parent view after submission | ☐ |

### 3.3 Student Feedback
| # | Test | Pass? |
|---|------|-------|
| 55 | Can select student and add feedback | ☐ |
| 56 | Category and severity options work | ☐ |
| 57 | Feedback visible in parent view | ☐ |

### 3.4 Messages
| # | Test | Pass? |
|---|------|-------|
| 58 | Conversation inbox loads | ☐ |
| 59 | Can compose new message to a parent | ☐ |
| 60 | Can reply in existing thread | ☐ |
| 61 | Message appears in parent's inbox | ☐ |

### 3.5 Leave Management
| # | Test | Pass? |
|---|------|-------|
| 62 | Can submit leave request | ☐ |
| 63 | Leave request shows in pending state | ☐ |
| 64 | Status updates when admin approves/rejects | ☐ |

---

## Test Suite 4: Admin Module

### 4.1 Student Management
| # | Test | Pass? |
|---|------|-------|
| 65 | Student list loads with search and filters | ☐ |
| 66 | Student registration wizard completes all steps | ☐ |
| 67 | New student appears in student list | ☐ |
| 68 | Can view/edit individual student profile | ☐ |
| 69 | Student appears in class roster for teacher | ☐ |

### 4.2 Class Management
| # | Test | Pass? |
|---|------|-------|
| 70 | Class list loads | ☐ |
| 71 | Can create new class | ☐ |
| 72 | Student count per class is accurate | ☐ |

### 4.3 Teacher Management
| # | Test | Pass? |
|---|------|-------|
| 73 | Teacher list loads with performance indicators | ☐ |
| 74 | Individual teacher profile accessible | ☐ |
| 75 | Teacher attendance marking works | ☐ |
| 76 | Leave request approval/rejection works | ☐ |

### 4.4 Timetable
| # | Test | Pass? |
|---|------|-------|
| 77 | Can select a class and view timetable | ☐ |
| 78 | Can add a new timetable slot | ☐ |
| 79 | Conflict detection prevents double-booking | ☐ |
| 80 | Can delete a slot | ☐ |

### 4.5 Discipline
| # | Test | Pass? |
|---|------|-------|
| 81 | Can log a disciplinary incident | ☐ |
| 82 | Incident appears in student history | ☐ |
| 83 | Severity and action fields save correctly | ☐ |

### 4.6 Announcements
| # | Test | Pass? |
|---|------|-------|
| 84 | Can compose and send announcement | ☐ |
| 85 | Target audience filter works (all, grade, class) | ☐ |
| 86 | Announcement appears in parent/teacher feeds | ☐ |

### 4.7 Reports
| # | Test | Pass? |
|---|------|-------|
| 87 | Report page loads with options | ☐ |
| 88 | Can generate and view a report | ☐ |
| 89 | PDF export downloads correctly | ☐ |
| 90 | Excel export downloads correctly | ☐ |

---

## Test Suite 5: Finance Module

### 5.1 Fee Management
| # | Test | Pass? |
|---|------|-------|
| 91 | Fee types list loads | ☐ |
| 92 | Can create a fee structure | ☐ |
| 93 | Can assign fee accounts to students | ☐ |
| 94 | Outstanding fees list loads with aging | ☐ |

### 5.2 Payment Plans
| # | Test | Pass? |
|---|------|-------|
| 95 | Can create installment plan for a student | ☐ |
| 96 | Installment schedule generated correctly | ☐ |
| 97 | Progress bar shows paid vs remaining | ☐ |

### 5.3 Reconciliation
| # | Test | Pass? |
|---|------|-------|
| 98 | Daily reconciliation page loads with date selector | ☐ |
| 99 | Transaction summary matches payment records | ☐ |
| 100 | Can manually reconcile a transaction | ☐ |

### 5.4 Fee Reminders
| # | Test | Pass? |
|---|------|-------|
| 101 | Can select aging and channels | ☐ |
| 102 | Sending reminders creates log entries | ☐ |
| 103 | Reminder history displays correctly | ☐ |

### 5.5 Payroll
| # | Test | Pass? |
|---|------|-------|
| 104 | Salary setup page shows all teachers | ☐ |
| 105 | Can edit salary components (basic, allowances) | ☐ |
| 106 | Generate payroll creates a draft run | ☐ |
| 107 | Payslips show correct PAYE/pension/NHF deductions | ☐ |
| 108 | Can approve payroll run | ☐ |
| 109 | NIBSS CSV download works | ☐ |
| 110 | Can mark payroll as paid | ☐ |

### 5.6 Reports
| # | Test | Pass? |
|---|------|-------|
| 111 | Financial reports page loads | ☐ |
| 112 | PDF/Excel export works | ☐ |

---

## Test Suite 6: Cross-Cutting

### 6.1 Mobile Responsiveness
| # | Test | Pass? |
|---|------|-------|
| 113 | Login page renders well on mobile | ☐ |
| 114 | Dashboard fits mobile screen without horizontal scroll | ☐ |
| 115 | Mobile navigation menu opens/closes | ☐ |
| 116 | Attendance marking usable on phone | ☐ |
| 117 | Fee payment flow works on mobile | ☐ |
| 118 | Tables scroll horizontally on small screens | ☐ |

### 6.2 Notifications
| # | Test | Pass? |
|---|------|-------|
| 119 | In-app notifications appear in header bell icon | ☐ |
| 120 | Notification count badge updates | ☐ |
| 121 | Clicking notification navigates to relevant page | ☐ |
| 122 | Marking notification as read works | ☐ |

### 6.3 PWA / Offline
| # | Test | Pass? |
|---|------|-------|
| 123 | "Add to Home Screen" prompt appears on mobile | ☐ |
| 124 | App icon appears on home screen | ☐ |
| 125 | Offline indicator appears when disconnected | ☐ |
| 126 | Offline fallback page shown for uncached routes | ☐ |

### 6.4 Performance
| # | Test | Pass? |
|---|------|-------|
| 127 | Pages load within 3 seconds on 4G | ☐ |
| 128 | No visible layout shifts during load | ☐ |
| 129 | App doesn't freeze during data-heavy operations | ☐ |

---

## Issue Logging Template

For any failures, log:

| Field | Value |
|-------|-------|
| Test # | |
| Description | |
| Expected | |
| Actual | |
| Device/Browser | |
| Screenshot | |
| Severity | Critical / High / Medium / Low |
| Steps to Reproduce | |

---

## Sign-Off

| Role | Tester Name | Date | Pass? | Notes |
|------|------------|------|-------|-------|
| Admin | | | ☐ | |
| Teacher | | | ☐ | |
| Parent | | | ☐ | |
| Finance | | | ☐ | |

**UAT approved by:** _____________________ Date: _____________
