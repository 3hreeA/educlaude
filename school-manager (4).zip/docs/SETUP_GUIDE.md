# School Manager — Operational Setup Guide
## From Zip to Running Application

---

## Step 1: Supabase Setup (Database & Auth)

### 1.1 Create a Supabase Project

1. Go to [supabase.com](https://supabase.com) and sign in (or create an account)
2. Click **New Project**
3. Fill in:
   - **Name:** `school-manager`
   - **Database Password:** Choose a strong password (save this!)
   - **Region:** Choose closest to Nigeria (e.g., `West EU (London)`)
4. Click **Create new project** — wait ~2 minutes for provisioning

### 1.2 Get Your API Keys

1. In your Supabase project, go to **Settings → API**
2. Copy these values:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon (public) key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role (secret) key** → `SUPABASE_SERVICE_ROLE_KEY`

> ⚠️ Never expose the `service_role` key in client-side code.

### 1.3 Run Database Migrations

**Option A: Single file (recommended)**
1. Go to **SQL Editor** in your Supabase dashboard
2. Open the file `scripts/setup-database.sql` from the project
3. Paste the entire contents into the SQL Editor
4. Click **Run** (this takes 10-30 seconds)

**Option B: One migration at a time**
1. Go to **SQL Editor**
2. Run each file in `supabase/migrations/` in numerical order:
   - `001_core_schema.sql` → `018_sprint13_timetable_messages.sql`
3. Run each one separately and check for errors before proceeding

### 1.4 Verify Database Setup

After running migrations, verify in **Table Editor**:
- You should see 30+ tables
- The `school` table should have one row (seed data)
- The `users` table should have 4+ users (admin, teacher, parent, finance)

### 1.5 Configure Supabase Auth

1. Go to **Authentication → Providers**
2. Ensure **Email** provider is enabled
3. Go to **Authentication → URL Configuration**
4. Set **Site URL** to your app URL (e.g., `http://localhost:3000` for dev)
5. Add redirect URLs:
   - `http://localhost:3000/**` (development)
   - `https://your-domain.com/**` (production)

---

## Step 2: Project Setup

### 2.1 Extract & Install

```bash
# Extract the zip
unzip school-manager.zip -d school-manager
cd school-manager

# Install dependencies
npm install
```

### 2.2 Environment Variables

```bash
# Copy the template
cp .env.example .env.local
```

Edit `.env.local` with your values:

```env
# ─── REQUIRED ─────────────────────────────────────────
NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJ...your-anon-key
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJ...your-service-role-key

NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=School Manager

# ─── PAYMENTS (set up in Step 3) ──────────────────────
PAYSTACK_SECRET_KEY=sk_test_xxxxx
NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY=pk_test_xxxxx
PAYSTACK_TEST_MODE=true

# ─── NOTIFICATIONS (set up in Step 4) ────────────────
WHATSAPP_ENABLED=false
SMS_ENABLED=false
EMAIL_ENABLED=false

# ─── CRON (set up in Step 5 if using Vercel) ─────────
CRON_SECRET=generate-a-random-string-here
```

### 2.3 Test Locally

```bash
npm run dev
```

Open http://localhost:3000 — you should see the login page.

### 2.4 Test Login

Use seed data credentials (created by the migration):

| Role    | Email                       | Password      |
|---------|-----------------------------|---------------|
| Admin   | admin@brightfuture.ng       | TestPass123!  |
| Teacher | teacher@brightfuture.ng     | TestPass123!  |
| Parent  | parent@brightfuture.ng      | TestPass123!  |
| Finance | finance@brightfuture.ng     | TestPass123!  |

> **Note:** The seed migration (`009b_seed_users.sql`) creates both Supabase Auth users and application users automatically. No manual user creation needed.

---

## Step 3: Paystack Setup (Payments)

### 3.1 Create Paystack Account

1. Go to [paystack.com](https://paystack.com) and sign up
2. Complete business verification (KYC)
3. Go to **Settings → API Keys & Webhooks**
4. Copy:
   - **Test Secret Key** → `PAYSTACK_SECRET_KEY`
   - **Test Public Key** → `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY`

### 3.2 Configure Webhook

1. In Paystack dashboard, go to **Settings → API Keys & Webhooks**
2. Set **Webhook URL**: `https://your-domain.com/api/webhooks/paystack`
3. Copy the **Webhook Secret** for verification

### 3.3 Test Payments

Use Paystack test cards:
- **Success:** 4084 0840 8408 4081, Expiry: any future date, CVV: 408
- **Failed:** 4084 0840 8408 4085

### 3.4 Go Live

When ready for real payments:
1. Complete Paystack business verification
2. Switch to **Live Keys** in your `.env`
3. Set `PAYSTACK_TEST_MODE=false`

---

## Step 4: Notification Channels Setup

### 4.1 WhatsApp Business API

**Option A: Via Meta (Direct)**
1. Create a Meta Business account at [business.facebook.com](https://business.facebook.com)
2. Go to Meta Developer portal → Create App → Business type
3. Add WhatsApp product
4. Get your **Phone Number ID** and **Access Token**

**Option B: Via Provider (Easier)**
Use a provider like [360dialog](https://www.360dialog.com) or [Twilio](https://www.twilio.com/whatsapp):
1. Sign up and get API credentials
2. Register your WhatsApp Business number
3. Create message templates (must be approved by Meta)

Update `.env.local`:
```env
WHATSAPP_ENABLED=true
WHATSAPP_API_URL=https://graph.facebook.com/v18.0
WHATSAPP_ACCESS_TOKEN=your-access-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
```

### 4.2 Termii SMS

1. Sign up at [termii.com](https://www.termii.com)
2. Go to **API Keys** and copy your key
3. Register a Sender ID (e.g., "SchoolMgr")
4. Fund your SMS wallet

Update `.env.local`:
```env
SMS_ENABLED=true
TERMII_API_KEY=your-termii-api-key
TERMII_SENDER_ID=SchoolMgr
TERMII_BASE_URL=https://api.ng.termii.com/api
```

### 4.3 SendGrid Email

1. Sign up at [sendgrid.com](https://sendgrid.com)
2. Create an API key with Mail Send permissions
3. Verify your sender email address
4. (Optional) Set up domain authentication for better deliverability

Update `.env.local`:
```env
EMAIL_ENABLED=true
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=SG.your-api-key
EMAIL_FROM=noreply@yourschool.com
EMAIL_FROM_NAME=School Manager
```

---

## Step 5: Deployment

### Option A: Replit

1. Go to [replit.com](https://replit.com) → Create Repl → Import from ZIP
2. Upload the `school-manager.zip` file
3. Go to **Secrets** tab and add all environment variables
4. Click **Run** — Replit will install dependencies and start the dev server
5. For production: click **Deploy** → the `.replit` config handles the build

### Option B: Vercel (Recommended for Production)

1. Push code to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/your-username/school-manager.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com) → New Project → Import from GitHub

3. Set environment variables in Vercel dashboard:
   - Add all variables from `.env.local`
   - Set `NEXT_PUBLIC_APP_URL` to your Vercel domain

4. Deploy — Vercel auto-detects Next.js and builds

5. Set up custom domain (optional):
   - Go to Settings → Domains
   - Add your domain and configure DNS

6. Configure cron (for automated fee reminders):
   - The `vercel.json` already has a cron schedule
   - Set `CRON_SECRET` in environment variables
   - Cron runs daily at 9am WAT (weekdays)

### Option C: Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Set environment variables
3. Railway auto-detects Next.js
4. Custom domain available on paid plan

---

## Step 6: Verify Auth Users

The seed migration (`009b_seed_users.sql`) automatically creates both Supabase Auth users and application users. Verify in your Supabase dashboard:

1. Go to **Authentication → Users**
2. You should see 4 users:
   - admin@brightfuture.ng
   - teacher@brightfuture.ng
   - parent@brightfuture.ng
   - finance@brightfuture.ng

3. Go to **Table Editor → users** (public schema)
4. Verify 4 rows exist with matching `auth_id` values

If the auth users don't appear, re-run `009b_seed_users.sql` in the SQL Editor.

### Adding Real School Staff Later

When onboarding real users:
1. They register via the app's registration page, OR
2. Admin creates them in Supabase Auth dashboard → then adds their details in the app
3. The middleware automatically links `auth_id` to the `users` table

---

## Step 7: Verify Everything Works

Run through this quick checklist after deployment:

### Admin Role
- [ ] Login as admin@schoolmanager.com
- [ ] Dashboard loads with stats
- [ ] Students list shows seeded students
- [ ] Can navigate to all admin pages
- [ ] Timetable page loads and shows class selector

### Teacher Role
- [ ] Login as teacher@schoolmanager.com
- [ ] Dashboard shows assigned classes
- [ ] Attendance marking page works
- [ ] Grade entry grid loads
- [ ] Messages page accessible

### Parent Role
- [ ] Login as parent@schoolmanager.com
- [ ] Dashboard shows child/children cards
- [ ] Can view attendance calendar
- [ ] Can view grades
- [ ] Fee balance displays correctly
- [ ] Messages page accessible

### Finance Role
- [ ] Login as finance@schoolmanager.com
- [ ] Dashboard shows financial summary
- [ ] Outstanding fees list loads
- [ ] Payroll page shows salary data
- [ ] Reconciliation page loads
- [ ] Fee reminders page accessible

---

## Troubleshooting

### Login fails / redirects back to login
**Most common issue.** This means the `auth_id` in the `users` table doesn't match Supabase Auth.
1. Check Authentication → Users in Supabase dashboard — 4 test users should exist
2. Check the `users` table — `auth_id` should match the Auth user UIDs
3. If users are missing, re-run `009b_seed_users.sql` in SQL Editor
4. If auth.users insert fails (rare), create users manually in Auth dashboard, then update `users.auth_id`

### "relation does not exist" errors
Migrations weren't run completely. Re-run `scripts/setup-database.sql` or check which migration failed.

### Blank dashboard / no data
Seed data migrations (009, 010, 011, 013, etc.) may not have run. Check:
- `students` table should have rows
- `classes` table should have rows
- `school` table should have one row

### Payment page errors
- Verify Paystack keys are correct (test vs live)
- Check browser console for Paystack script loading errors
- Ensure `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY` starts with `pk_test_` or `pk_live_`

### Build errors on deployment
```bash
npm run type-check  # Find TypeScript errors
npm run build       # Test build locally
```

### Supabase rate limits on free tier
Free tier allows 500MB database, 1GB file storage, 2GB bandwidth. For a pilot (50-100 students), this is sufficient. Upgrade to Pro ($25/month) for production use.

---

## Recommended Production Settings

| Setting | Value |
|---------|-------|
| Supabase Plan | Pro ($25/month) |
| Vercel Plan | Pro ($20/month) for custom domain + analytics |
| Paystack | Live keys + webhook |
| WhatsApp | Approved templates |
| SMS | Funded Termii wallet |
| CRON_SECRET | Random 32+ character string |
| Node.js | 20.x |

---

## Support Contacts

For technical issues during setup:
- Supabase: [supabase.com/docs](https://supabase.com/docs)
- Paystack: [paystack.com/docs](https://paystack.com/docs)
- Termii: [developer.termii.com](https://developer.termii.com)
- Vercel: [vercel.com/docs](https://vercel.com/docs)
