# School Manager — Quick Start Guide

## Overview

School Manager is a mobile-first school management platform for Nigerian private primary and secondary schools. It serves four user roles: Parents, Teachers, Admin, and Finance.

## Tech Stack

- **Framework:** Next.js 14 (App Router, TypeScript)
- **Database:** Supabase (PostgreSQL + Auth + Realtime + Storage)
- **Styling:** Tailwind CSS + shadcn/ui
- **State:** TanStack Query v5 (server) + Zustand (UI)
- **Payments:** Paystack
- **Notifications:** WhatsApp Business API + Termii SMS + SendGrid email

## Setup

### 1. Clone & Install

```bash
git clone <repo-url>
cd school-manager
npm install
```

### 2. Environment Variables

Copy `.env.example` to `.env.local` and fill in:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY=pk_test_...
PAYSTACK_SECRET_KEY=sk_test_...

WHATSAPP_API_TOKEN=your-whatsapp-token
WHATSAPP_PHONE_ID=your-phone-number-id

TERMII_API_KEY=your-termii-key
TERMII_SENDER_ID=SchoolMgr

SENDGRID_API_KEY=your-sendgrid-key
SENDGRID_FROM_EMAIL=noreply@yourschool.com
```

### 3. Database Setup

Run all migrations in order in the Supabase SQL Editor:

```
supabase/migrations/
  001_core_schema.sql        — Users, school, academic years, classes
  002_academic_schema.sql    — Subjects, attendance, assessments, grades
  003_financial_schema.sql   — Fees, payments, payroll tables
  004_communication.sql      — Announcements, messages, notifications
  005_disciplinary.sql       — Incident tracking
  006_rls_policies.sql       — Row-level security
  009_seed_data.sql          — Base school, classes, subjects, fee types
  009b_seed_users.sql        — Test user accounts (Auth + app users)
  010_sprint3_seed_data.sql  — Students, parents, teachers, attendance, grades
  011_sprint5_teacher_data.sql
  011_sprint5_teacher_data.sql
  012_fixup_feedback_schema.sql
  013_sprint6_fee_data.sql
  014_sprint8_communication.sql
  015_sprint8_notification_seed.sql
  016_sprint9_teacher_leave.sql
  017_sprint11_payroll_plans.sql
  018_sprint13_timetable_messages.sql
```

### 4. Run Development Server

```bash
npm run dev
```

Open http://localhost:3000

### 5. Default Test Accounts

| Role    | Email                    | Password     |
|---------|--------------------------|--------------|
| Admin   | admin@brightfuture.ng    | TestPass123! |
| Teacher | teacher@brightfuture.ng  | TestPass123! |
| Parent  | parent@brightfuture.ng   | TestPass123! |
| Finance | finance@brightfuture.ng  | TestPass123! |

## Project Structure

```
src/
  app/
    (auth)/          — Login, register, password flows
    (dashboard)/     — Role-based dashboards
      parent/        — 5 pages (dashboard, children, fees, messages, announcements)
      teacher/       — 7 pages (dashboard, classes, attendance, feedback, messages, leave, announcements)
      admin/         — 10 pages (dashboard, students, classes, teachers, timetable, attendance, leave, discipline, announcements, reports)
      finance/       — 10 pages (dashboard, fees, outstanding, payment plans, payments, reconciliation, reminders, payroll, salary, reports)
    api/             — 44+ REST API routes
  components/
    ui/              — shadcn/ui primitives
    layouts/         — Sidebar, MobileNav, Header, DashboardShell
    shared/          — StatCard, PageHeader, EmptyState, DataTable, etc.
  features/          — Business logic (hooks, types per domain)
  lib/
    supabase/        — Client/server/middleware Supabase helpers
    utils/           — Format, validation, errors, payroll calculations
    hooks/           — PWA, debounce, media query hooks
    integrations/    — Paystack, WhatsApp, SMS, email clients
  stores/            — Zustand UI state
  types/             — Database types, API schemas, nav config
```

## Feature Summary

### Parent Module
- Student dashboard with attendance, grades, fees overview
- Detailed attendance calendar with color coding
- Grade viewing with class average comparison
- Fee payment via Paystack (card, bank transfer, USSD)
- Digital receipts
- Direct messaging with teachers
- Announcement feed with multi-channel delivery

### Teacher Module
- Class roster management
- Quick attendance marking (mark all present + exceptions)
- Grade entry grid with validation
- Student behavioral feedback
- Leave request self-service
- Direct messaging with parents
- Announcement viewing

### Admin Module
- Student registration wizard
- Class and section management
- Teacher list with performance overview
- Teacher attendance marking
- Leave approval workflow
- Disciplinary incident logging with severity levels
- Timetable management (weekly grid per class)
- Announcement composer (multi-channel: push, WhatsApp, SMS, email)
- Reports with PDF/Excel export

### Finance Module
- Fee type and structure configuration
- Fee account assignment to students
- Outstanding fees with aging analysis (30/60/90+ days)
- Payment plan management (installment tracking)
- Payment transaction log
- Daily reconciliation dashboard
- Automated fee reminders (multi-channel)
- Salary structure setup per teacher
- Payroll processing with Nigerian deductions:
  - PAYE tax (6-bracket system with consolidated relief)
  - Pension (8% employee, PFA Act 2014)
  - NHF (2.5% of basic)
- Payslip generation and approval workflow
- NIBSS bank transfer file export
- Financial reporting dashboard

## Nigerian Localization

- Currency: ₦ (Naira) with proper formatting
- Date format: DD/MM/YYYY
- Timezone: WAT (UTC+1)
- Phone: +234 format
- Tax: PAYE brackets per Nigeria Finance Act
- Banks: 20 Nigerian banks with NIBSS codes
- Payments: Paystack (Verve, Mastercard, Visa, USSD, bank transfer)
- Notifications: WhatsApp Business API + Termii SMS

## PWA Support

The app includes:
- Web manifest for add-to-home-screen
- Service worker for offline caching
- Network status indicator
- Offline fallback page

## Deployment

### Replit
1. Import project
2. Set environment variables in Secrets
3. Run `npm run build && npm start`

### Vercel
1. Connect GitHub repo
2. Set environment variables
3. Deploy (auto-detects Next.js)

## API Conventions

All API routes follow this pattern:

- Success: `{ data: ... }`
- Error: `{ error: { message: string, code: string } }`
- Authentication: Supabase JWT via cookies
- Authorization: Role checked in each route handler
- Pagination: `?page=1&limit=20` where applicable
