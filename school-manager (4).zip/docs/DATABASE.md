# Database Schema Reference

## Tables (18 migrations, 30+ tables)

### Core Tables
| Table | Purpose |
|-------|---------|
| `school` | School profile, settings |
| `users` | All user accounts (auth_id links to Supabase Auth) |
| `academic_years` | e.g., "2025/2026" |
| `terms` | 3 terms per year with start/end dates |
| `classes` | e.g., "Primary 1A", "JSS 2B" |
| `subjects` | Mathematics, English, etc. |
| `students` | Student records with admission numbers |
| `parents` | Parent contact info and preferences |
| `teachers` | Staff profiles with qualifications |
| `student_parents` | Many-to-many: which parents belong to which students |
| `teacher_assignments` | Teacher ↔ Class ↔ Subject mapping |

### Academic Tables
| Table | Purpose |
|-------|---------|
| `attendance_records` | Daily student attendance (Present/Absent/Late/Excused) |
| `assessments` | Tests, exams, quizzes definitions |
| `grades` | Student scores per assessment |
| `report_cards` | Term-end report generation |
| `student_feedback` | Teacher comments (behavioral/academic) |

### Financial Tables
| Table | Purpose |
|-------|---------|
| `fee_types` | Tuition, Development Fee, Sports, etc. |
| `fee_structures` | Fee packages per term/class |
| `fee_structure_items` | Line items within a structure |
| `student_fee_accounts` | Per-student balance tracking (computed `balance` column) |
| `payment_transactions` | All payments with gateway references |
| `salary_structures` | Per-teacher salary breakdown |
| `payroll_runs` | Monthly payroll batches |
| `payslips` | Individual teacher payslips with deductions |
| `payment_plans` | Installment arrangements |
| `payment_plan_items` | Individual installment due dates |
| `fee_reminder_logs` | History of sent payment reminders |

### Communication Tables
| Table | Purpose |
|-------|---------|
| `announcements` | School-wide or targeted announcements |
| `notifications` | In-app notifications per user |
| `direct_messages` | Parent ↔ Teacher messaging |

### Administrative Tables
| Table | Purpose |
|-------|---------|
| `disciplinary_incidents` | Student misconduct records |
| `teacher_attendance` | Daily staff attendance |
| `leave_requests` | Teacher leave applications |
| `timetable_slots` | Class schedule (day + time + subject + teacher) |

## Key Relationships

```
school ─┬─ users ─── parents
        │           └─ student_parents ─── students ─── classes
        │
        ├─ teachers ── teacher_assignments ── subjects
        │                                    └─ classes
        │
        ├─ fee_structures ── student_fee_accounts ── payment_transactions
        │
        ├─ payroll_runs ── payslips ── teachers
        │
        └─ announcements ── notifications ── users
```

## Row-Level Security

All tables have RLS enabled via `006_rls_policies.sql`:
- **Parents** see only their children's data
- **Teachers** see their assigned classes
- **Admin** sees all school data
- **Finance** sees financial data + student info

## Indexes

Performance indexes on all high-traffic queries:
- `(student_id, date)` on attendance
- `(class_id, date)` on attendance
- `(status, due_date)` on fee accounts
- `(recipient_id WHERE read_at IS NULL)` on notifications
- `(class_id, day_of_week)` on timetable
- All foreign key columns
