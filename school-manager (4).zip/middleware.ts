import { NextResponse, type NextRequest } from "next/server";
import { createMiddlewareClient } from "@/lib/supabase/middleware";

// Routes that don't require authentication
const PUBLIC_ROUTES = ["/login", "/register", "/forgot-password", "/reset-password"];
// Role-to-dashboard mapping
const ROLE_ROUTES: Record<string, string> = {
  parent: "/parent",
  teacher: "/teacher",
  admin: "/admin",
  finance: "/finance",
};

export async function middleware(request: NextRequest) {
  const { supabase, response } = createMiddlewareClient(request);
  const { pathname } = request.nextUrl;

  // Refresh session
  const { data: { session } } = await supabase.auth.getSession();

  // Public routes — redirect to dashboard if already logged in
  if (PUBLIC_ROUTES.some((route) => pathname.startsWith(route))) {
    if (session) {
      const { data: user } = await supabase
        .from("users")
        .select("role")
        .eq("auth_id", session.user.id)
        .single();

      if (user?.role) {
        const dashboard = ROLE_ROUTES[user.role] || "/parent";
        return NextResponse.redirect(new URL(dashboard, request.url));
      }
    }
    return response;
  }

  // Protected routes — redirect to login if not authenticated
  if (!session) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Role-based access control for dashboard routes
  const dashboardPrefixes = Object.values(ROLE_ROUTES);
  const isDashboardRoute = dashboardPrefixes.some((prefix) => pathname.startsWith(prefix));

  if (isDashboardRoute) {
    const { data: user } = await supabase
      .from("users")
      .select("role")
      .eq("auth_id", session.user.id)
      .single();

    if (user?.role) {
      const allowedPrefix = ROLE_ROUTES[user.role];
      if (allowedPrefix && !pathname.startsWith(allowedPrefix)) {
        // User is accessing a route outside their role — redirect to their dashboard
        return NextResponse.redirect(new URL(allowedPrefix, request.url));
      }
    }
  }

  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|icons|manifest.json|sw.js|api).*)",
  ],
};
